package dev.killerranking.entity;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.*;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1322;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.network.syncher.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import java.util.*;

/** Summoned human follower: no natural spawning, loot, reproduction or owner damage. */
public final class BishopFollower extends class_1314 {
    private static final class_2940<Boolean> LEAPING=class_2945.method_12791(BishopFollower.class,class_2943.field_13323);
    private static final class_2940<Boolean> FIGHTING=class_2945.method_12791(BishopFollower.class,class_2943.field_13323);
    private static final class_2940<Integer> ATTACK_TICK=class_2945.method_12791(BishopFollower.class,class_2943.field_13327);
    private static final class_2940<Integer> ATTACK_STYLE=class_2945.method_12791(BishopFollower.class,class_2943.field_13327);
    private static final class_2940<Integer> LEAP_POSE=class_2945.method_12791(BishopFollower.class,class_2943.field_13327);
    private static final class_2940<Boolean> BARRAGE_ECHO=class_2945.method_12791(BishopFollower.class,class_2943.field_13323);
    private UUID ownerId;private long expires;private int formation,attackDelay,leapDelay,flight,ownerAttackStamp,ownerHurtStamp;
    private class_243 flightDirection=class_243.field_1353;
    private int leapWindup,flightAge,landingTicks;
    private int strikeTick,strikeStyle,cycle,comboHits,repathTicks,stalledTicks,unseenTicks;
    private UUID comboVictim,combatTarget;
    private UUID designatedTarget;
    private class_243 lastWalk=class_243.field_1353,lastPath=class_243.field_1353;
    private static final net.minecraft.class_2960 COMBO_DAMAGE=KillerRankingMod.id("bishop_combo_contact");
    public BishopFollower(class_1299<? extends class_1314> type,class_1937 level){super(type,level);field_6194=0;}
    public static class_5132.class_5133 attributes(){return class_1308.method_26828().method_26868(class_5134.field_23716,18).method_26868(class_5134.field_23719,.62).method_26868(class_5134.field_23721,4).method_26868(class_5134.field_23717,32).method_26868(class_5134.field_23718,.15);}
    @Override protected void method_5693(class_2945.class_9222 builder){super.method_5693(builder);builder.method_56912(LEAPING,false);builder.method_56912(FIGHTING,false);builder.method_56912(ATTACK_TICK,0);builder.method_56912(ATTACK_STYLE,1);builder.method_56912(LEAP_POSE,0);builder.method_56912(BARRAGE_ECHO,false);}
    @Override protected void method_5959(){field_6201.method_6277(0,new class_1347(this));field_6201.method_6277(1,new EscortGoal());}
    public void summon(class_3222 p,long until,int index,int level){
        ownerId=p.method_5667();expires=until;formation=index;
        // Equipment contributes the dagger's four attack points on the next tick.
        method_5996(class_5134.field_23721).method_6192(BishopRules.damage(level)-4);
        method_6122(class_1268.field_5808,new class_1799(KillerRankingMod.BISHOP_DAGGER));method_5946(class_1304.field_6173,0);
        method_5971();
        armAt(p.method_6083(),p.method_6117());
    }
    public void armAt(int attackStamp,int hurtStamp){ownerAttackStamp=attackStamp;ownerHurtStamp=hurtStamp;}
    public void barrage(class_3222 p,long until,int index,int level){
        summon(p,until,index,level);field_6011.method_12778(BARRAGE_ECHO,true);field_6011.method_12778(FIGHTING,true);field_6011.method_12778(ATTACK_STYLE,BishopRules.COMBO);field_6011.method_12778(ATTACK_TICK,1);
        field_5960=true;method_5875(true);method_5684(true);
    }
    public boolean barrageEcho(){return field_6011.method_12789(BARRAGE_ECHO);}
    @Override public boolean method_5810(){return !barrageEcho()&&super.method_5810();}
    @Override public boolean method_5863(){return !barrageEcho()&&super.method_5863();}
    @Override public boolean method_5732(){return !barrageEcho()&&super.method_5732();}
    @Override public void method_5697(class_1297 other){if(!barrageEcho())super.method_5697(other);}
    public UUID ownerId(){return ownerId;}
    public class_3222 owner(){return ownerId==null||method_37908().field_9236?null:method_37908().method_8503().method_3760().method_14602(ownerId);}
    public boolean leaping(){return field_6011.method_12789(LEAPING);}
    public boolean fighting(){return field_6011.method_12789(FIGHTING);}
    public int attackPoseTick(){return field_6011.method_12789(ATTACK_TICK);}
    public int attackStyle(){return field_6011.method_12789(ATTACK_STYLE);}
    public boolean striking(){return attackPoseTick()>0;}
    public int leapPoseTick(){return field_6011.method_12789(LEAP_POSE);}
    @Override public boolean method_5974(double distance){return false;}
    @Override public boolean method_6121(class_1297 victim){
        if(barrageEcho())return false;
        var p=owner();if(!(victim instanceof class_1309 e)||!BishopTargets.allowed(p,e))return false;
        e.method_29505(p);
        boolean hit=super.method_6121(victim);
        if(hit){var at=method_19538().method_1019(e.method_19538().method_1020(method_19538()).method_1029().method_1021(.65)).method_1031(0,1.05,0);
            ((net.minecraft.class_3218)method_37908()).method_14199(KillerRankingMod.BISHOP_SLASH,at.field_1352,at.field_1351,at.field_1350,1,0,0,0,0);
        }
        return hit;
    }
    @Override protected net.minecraft.class_5321<net.minecraft.class_52> method_5991(){return net.minecraft.class_39.field_844;}
    @Override protected void method_6099(net.minecraft.class_3218 level,net.minecraft.class_1282 source,boolean recentlyHit){ }
    @Override public boolean method_5874(net.minecraft.class_3218 level,class_1309 victim){
        // Vanilla awards per-entity mission statistics to the direct killer separately from kill credit.
        var p=owner();if(p!=null&&victim!=p&&KillerRankingMod.BISHOP.eligible(p))p.method_5874(level,victim);
        return super.method_5874(level,victim);
    }
    public boolean leapAt(class_1309 enemy,boolean force){
        if(!method_24828()||leapWindup>0||flight>0||landingTicks>0||(!force&&leapDelay>0)||!BishopTargets.allowed(owner(),enemy)||!method_6057(enemy))return false;
        var offset=BishopTactics.lead(enemy.method_19538(),enemy.method_18798(),2).method_1020(method_19538());double distance=offset.method_37267();
        if(!BishopRules.canLeap(distance)||Math.abs(offset.field_1351)>1.6||method_37908().method_20812(this,method_5829().method_997(offset.method_1029().method_1021(.7))).iterator().hasNext())return false;
        flightDirection=new class_243(offset.field_1352,0,offset.field_1350).method_1029();
        leapWindup=BishopRules.LEAP_PREPARE;leapDelay=24;method_5942().method_6340();
        field_6011.method_12778(ATTACK_STYLE,BishopRules.STAB);
        var v=method_18798();method_18800(0,v.field_1351,0);field_6011.method_12778(LEAP_POSE,1);return true;
    }
    private void startStrike(int style){
        strikeStyle=style;strikeTick=1;comboHits=0;comboVictim=null;cycle++;
        field_6011.method_12778(ATTACK_TICK,1);field_6011.method_12778(ATTACK_STYLE,style);field_6011.method_12778(LEAP_POSE,0);
        landingTicks=0;method_5942().method_6340();var v=method_18798();method_18800(0,v.field_1351,0);
    }
    private void stopStrike(){strikeTick=0;field_6011.method_12778(ATTACK_TICK,0);attackDelay=3;}
    private void face(class_1309 enemy){
        method_5988().method_6226(enemy,50,35);
        var offset=enemy.method_19538().method_1020(method_19538());
        if(offset.method_37268()>.0001){float yaw=(float)(Math.atan2(offset.field_1350,offset.field_1352)*180/Math.PI-90);
            method_36456(net.minecraft.class_3532.method_15388(method_36454(),yaw,35));field_6283=method_36454();}
    }
    private void resetEncounter(class_1309 enemy){
        combatTarget=enemy.method_5667();cycle=0;attackDelay=leapDelay=unseenTicks=stalledTicks=repathTicks=0;
        flight=leapWindup=landingTicks=strikeTick=comboHits=0;comboVictim=null;lastWalk=method_19538();lastPath=class_243.field_1353;
        method_5942().method_6340();var v=method_18798();method_18800(0,v.field_1351,0);
        field_6011.method_12778(ATTACK_TICK,0);field_6011.method_12778(LEAP_POSE,0);field_6011.method_12778(LEAPING,false);
    }
    private class_1309 alignDesignation(class_3222 p){
        var marked=KillerRankingMod.BISHOP.designated(p);
        if(marked!=null){
            designatedTarget=marked.method_5667();
            if(method_5968()!=marked){method_5980(marked);resetEncounter(marked);}
            field_6011.method_12778(FIGHTING,true);
        }else if(designatedTarget!=null){
            designatedTarget=null;method_5980(null);combatTarget=null;
            strikeTick=flight=leapWindup=landingTicks=comboHits=0;comboVictim=null;
            method_5942().method_6340();method_18800(0,method_18798().field_1351,0);
            field_6011.method_12778(FIGHTING,false);field_6011.method_12778(ATTACK_TICK,0);field_6011.method_12778(LEAP_POSE,0);field_6011.method_12778(LEAPING,false);
        }
        return marked;
    }
    private class_1309 nextThreat(class_3222 p,class_1309 excluded){
        return method_37908().method_8390(class_1309.class,p.method_5829().method_1014(16),e->e!=excluded
            &&e instanceof net.minecraft.class_1569&&BishopTargets.allowed(p,e)
            &&(method_6057(e)||method_5942().method_6349(e,0)!=null)).stream()
            .min(Comparator.comparingDouble(e->method_5858(e)+(e instanceof class_1308 mob&&mob.method_5968()==p?-32:0)))
            .orElse(null);
    }
    private void pursue(class_1309 enemy){
        double gap=enemy.method_19538().method_1020(method_19538()).method_37267();
        if(gap>3&&method_19538().method_1025(lastWalk)<.003)stalledTicks++;else stalledTicks=0;
        lastWalk=method_19538();
        var aim=BishopTactics.lead(enemy.method_19538(),enemy.method_18798(),3);
        boolean crowded=method_6057(enemy)&&gap<6&&method_37908().method_8390(BishopFollower.class,method_5829().method_1014(.8),e->e!=this&&Objects.equals(ownerId,e.ownerId())).size()>0;
        if(crowded||stalledTicks>=16)aim=BishopTactics.approach(method_19538(),aim,formation+(stalledTicks/16));
        if(--repathTicks<=0||method_5942().method_6357()||aim.method_1025(lastPath)>.64){
            boolean found=method_5942().method_6337(aim.field_1352,aim.field_1351,aim.field_1350,BishopRules.RUN_SPEED);
            if(!found)method_5942().method_6335(enemy,BishopRules.RUN_SPEED);
            repathTicks=4;lastPath=aim;
        }
    }
    @Override protected void method_5958(){
        super.method_5958();var p=owner();
        if(barrageEcho()){
            if(p==null||p.method_37908()!=method_37908()||!KillerRankingMod.BISHOP.eligible(p)||!KillerRankingMod.BISHOP_BARRAGE.manages(p,method_5667())||p.field_13995.method_30002().method_8510()>=expires){
                method_31472();return;
            }
            method_5942().method_6340();method_18799(class_243.field_1353);field_6011.method_12778(ATTACK_TICK,(int)Math.clamp(BishopBarrageRules.ECHO_TICKS-(expires-p.field_13995.method_30002().method_8510()),1,BishopBarrageRules.ECHO_TICKS));return;
        }
        if(p==null||p.method_37908()!=method_37908()||!KillerRankingMod.BISHOP.eligible(p)||!KillerRankingMod.BISHOP.manages(p,method_5667())
            ||p.field_13995.method_30002().method_8510()>=expires){method_31472();return;}
        alignDesignation(p);
        if(attackDelay>0)attackDelay--;if(leapDelay>0)leapDelay--;
        if(method_5968()!=null&&!BishopTargets.allowed(p,method_5968()))method_5980(null);
        if(strikeTick>0){
            var enemy=method_5968();
            if(!BishopTargets.allowed(p,enemy)||method_5858(enemy)>49){stopStrike();}
            else{
                face(enemy);var gap=enemy.method_19538().method_1020(method_19538());double distance=gap.method_37267();
                if(method_6057(enemy)){
                    var aim=BishopTactics.lead(enemy.method_19538(),enemy.method_18798(),2).method_1020(method_19538());
                    var step=new class_243(aim.field_1352,0,aim.field_1350).method_1029().method_1021(BishopTactics.step(distance,strikeStyle==BishopRules.STAB_COMBO));
                    var v=method_18798();method_18799(step.method_1031(0,v.field_1351,0));field_6007=true;
                }
                if(BishopRules.isHitTick(strikeStyle,strikeTick)&&method_6057(enemy)
                    &&method_5858(enemy)<Math.pow(BishopRules.reach(strikeStyle,enemy.method_17681()),2)){
                    // Confirmed contacts of the same multi-hit sequence pass native armor/parry checks.
                    if(BishopRules.repeated(strikeStyle)&&comboHits>0&&enemy.method_5667().equals(comboVictim))enemy.field_6008=0;
                    method_6104(class_1268.field_5808);boolean hit;
                    if(BishopRules.repeated(strikeStyle)){
                        var damage=method_5996(class_5134.field_23721);
                        damage.method_26835(new class_1322(COMBO_DAMAGE,BishopRules.COMBO_DAMAGE_SCALE-1,class_1322.class_1323.field_6331));
                        try{hit=method_6121(enemy);}finally{damage.method_6200(COMBO_DAMAGE);}
                    }else hit=method_6121(enemy);
                    if(hit&&BishopRules.repeated(strikeStyle)){comboVictim=enemy.method_5667();comboHits++;}
                }
                field_6011.method_12778(ATTACK_TICK,strikeTick++);
                if(strikeTick>BishopRules.attackLength(strikeStyle))stopStrike();
            }
        }
        if(landingTicks>0){field_6011.method_12778(LEAP_POSE,18-landingTicks);if(--landingTicks==0)field_6011.method_12778(LEAP_POSE,0);}
        if(leapWindup>0){
            if(!BishopTargets.allowed(p,method_5968())||!method_6057(method_5968())){leapWindup=0;field_6011.method_12778(LEAP_POSE,0);}
            else if(--leapWindup==0){
                var offset=BishopTactics.lead(method_5968().method_19538(),method_5968().method_18798(),2).method_1020(method_19538());flightDirection=new class_243(offset.field_1352,0,offset.field_1350).method_1029();
                flight=10;flightAge=0;method_18799(flightDirection.method_1021(BishopRules.LEAP_SPEED).method_1031(0,BishopRules.LEAP_UP,0));
                field_6007=true;field_6037=true;field_6011.method_12778(LEAPING,true);field_6011.method_12778(LEAP_POSE,5);
            }else field_6011.method_12778(LEAP_POSE,1+(int)(3.0*(BishopRules.LEAP_PREPARE-leapWindup)/BishopRules.LEAP_PREPARE));
        }
        if(flight>0){
            flight--;flightAge++;field_6017=0;field_6011.method_12778(LEAP_POSE,Math.min(13,4+flightAge));
            var enemy=method_5968();var v=method_18798();
            boolean valid=BishopTargets.allowed(p,enemy)&&method_6057(enemy);
            if(valid){var aim=BishopTactics.lead(enemy.method_19538(),enemy.method_18798(),2).method_1020(method_19538());flightDirection=new class_243(aim.field_1352,0,aim.field_1350).method_1029();}
            double remaining=valid?enemy.method_19538().method_1020(method_19538()).method_1026(flightDirection)-1.35:0;
            if(!valid||remaining<=.1||flightAge>2&&(method_24828()||field_5976)||flight==0){
                flight=0;field_6011.method_12778(LEAPING,false);method_18800(0,v.field_1351,0);landingTicks=4;field_6011.method_12778(LEAP_POSE,14);repathTicks=0;
            }else method_18799(flightDirection.method_1021(Math.clamp(remaining,0,BishopRules.LEAP_SPEED)).method_1031(0,v.field_1351,0));
        }
    }
    @Override public void method_5652(class_2487 tag){super.method_5652(tag);if(ownerId!=null)tag.method_25927("BishopOwner",ownerId);tag.method_10544("BishopExpires",expires);tag.method_10569("BishopFormation",formation);tag.method_10556("BishopEcho",barrageEcho());}
    @Override public void method_5749(class_2487 tag){super.method_5749(tag);ownerId=tag.method_25928("BishopOwner")?tag.method_25926("BishopOwner"):null;expires=tag.method_10537("BishopExpires");formation=tag.method_10550("BishopFormation");field_6011.method_12778(BARRAGE_ECHO,tag.method_10577("BishopEcho"));if(barrageEcho()){field_5960=true;method_5875(true);}}
    private final class EscortGoal extends class_1352 {
        EscortGoal(){method_6265(EnumSet.of(class_4134.field_18405,class_4134.field_18406));}
        @Override public boolean method_6264(){return true;}
        @Override public boolean method_38846(){return true;}
        @Override public void method_6268(){
            if(barrageEcho())return;
            var p=owner();if(p==null)return;var designated=alignDesignation(p);class_1309 triggered=null;
            if(ownerHurtStamp!=p.method_6117()){
                ownerHurtStamp=p.method_6117();if(BishopTargets.allowed(p,p.method_6065()))triggered=p.method_6065();
            }
            if(ownerAttackStamp!=p.method_6083()){
                ownerAttackStamp=p.method_6083();if(triggered==null&&BishopTargets.allowed(p,p.method_6052()))triggered=p.method_6052();
            }
            if(designated==null&&triggered!=null){method_5980(triggered);field_6011.method_12778(FIGHTING,true);}
            if(designated==null&&fighting()&&(!BishopTargets.allowed(p,method_5968())||p.method_5858(method_5968())>40*40)){
                method_5980(nextThreat(p,null));if(method_5968()==null)field_6011.method_12778(FIGHTING,false);
            }
            var enemy=method_5968();
            if(enemy!=null&&BishopTargets.allowed(p,enemy)&&(designated!=null||p.method_5858(enemy)<=40*40)){
                if(!enemy.method_5667().equals(combatTarget))resetEncounter(enemy);
                face(enemy);if(method_6057(enemy))unseenTicks=0;else unseenTicks++;
                if(designated==null&&unseenTicks>60&&stalledTicks>=16&&Math.floorMod(field_6012,10)==Math.floorMod(formation,10)){var alternative=nextThreat(p,enemy);if(alternative!=null){method_5980(alternative);resetEncounter(alternative);return;}}
                if(strikeTick>0||flight>0||leapWindup>0||landingTicks>0){method_5942().method_6340();return;}
                var offset=enemy.method_19538().method_1020(method_19538());double gap=offset.method_37267();
                double escaping=enemy.method_18798().method_1026(new class_243(offset.field_1352,0,offset.field_1350).method_1029());
                int planned=BishopTactics.attack(cycle,formation,gap,escaping);
                if(attackDelay==0&&method_5858(enemy)<Math.pow(BishopRules.reach(planned,enemy.method_17681()),2)&&method_6057(enemy)){
                    startStrike(planned);return;
                }
                if(gap>=5&&leapAt(enemy,false))return;
                if(gap<=1.25&&method_6057(enemy)){method_5942().method_6340();var v=method_18798();method_18800(0,v.field_1351,0);return;}
                pursue(enemy);
            }else{
                method_5980(null);combatTarget=null;stalledTicks=unseenTicks=0;if(flight>0)return;
                double angle=formation*Math.PI/3+Math.toRadians(p.method_36454());
                double radius=2.1+.85*Math.floorMod(formation/6,5);
                class_243 at=p.method_19538().method_1031(Math.cos(angle)*radius,0,Math.sin(angle)*radius);
                if(method_19538().method_1025(at)>1.6)method_5942().method_6337(at.field_1352,at.field_1351,at.field_1350,1.1);else method_5942().method_6340();
                method_5988().method_6226(p,25,25);
            }
        }
    }
}
