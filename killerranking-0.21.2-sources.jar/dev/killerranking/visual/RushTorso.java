package dev.killerranking.visual;

import net.minecraft.class_243;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Place a rigid native torso so its lower centre stays on the hip joint. */
public final class RushTorso {
    public static class_243 pivot(class_243 hip,class_243 rotation){
        var bottom=new Matrix4f().rotateZYX((float)rotation.field_1350,(float)rotation.field_1351,(float)rotation.field_1352)
            .transformPosition(new Vector3f(0,12,0));
        return hip.method_1023(bottom.x,bottom.y,bottom.z);
    }
    private RushTorso(){ }
}
