package dev.killerranking.visual;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;

/** The front boundary is the actual straight blade, not a perpendicular curved cap. */
public final class BladeSweepCurve {
    public static List<BatTrailHistory.Point> smooth(List<BatTrailHistory.Point> raw) {
        if(raw.size()<3) return List.copyOf(raw);
        double travel=raw.getLast().distance()-raw.getFirst().distance();
        if(travel<.001) return List.copyOf(raw);
        class_243 tipControl=control(raw,travel,true),innerControl=control(raw,travel,false);
        var points=new ArrayList<BatTrailHistory.Point>(17);
        class_243 previous=null;double distance=0;
        for(int i=0;i<=16;i++) {
            double t=i/16d;
            class_243 tip=curve(raw.getFirst().tip(),tipControl,raw.getLast().tip(),t);
            class_243 inner=curve(raw.getFirst().inner(),innerControl,raw.getLast().inner(),t);
            if(previous!=null) distance+=tip.method_1022(previous);
            points.add(new BatTrailHistory.Point(inner,tip,distance));previous=tip;
        }
        return List.copyOf(points);
    }
    private static class_243 control(List<BatTrailHistory.Point> raw,double travel,boolean tip) {
        class_243 start=tip?raw.getFirst().tip():raw.getFirst().inner();
        class_243 end=tip?raw.getLast().tip():raw.getLast().inner();
        class_243 chord=end.method_1020(start);double length=chord.method_1033();
        if(length<.04) return start.method_35590(end,.5);
        class_243 control=class_243.field_1353;double weight=0;
        for(var point:raw) {
            double t=(point.distance()-raw.getFirst().distance())/travel,w=2*t*(1-t);
            class_243 position=tip?point.tip():point.inner();
            control=control.method_1019(position.method_1020(start.method_1021((1-t)*(1-t))).method_1020(end.method_1021(t*t)).method_1021(w));
            weight+=w*w;
        }
        control=weight>.00001?control.method_1021(1/weight):start.method_35590(end,.5);
        class_243 direction=chord.method_1021(1/length),relative=control.method_1020(start);
        double along=Math.clamp(relative.method_1026(direction)/length,.15,.85);
        class_243 bend=relative.method_1020(direction.method_1021(relative.method_1026(direction)));
        if(bend.method_1033()>length) bend=bend.method_1029().method_1021(length);
        return start.method_1019(chord.method_1021(along)).method_1019(bend);
    }
    private static class_243 curve(class_243 start,class_243 control,class_243 end,double t) {
        // Keep both leading endpoints exact, even for a very short or wide cut.
        if(t==0) return start;
        if(t==1) return end;
        return start.method_1021((1-t)*(1-t)).method_1019(control.method_1021(2*t*(1-t))).method_1019(end.method_1021(t*t));
    }
    private BladeSweepCurve() { }
}
