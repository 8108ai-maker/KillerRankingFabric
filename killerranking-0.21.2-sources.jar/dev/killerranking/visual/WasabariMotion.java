package dev.killerranking.visual;
import dev.killerranking.combat.WasabariRules;

import static dev.killerranking.visual.HeavyPunchGrip.rotate;
import dev.killerranking.visual.HeavyPunchGrip.Limb;
import net.minecraft.class_243;

/** Rigid native limbs: cock the foot back, hook forward, then stand and plunge into the held leg. */
public final class WasabariMotion {
    public static final double KNIFE_REACH=SalmosaKnifeGeometry.SKILL_REACH;
    public static final double KNIFE_LIFT=6;
    public record Pose(Limb torso,Limb head,Limb rightArm,Limb leftArm,Limb rightLeg,Limb leftLeg) { }
    public static double grabWeight(float age){return smooth((age-21)/5);}
    public static float raisedLegPitch(float age){return (float)(-1.48*grabWeight(age));}
    /** Keep the opposite palm around the lifted ankle while the knife hand retracts and stabs the same shin. */
    public static Pose hold(Pose base,float age,boolean left,class_243 ankle,class_243 shin,class_243 knifeDirection,float centre){
        knifeDirection=knifeDirection.method_1029();
        var knifePalm=shin.method_1020(knifeDirection.method_1021(KNIFE_REACH+KNIFE_LIFT*(1-stabWeight(age))));
        var knifeShoulder=base.torso().point(left?5:-5,2,0);
        var knife=arm(knifePalm,knifePalm.method_1020(knifeShoulder).method_1029(),left?centre:-centre);
        var braceShoulder=base.torso().point(left?-5:5,2,0);
        var brace=arm(ankle,ankle.method_1020(braceShoulder).method_1029(),left?-centre:centre);
        double weight=grabWeight(age);
        var right=blend(base.rightArm(),left?brace:knife,weight);
        var other=blend(base.leftArm(),left?knife:brace,weight);
        return new Pose(base.torso(),base.head(),right,other,base.rightLeg(),base.leftLeg());
    }
    private static Limb blend(Limb a,Limb b,double weight){return new Limb(a.pivot().method_35590(b.pivot(),weight),a.rotation().method_35590(b.rotation(),weight));}
    public static class_243 knifeDirection(boolean left){return new class_243(left?-.48:.48,.88,0).method_1029();}
    /** Load behind the support leg, kick/hook through on Bari, then plant both feet. */
    public static class_243 hookFoot(float age){
        if(age<=12)return new class_243(-2.5,24,0).method_35590(new class_243(-3.3,18,8.5),smooth(age/12));
        if(age<=15)return new class_243(-3.3,18,8.5);
        if(age<=20)return new class_243(-3.3,18,8.5).method_35590(new class_243(-2.2,13,-13.5),smooth((age-15)/5));
        return new class_243(-2.2,13,-13.5).method_35590(new class_243(-3.2,24,-2),smooth((age-20)/6));
    }
    /** Third-person low reap: weight on the planted leg, a small outside arc, then pull across the ankle. */
    public static Pose thirdPersonPose(float age,boolean left){
        if(age>=26)return pose(age,left);
        var base=pose(age,false);
        double load=smooth(age/10)*(1-smooth((age-14)/6));
        double sweep=smooth((age-14)/6)*(1-smooth((age-21)/5));
        var hip=new class_243(1.35*load+.65*sweep,12+.30*load+.20*sweep,.50*load-.75*sweep);
        var rot=base.torso().rotation().method_1031(-.14*load+.08*sweep,.03*load-.05*sweep,-.10*load+.035*sweep);
        var torso=new Limb(RushTorso.pivot(hip,rot),rot);
        var head=new Limb(torso.pivot(),new class_243(base.head().rotation().field_1352-.07*load+.05*sweep,rot.field_1351*.65,0));
        var shoulderShift=torso.point(-5,2,0).method_1020(base.torso().point(-5,2,0));
        var right=new Limb(base.rightArm().pivot().method_1019(shoulderShift),base.rightArm().rotation());
        // Counterbalance forward instead of throwing the free arm above the head.
        var braceDir=new class_243(.08,.97,-.23).method_35590(new class_243(.14,.40,-.91),Math.max(load,sweep)*.85).method_1029();
        var other=arm(torso.point(5,2,0).method_1019(braceDir.method_1021(10)),braceDir,1);
        var frontHip=hip.method_1031(-2.5,0,0);
        var rightLeg=leg(thirdPersonFoot(age),frontHip);
        var leftLeg=leg(new class_243(3.16,23.98,0),hip.method_1031(2.5,0,0));
        if(left)return new Pose(mirror(torso),mirror(head),mirror(other),mirror(right),mirror(leftLeg),mirror(rightLeg));
        return new Pose(torso,head,right,other,rightLeg,leftLeg);
    }
    private static class_243 thirdPersonFoot(float age){
        var rest=new class_243(-2.5,24,0);var load=new class_243(-3.1,20.5,7.5);
        var outside=new class_243(-4.8,21,-2.5);var contact=new class_243(-2.3,20.5,-10);
        var follow=new class_243(-.8,22,-7);var plant=new class_243(-3.2,24,-2);
        if(age<=12)return rest.method_35590(load,smooth(age/12));
        if(age<=14)return load;
        if(age<=17)return load.method_35590(outside,smooth((age-14)/3));
        if(age<=20)return outside.method_35590(contact,smooth((age-17)/3));
        if(age<=22)return contact.method_35590(follow,smooth((age-20)/2));
        return follow.method_35590(plant,smooth((age-22)/4));
    }
    private static Limb leg(class_243 foot,class_243 hip){
        var d=foot.method_1020(hip).method_1029();
        var rot=new class_243(Math.atan2(d.field_1350,Math.hypot(d.field_1352,d.field_1351)),0,Math.atan2(-d.field_1352,d.field_1351));
        return new Limb(foot.method_1020(rotate(new class_243(0,12,0),rot)),rot);
    }
    public static Pose pose(float age,boolean left){
        double hold=smooth((age-21)/5)*(1-smooth((age-60)/6));
        double load=smooth(age/12)*(1-smooth((age-15)/5));
        double kick=smooth((age-15)/5)*(1-smooth((age-20)/6)),jab=stabWeight(age);
        double twist=.16*load-.19*kick+.10*jab*hold;
        var hip=new class_243(.8*load,12-.4*load,-.7*load);
        var rot=new class_243(.04+.16*hold+.10*jab*hold,.0+twist,-.05*load);
        var torso=new Limb(RushTorso.pivot(hip,rot),rot);
        var head=new Limb(torso.pivot(),new class_243(.05+.18*hold,twist*.65,0));
        var shoulder=torso.point(-5,2,0);
        var aim=new class_243(-.40,-.88,-.26).method_1029();
        var punchDir=new class_243(.06,.97,-.23).method_35590(aim,hold).method_1029();
        var palm=shoulder.method_1019(punchDir.method_1021(10));
        var right=arm(palm,punchDir,-1);
        var braceDir=new class_243(.08,.97,-.23).method_35590(new class_243(.16,-.98,-.12),Math.max(load,kick)).method_1029();
        var other=arm(torso.point(5,2,0).method_1019(braceDir.method_1021(10)),braceDir,1);
        var frontHip=hip.method_1031(-2.5,0,0);
        var restingFoot=frontHip.method_1031(-.7,12,-2);
        var foot=hookFoot(age).method_35590(restingFoot,smooth((age-60)/6));
        var footDirection=foot.method_1020(frontHip).method_1029();
        var footRot=new class_243(Math.atan2(footDirection.field_1350,Math.hypot(footDirection.field_1352,footDirection.field_1351)),0,Math.atan2(-footDirection.field_1352,footDirection.field_1351));
        var rightLeg=new Limb(foot.method_1020(rotate(new class_243(0,12,0),footRot)),footRot);
        var leftLeg=new Limb(hip.method_1031(2.5,0,0),new class_243(.025*load,0,-.055));
        if(left)return new Pose(mirror(torso),mirror(head),mirror(other),mirror(right),mirror(leftLeg),mirror(rightLeg));
        return new Pose(torso,head,right,other,rightLeg,leftLeg);
    }
    private static Limb arm(class_243 palm,class_243 direction,double x){var d=direction.method_1029();var r=new class_243(Math.atan2(d.field_1350,Math.hypot(d.field_1352,d.field_1351)),0,Math.atan2(-d.field_1352,d.field_1351));return new Limb(palm.method_1020(rotate(new class_243(x,10,0),r)),r);}
    private static Limb mirror(Limb p){return new Limb(new class_243(-p.pivot().field_1352,p.pivot().field_1351,p.pivot().field_1350),new class_243(p.rotation().field_1352,-p.rotation().field_1351,-p.rotation().field_1350));}
    public static double stabWeight(double age){for(int i=0;i<WasabariRules.STABS;i++){double t=age-(WasabariRules.FIRST_STAB+i*WasabariRules.STAB_INTERVAL);if(t>=-2&&t<3)return t<0?smooth((t+2)/2):1-smooth(t/3);}return 0;}
    public static double pulse(double age,double beat,double width){return Math.max(0,1-Math.abs(age-beat)/width);}
    private static double smooth(double value){value=Math.clamp(value,0,1);return value*value*(3-2*value);}
    private WasabariMotion() { }
}
