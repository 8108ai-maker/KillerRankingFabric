package dev.killerranking.visual;

import dev.killerranking.combat.HeavyPunchRules;
import net.minecraft.class_243;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Native pixel-space poses for the two supplied self-wrist-brace reference frames. */
public final class HeavyPunchGrip {
    public record Limb(class_243 pivot,class_243 rotation) {
        public class_243 point(double x,double y,double z){return pivot.method_1019(rotate(new class_243(x,y,z),rotation));}
        public class_243 direction(){return rotate(new class_243(0,1,0),rotation);}
        private Limb mirror(){return new Limb(new class_243(-pivot.field_1352,pivot.field_1351,pivot.field_1350),new class_243(rotation.field_1352,-rotation.field_1351,-rotation.field_1350));}
    }
    public record Pose(Limb torso,Limb head,Limb punch,Limb brace,Limb rightLeg,Limb leftLeg) { }
    private static final class_243 HIP=new class_243(0,12,0),UPPER_HAND=new class_243(-3.5,9,-4.8);
    private static final class_243 PUNCH_SHOULDER=new class_243(-5,2,0),BRACE_SHOULDER=new class_243(5,2,0);
    public static Pose pose(float age,boolean leftPunch,boolean firstPerson,float centre){
        double load=smooth(age/24),hit=strike(age),back=smooth((age-46)/8);
        var rotation=new class_243(.08+.57*load,2.05*load,.05*load).method_35590(new class_243(.72,-.22,.08),hit).method_1021(1-back);
        var torso=new Limb(RushTorso.pivot(HIP,rotation),rotation);
        var headRotation=new class_243(rotation.field_1352+.18*load*(1-hit),rotation.field_1351+.18*load*(1-hit),rotation.field_1350)
            .method_35590(new class_243(.92,-.22,.08),hit).method_1021(1-back);
        var head=new Limb(torso.pivot(),headRotation);
        // Anchor the key poses to the caster, not the victim's distance.
        var loaded=torso.pivot().method_1019(rotate(UPPER_HAND,rotation));
        var raisedRoot=torso.pivot().method_1019(rotate(PUNCH_SHOULDER,rotation)).method_1031(0,-4,-1);
        var extended=new class_243(.18,.10,-1).method_1029();
        var palm=loaded.method_35590(raisedRoot.method_1019(extended.method_1021(10)),hit);
        var punchDirection=rotate(UPPER_HAND.method_1020(PUNCH_SHOULDER),rotation).method_1029().method_35590(extended,hit).method_1029();
        var fpOffset=firstPerson?new class_243(0,3-1.5*hit,-2-Math.max(0,loaded.field_1350+6)*(1-hit)):class_243.field_1353;
        palm=palm.method_1019(fpOffset).method_35590(new class_243(-3.5,5,-8),back);
        punchDirection=punchDirection.method_35590(new class_243(0,0,-1),back).method_1029();
        var punch=arm(palm,punchDirection,-centre);
        var wrist=punch.point(-centre,8.2,0);
        var gripPalm=wrist.method_1019(braceOffset());
        var gripRoot=torso.pivot().method_1019(rotate(BRACE_SHOULDER,rotation)).method_1031(0,2,0).method_1019(fpOffset);
        var gripDirection=gripPalm.method_1020(gripRoot).method_1029();
        gripPalm=gripPalm.method_35590(new class_243(3.5,5,-8),back);
        gripDirection=gripDirection.method_35590(new class_243(0,0,-1),back).method_1029();
        var brace=arm(gripPalm,gripDirection,centre);
        // Plant a wide stance before contact; outward roll keeps the feet apart.
        double stance=load*(1-back),plant=smooth((age-24)/12);
        double step=(1.5+.7*plant)*stance,spread=(.12+.10*plant)*stance;
        var rightLeg=new Limb(new class_243(-2.5,12,-step),new class_243(-(.18+.12*plant)*stance,0,spread));
        var leftLeg=new Limb(new class_243(2.5,12,step),new class_243((.16+.12*plant)*stance,0,-spread));
        return leftPunch?new Pose(torso.mirror(),head.mirror(),punch.mirror(),brace.mirror(),leftLeg.mirror(),rightLeg.mirror())
            :new Pose(torso,head,punch,brace,rightLeg,leftLeg);
    }
    public static class_243 braceOffset(){return new class_243(.85,.85,0);}
    private static Limb arm(class_243 palm,class_243 direction,double handX){
        var d=direction.method_1029();
        var rotation=new class_243(Math.atan2(d.field_1350,Math.hypot(d.field_1352,d.field_1351)),0,Math.atan2(-d.field_1352,d.field_1351));
        return new Limb(palm.method_1020(rotate(new class_243(handX,10,0),rotation)),rotation);
    }
    public static class_243 rotate(class_243 point,class_243 rotation){
        var p=new Matrix4f().rotateZYX((float)rotation.field_1350,(float)rotation.field_1351,(float)rotation.field_1352)
            .transformPosition(new Vector3f((float)point.field_1352,(float)point.field_1351,(float)point.field_1350));
        return new class_243(p.x,p.y,p.z);
    }
    public static float strike(float age){return (float)Math.pow(Math.clamp((age-38)/3,0,1),1.6);}
    private static double smooth(double t){t=Math.clamp(t,0,1);return t*t*(3-2*t);}
    public static float gripWeight(float age){return (float)(Math.clamp(age/6,0,1)*Math.clamp((HeavyPunchRules.RELEASE-age)/2,0,1));}
    private HeavyPunchGrip() { }
}
