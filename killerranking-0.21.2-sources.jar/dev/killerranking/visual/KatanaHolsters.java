package dev.killerranking.visual;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.network.KatanaHolstersPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class KatanaHolsters {
    public static final class_2960 EMPTY = class_2960.method_60656("air");
    public static final class_6862<class_1792> KATANAS = class_6862.method_40092(class_7924.field_41197,KillerRankingMod.id("katanas"));
    private static final Map<UUID,KatanaHolstersPayload> LAST = new HashMap<>();

    public static boolean katana(class_1799 stack) {
        return !stack.method_7960() && (stack.method_31573(KATANAS) || class_7923.field_41178.method_10221(stack.method_7909()).method_12832().contains("katana"));
    }
    public static KatanaHolsterSelection.Slots<class_1799> inventory(class_1657 player) {
        var items = new ArrayList<class_1799>(player.method_31548().field_7547);
        items.addAll(player.method_31548().field_7544);
        return KatanaHolsterSelection.select(items,KatanaHolsters::katana,s -> class_7923.field_41178.method_10221(s.method_7909()).toString());
    }
    private static class_2960 id(class_1799 sword) {
        return sword == null ? EMPTY : class_7923.field_41178.method_10221(sword.method_7909());
    }
    public static KatanaHolstersPayload snapshot(class_1657 player) {
        var slots = inventory(player);
        return new KatanaHolstersPayload(player.method_5667(),id(slots.waist()),id(slots.back()));
    }
    private static void send(class_3222 viewer, KatanaHolstersPayload value) {
        if (ServerPlayNetworking.canSend(viewer,KatanaHolstersPayload.TYPE)) ServerPlayNetworking.send(viewer,value);
    }
    public static void register() {
        EntityTrackingEvents.START_TRACKING.register((entity,viewer) -> {
            if (entity instanceof class_3222 player) send(viewer,snapshot(player));
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler,server) -> LAST.remove(handler.field_14140.method_5667()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> LAST.clear());
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (var player : server.method_3760().method_14571()) {
                var value = snapshot(player);
                if (value.equals(LAST.put(player.method_5667(),value))) continue;
                send(player,value);
                for (var viewer : PlayerLookup.tracking(player)) send(viewer,value);
            }
        });
    }
    private KatanaHolsters() { }
}
