package dev.killerranking.visual;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;

/** Fits one restrained arc instead of reproducing every wrist wobble in the effect. */
public final class WeaponTrailCurve {
    private static final int STEPS=16;

    public static List<BatTrailHistory.Point> smooth(List<BatTrailHistory.Point> raw) {
        if(raw.size()<3) return List.copyOf(raw);
        class_243 start=raw.getFirst().tip(),end=raw.getLast().tip(),chord=end.method_1020(start);
        double length=chord.method_1033(),travel=raw.getLast().distance()-raw.getFirst().distance();
        if(length<.04||travel<.001) return List.of(new BatTrailHistory.Point(raw.getFirst().inner(),start,0),
            new BatTrailHistory.Point(raw.getLast().inner(),end,length));
        class_243 control=class_243.field_1353,span=class_243.field_1353;double weight=0,width=0;
        for(var p:raw) {
            double t=(p.distance()-raw.getFirst().distance())/travel;
            double w=2*t*(1-t);
            control=control.method_1019(p.tip().method_1020(start.method_1021((1-t)*(1-t))).method_1020(end.method_1021(t*t)).method_1021(w));
            weight+=w*w;
            class_243 blade=p.tip().method_1020(p.inner());span=span.method_1019(blade);width+=blade.method_1033();
        }
        control=weight>.00001?control.method_1021(1/weight):start.method_35590(end,.5);
        span=span.method_1021(1d/raw.size());width/=raw.size();
        class_243 direction=chord.method_1021(1/length),relative=control.method_1020(start);
        // A monotonic chord coordinate prevents a small reversal from folding
        // the ribbon back on itself. Bound the bend rather than amplify noise.
        double along=Math.clamp(relative.method_1026(direction)/length,.15,.85);
        class_243 bend=relative.method_1020(direction.method_1021(relative.method_1026(direction)));
        if(bend.method_1033()>length) bend=bend.method_1029().method_1021(length);
        control=start.method_1019(chord.method_1021(along)).method_1019(bend);
        class_243 normal=chord.method_1036(bend);
        if(normal.method_1027()<.000001) normal=chord.method_1036(span);
        boolean planar=normal.method_1027()>.000001;
        if(planar) {
            normal=normal.method_1029();
            if(normal.method_1036(tangent(start,control,end,.5)).method_1026(span)<0) normal=normal.method_1021(-1);
            // Keep the inner edge outside the curve's cusp radius: a wide
            // weapon on a very short arc must not turn its strip inside out.
            class_243 acceleration=end.method_1020(control.method_1021(2)).method_1019(start).method_1021(2);
            double radius=Double.POSITIVE_INFINITY;
            for(int i=0;i<=STEPS;i++) {
                class_243 velocity=tangent(start,control,end,(double)i/STEPS);
                double cross=velocity.method_1036(acceleration).method_1033();
                if(cross>.000001) radius=Math.min(radius,Math.pow(velocity.method_1033(),3)/cross);
            }
            width=Math.min(width,radius*.75);
        }
        class_243 fallback=span.method_1027()>.000001?span.method_1029():raw.getLast().tip().method_1020(raw.getLast().inner()).method_1029();
        var result=new ArrayList<BatTrailHistory.Point>(STEPS+1);
        class_243 previous=null;double distance=0;
        for(int i=0;i<=STEPS;i++) {
            double t=(double)i/STEPS;
            class_243 tip=start.method_1021((1-t)*(1-t)).method_1019(control.method_1021(2*t*(1-t))).method_1019(end.method_1021(t*t));
            class_243 side=planar?normal.method_1036(tangent(start,control,end,t)).method_1029():fallback;
            if(previous!=null) distance+=tip.method_1022(previous);
            result.add(new BatTrailHistory.Point(tip.method_1020(side.method_1021(width)),tip,distance));previous=tip;
        }
        return List.copyOf(result);
    }
    private static class_243 tangent(class_243 a,class_243 c,class_243 b,double t) {
        return c.method_1020(a).method_1021(2*(1-t)).method_1019(b.method_1020(c).method_1021(2*t));
    }
    private WeaponTrailCurve() { }
}
