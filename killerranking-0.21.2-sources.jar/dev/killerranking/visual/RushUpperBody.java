package dev.killerranking.visual;

import net.minecraft.class_243;
import org.joml.Matrix4f;

/** One native-size upper body on the player's exact position and facing. */
public final class RushUpperBody {
    public static final double SEPARATION=0;
    public static class_243 origin(class_243 player,float yaw,float scale){
        return player;
    }
    public static float facing(float yaw){
        return yaw;
    }
    public static Matrix4f root(class_243 player,float yaw,float scale,class_243 position,class_243 rotation){
        var at=origin(player,yaw,scale);float nativeScale=.9375f*scale;
        return new Matrix4f().translation((float)at.field_1352,(float)at.field_1351,(float)at.field_1350)
            .rotateY((float)Math.toRadians(180-facing(yaw)))
            .translate((float)position.field_1352,(float)position.field_1351+.7f,(float)position.field_1350)
            .rotateZYX((float)rotation.field_1350,(float)rotation.field_1351,(float)rotation.field_1352).translate(0,-.7f,0)
            .scale(-nativeScale,-nativeScale,nativeScale).translate(0,-1.501f,0);
    }
    private RushUpperBody(){ }
}
