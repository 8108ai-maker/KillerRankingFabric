package dev.killerranking.visual;
import dev.killerranking.combat.ShoulderStabRules;
import dev.killerranking.visual.HeavyPunchGrip.Limb;
import net.minecraft.class_243;

import static dev.killerranking.visual.HeavyPunchGrip.rotate;

/** Rigid block limbs, a high reverse-grip plunge and a planted wide stance. */
public final class ShoulderStabMotion {
    public static float strike(float age){return (float)Math.pow(Math.clamp((age-6)/2,0,1),1.8);}
    public static WasabariMotion.Pose pose(float age,boolean left){
        double load=smooth(age/4),hit=strike(age),recover=smooth((age-16)/8),weight=1-recover;
        var rotation=new class_243(.03+.12*hit,-.30*load+.48*hit,.07*load-.10*hit).method_1021(weight);
        var hip=new class_243(0,12,0);var torso=new Limb(RushTorso.pivot(hip,rotation),rotation);
        var head=new Limb(torso.pivot(),new class_243(.04+.16*hit,rotation.field_1351*.6,rotation.field_1350*.4));
        var palm=new class_243(-5,12,0).method_35590(new class_243(-6,-8,2),load).method_35590(new class_243(-3,-1,-10),hit).method_35590(new class_243(-5,12,0),recover);
        var shoulder=torso.point(-5,2,0);var right=arm(palm,palm.method_1020(shoulder),-1);
        var braceDir=new class_243(.15,.90,-.4).method_1029();var other=arm(torso.point(5,2,0).method_1019(braceDir.method_1021(10)),braceDir,1);
        double stance=load*weight;
        var rleg=new Limb(new class_243(-2.5,12,-1.5*stance),new class_243(-.14*stance,0,.13*stance));
        var lleg=new Limb(new class_243(2.5,12,1.5*stance),new class_243(.14*stance,0,-.13*stance));
        return left?new WasabariMotion.Pose(mirror(torso),mirror(head),mirror(other),mirror(right),mirror(lleg),mirror(rleg))
            :new WasabariMotion.Pose(torso,head,right,other,rleg,lleg);
    }
    public static WasabariMotion.Pose contact(float age,boolean left,class_243 wound,class_243 direction,float centre){
        return contact(age,left,wound,direction,centre,false);
    }
    public static WasabariMotion.Pose contact(float age,boolean left,class_243 wound,class_243 direction,float centre,boolean firstPerson){
        var base=pose(age,left);direction=direction.method_1029();
        double withdrawal=smooth((age-ShoulderStabRules.WITHDRAW)/3);
        var palm=wound.method_1020(direction.method_1021(SalmosaKnifeGeometry.SKILL_REACH+6*(1-strike(age))+5*withdrawal));
        // The rigid upper arm sits outside the first-person camera. The palm and
        // actual dagger tip still land at the same world-space shoulder contact.
        var shoulder=base.torso().point(left?(firstPerson?18:5):-(firstPerson?18:5),firstPerson?8:2,firstPerson?4:0);
        var knife=arm(palm,palm.method_1020(shoulder),left?centre:-centre);
        double recovery=smooth((age-17)/7);
        var rest=left?base.leftArm():base.rightArm();
        knife=new Limb(knife.pivot().method_35590(rest.pivot(),recovery),knife.rotation().method_35590(rest.rotation(),recovery));
        return new WasabariMotion.Pose(base.torso(),base.head(),left?base.rightArm():knife,left?knife:base.leftArm(),base.rightLeg(),base.leftLeg());
    }
    public static Limb arm(class_243 palm,class_243 direction,double centre){
        var d=direction.method_1029();var rotation=new class_243(Math.atan2(d.field_1350,Math.hypot(d.field_1352,d.field_1351)),0,Math.atan2(-d.field_1352,d.field_1351));
        return new Limb(palm.method_1020(rotate(new class_243(centre,10,0),rotation)),rotation);
    }
    public static WasabariMotion.Pose counterPose(float age,boolean left){
        float sample=age<6?age*4/6:age<10?4+(age-6)/2:age<12?6+age-10:age<20?8+age-12:16+(age-20)*8/6;
        var base=pose(sample,left);double airborne=smooth(age/4)*(1-smooth((age-10)/2));
        var right=new Limb(base.rightLeg().pivot(),base.rightLeg().rotation().method_1031(-.72*airborne,0,0));
        var other=new Limb(base.leftLeg().pivot(),base.leftLeg().rotation().method_1031(.54*airborne,0,0));
        return new WasabariMotion.Pose(base.torso(),base.head(),base.rightArm(),base.leftArm(),left?other:right,left?right:other);
    }
    public static WasabariMotion.Pose counterContact(float age,boolean left,class_243 wound,class_243 direction,class_243 airCatch,float centre,boolean firstPerson){
        var base=counterPose(age,left);var rest=left?base.leftArm():base.rightArm();direction=direction.method_1029();
        var contact=wound.method_1020(direction.method_1021(SalmosaKnifeGeometry.SKILL_REACH));
        var palm=age<6?rest.point(left?centre:-centre,10,0).method_35590(airCatch,smooth((age-4)/2))
            :airCatch.method_35590(contact,Math.pow(Math.clamp((age-10)/2,0,1),1.8));
        palm=palm.method_1020(direction.method_1021(5*smooth((age-20)/3)));
        var shoulder=base.torso().point(left?(firstPerson?18:5):-(firstPerson?18:5),firstPerson?8:2,firstPerson?4:0);
        var hand=arm(palm,palm.method_1020(shoulder),left?centre:-centre);
        double recovery=smooth((age-23)/3);hand=new Limb(hand.pivot().method_35590(rest.pivot(),recovery),hand.rotation().method_35590(rest.rotation(),recovery));
        return new WasabariMotion.Pose(base.torso(),base.head(),left?base.rightArm():hand,left?hand:base.leftArm(),base.rightLeg(),base.leftLeg());
    }
    private static Limb mirror(Limb limb){return new Limb(new class_243(-limb.pivot().field_1352,limb.pivot().field_1351,limb.pivot().field_1350),new class_243(limb.rotation().field_1352,-limb.rotation().field_1351,-limb.rotation().field_1350));}
    private static double smooth(double t){t=Math.clamp(t,0,1);return t*t*(3-2*t);}
    private ShoulderStabMotion(){ }
}
