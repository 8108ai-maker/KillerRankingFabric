package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import net.minecraft.class_8111;

/** Normal attacks cannot overlap skill preparation or execution. Cooldowns and passive buffs do not lock attacks. */
public final class SkillCombatLock {
    public static boolean blocksAttack(class_3222 player) {
        return KillerRankingMod.NEUNGSA_SKILL.active(player)
            || KillerRankingMod.SHOULDER_STAB.active(player)
            || KillerRankingMod.KNIFE_PURSUIT.active(player)
            || KillerRankingMod.HEAVY_PUNCH.locked(player)
            || KillerRankingMod.BISHOP.casting(player)
            || KillerRankingMod.BISHOP_BARRAGE.active(player)
            || KillerRankingMod.RUSH.active(player)
            || KillerRankingMod.CHECKMATE.active(player)
            || KillerRankingMod.ROOK.active(player)
            || KillerRankingMod.ROOK.locked(player)
            || KillerRankingMod.MADNESS_LEAP.active(player)
            || KillerRankingMod.CLEAVE.active(player)
            || KillerRankingMod.PARRY.window(player) > 0;
    }

    /** Preserve scoped skill strikes and delayed effects, while rejecting melee damage from alternate attack paths. */
    public static boolean allowsDamage(class_1309 victim, class_1282 source) {
        if (RushDamage.current(victim) || CheckmateDamage.current(victim)) return true;
        if (source.method_5529() instanceof class_1309 attacker && KillerRankingMod.ROOK.locked(attacker)) return false;
        return !(source.method_5529() instanceof class_3222 player && blocksAttack(player)
            && source.method_49708(class_8111.field_42320) && !BleedingDamage.current(victim));
    }

    private SkillCombatLock() { }
}
