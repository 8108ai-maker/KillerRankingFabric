package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import java.util.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;

/** Brace the caster's own wrist and deliver one rising punch on its animation beat. */
public final class HeavyPunchService {
    private static final class Cast {
        final class_3222 owner;final class_1309 target;final class_243 ownerAt,direction;
        final long started;final float yaw;boolean struck;
        Cast(class_3222 p,class_1309 e){owner=p;target=e;ownerAt=p.method_19538();
            started=now(p);direction=e.method_19538().method_1020(ownerAt).method_18805(1,0,1).method_1029();
            yaw=(float)Math.toDegrees(Math.atan2(-direction.field_1352,direction.field_1350));}
    }
    private final Map<UUID,Cast> casts=new HashMap<>();
    private final Map<UUID,HeavyPunchStatusPayload> sent=new HashMap<>();
    private static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    public static boolean available(class_3222 p){return RushService.branch(p)&&RushState.get(p).unlocked();}
    private static boolean eligible(class_3222 p){return available(p)&&p.method_5805()&&!p.method_7325()&&TraitActivation.enabled(p)
        &&p.method_6047().method_31574(KillerRankingMod.TTEOKBAL_FIST)&&!p.method_6115()&&!p.method_5765();}
    public boolean active(class_3222 p){return casts.containsKey(p.method_5667());}
    public boolean captured(class_1297 e){return false;}
    public boolean locked(class_1297 e){return !e.method_37908().field_9236&&casts.containsKey(e.method_5667());}
    public int remaining(class_3222 p){var c=casts.get(p.method_5667());return c==null?0:(int)Math.clamp(HeavyPunchRules.DURATION-(now(p)-c.started),0,HeavyPunchRules.DURATION);}
    public class_1309 selected(class_3222 p){
        var eye=p.method_33571();var end=eye.method_1019(p.method_5720().method_1021(HeavyPunchRules.REACH));
        return p.method_51469().method_8390(class_1309.class,p.method_5829().method_1014(HeavyPunchRules.REACH),e->
            e!=p&&e.method_5805()&&!e.method_31481()&&!e.method_7325()&&e.method_5732()&&!e.method_5765()&&!e.method_5782()
            &&!p.method_5722(e)&&p.method_18395(e)&&!KillerRankingMod.ROOK.locked(e)
            &&!(e instanceof class_3222 other&&other.method_7337())&&p.method_6057(e)
            &&p.method_5858(e)<=HeavyPunchRules.REACH*HeavyPunchRules.REACH
            &&e.method_5829().method_1014(.15).method_992(eye,end).isPresent())
            .stream().min(Comparator.comparingDouble(p::method_5858)).orElse(null);
    }
    public void start(class_3222 p){
        if(!eligible(p)||SkillCombatLock.blocksAttack(p)||HeavyPunchState.get(p).cooldown(now(p))>0)return;
        var target=selected(p);
        if(target==null){p.method_7353(class_2561.method_43470("§7강타: 2.4m 안의 상대를 바라보세요."),true);return;}
        var direction=target.method_19538().method_1020(p.method_19538()).method_18805(1,0,1).method_1029();
        if(direction.method_1027()<.9)return;
        var cast=new Cast(p,target);casts.put(p.method_5667(),cast);
        HeavyPunchState.set(p,HeavyPunchState.get(p).cast(now(p)));freeze(cast);broadcast(cast,false);sync(p);
    }
    private static void position(class_1309 e,class_243 at){
        e.method_18799(class_243.field_1353);e.field_6017=0;
        if(e.method_19538().method_1025(at)>.0001){
            if(e instanceof class_3222 p)p.method_48105(p.method_51469(),at.field_1352,at.field_1351,at.field_1350,Set.of(class_2709.field_12397,class_2709.field_12401),p.method_36454(),p.method_36455());
            else e.method_5859(at.field_1352,at.field_1351,at.field_1350);
        }
    }
    private static void freeze(Cast c){position(c.owner,c.ownerAt);}
    private static boolean valid(Cast c){return eligible(c.owner)&&!c.owner.method_31481()&&c.owner.method_37908()==c.target.method_37908()
        &&c.owner.method_19538().method_1025(c.ownerAt)<4&&(c.struck||c.target.method_5805()&&!c.target.method_31481()&&!c.target.method_5765()
        &&!c.target.method_7325()&&!(c.target instanceof class_3222 p&&p.method_7337()));}
    public void refresh(class_3222 p){var c=casts.get(p.method_5667());if(c!=null&&!valid(c))cancel(p);}
    public void tick(MinecraftServer server){
        for(var p:server.method_3760().method_14571()){
            refresh(p);var c=casts.get(p.method_5667());
            if(c!=null){int age=(int)(now(p)-c.started);
                if(age>=HeavyPunchRules.DURATION)cancel(p);
                else {freeze(c);
                    if(age==HeavyPunchRules.SPLASH)sound(c,dev.killerranking.KillerRankingSounds.HEAVY_PUNCH_CHARGE,.9f,1f);
                    if(HeavyPunchRules.contact(age)&&!c.struck)strike(c);
                    if(age%5==0)broadcast(c,false);
                }
            }
            if(server.method_3780()%2==0)sync(p);
        }
    }
    private void strike(Cast c){
        c.struck=true;
        var offset=c.target.method_19538().method_1020(c.ownerAt).method_18805(1,0,1);
        boolean hit=c.target.method_5805()&&!c.target.method_31481()&&c.owner.method_6057(c.target)
            &&c.owner.method_5858(c.target)<=HeavyPunchRules.REACH*HeavyPunchRules.REACH
            &&offset.method_1029().method_1026(c.direction)>.65&&RushDamage.hit(c.owner,c.target,HeavyPunchRules.DAMAGE,true);
        sound(c,hit?dev.killerranking.KillerRankingSounds.HEAVY_PUNCH_IMPACT:dev.killerranking.KillerRankingSounds.SWING_FIST,1.1f,hit?1f:.7f);
        if(hit){var at=c.target.method_33571().method_1031(0,-.12,0);
            c.owner.method_51469().method_14199(class_2398.field_11205,at.field_1352,at.field_1351,at.field_1350,14,.15,.18,.15,.18);
            c.owner.method_51469().method_14199(class_2398.field_11236,at.field_1352,at.field_1351,at.field_1350,1,0,0,0,0);
            KillerRankingMod.ROOK.launchTarget(c.owner,c.target,c.direction);
        }
        broadcast(c,false);
    }
    private static void sound(Cast c,net.minecraft.class_3414 sound,float volume,float pitch){c.owner.method_51469().method_8396(null,c.owner.method_24515(),sound,class_3419.field_15248,volume,pitch);}
    private void broadcast(Cast c,boolean ending){
        var viewers=new HashSet<>(PlayerLookup.tracking(c.owner));viewers.addAll(PlayerLookup.tracking(c.target));viewers.add(c.owner);
        if(c.target instanceof class_3222 p)viewers.add(p);
        for(var v:viewers)send(c,v,ending);
    }
    private void send(Cast c,class_3222 v,boolean ending){if(ServerPlayNetworking.canSend(v,HeavyPunchVisualPayload.TYPE))
        ServerPlayNetworking.send(v,new HeavyPunchVisualPayload(c.owner.method_5667(),c.target.method_5628(),ending?0:remaining(c.owner),(int)Math.clamp(now(c.owner)-c.started,0,HeavyPunchRules.DURATION),c.yaw));}
    public void send(class_3222 p,class_3222 v){var c=casts.get(p.method_5667());if(c!=null)send(c,v,false);}
    public void cancel(class_3222 p){var c=casts.remove(p.method_5667());if(c!=null){broadcast(c,true);sync(p);}}
    public void forget(class_1297 e){for(var c:new ArrayList<>(casts.values()))if(c.owner==e||c.target==e)cancel(c.owner);sent.remove(e.method_5667());}
    public void clear(){casts.clear();sent.clear();}
    public void sync(class_3222 p){var value=new HeavyPunchStatusPayload(available(p),remaining(p),HeavyPunchState.get(p).cooldown(now(p)));
        if(!value.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,HeavyPunchStatusPayload.TYPE)){ServerPlayNetworking.send(p,value);sent.put(p.method_5667(),value);}}
}
