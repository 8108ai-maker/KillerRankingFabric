package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import java.util.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.phys.*;

public final class NeungsaSkillService {
    private record Cast(class_3222 owner,long started,class_243 origin,class_243 direction,class_1799 weapon,class_5321<class_1937> dimension) { }
    private final Map<UUID,Cast> casts=new HashMap<>();
    private final Map<UUID,Cast> echoes=new HashMap<>();
    private static final class Iaido {
        final class_3222 owner;final class_1799 weapon;final class_5321<class_1937> dimension;
        final Set<UUID> hits=new HashSet<>();
        long started;int phase=NeungsaIaidoRules.CHARGING;boolean full,blocked;
        class_243 origin,direction,feet;double travelled;
        Iaido(class_3222 p){owner=p;weapon=p.method_6047();dimension=p.method_37908().method_27983();started=now(p);origin=p.method_33571().method_1031(0,-.30,0);direction=p.method_5720().method_1029();feet=p.method_19538();}
    }
    private final Map<UUID,Iaido> iaidos=new HashMap<>();
    private final Map<UUID,NeungsaStatusPayload> sent=new HashMap<>();
    private static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    public static boolean branch(class_3222 p){return PlayerProfiles.get(p).trait()==Trait.POISON_AURA;}
    public static boolean available(class_3222 p){return branch(p)&&NeungsaSkillState.get(p).unlocked();}
    private static boolean eligible(class_3222 p){return available(p)&&TraitActivation.enabled(p)&&p.method_5805()&&!p.method_7325()
        &&!p.method_31481()&&!p.method_5765()&&!p.method_6115()&&p.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA)
        &&!KillerRankingMod.ROOK.locked(p)&&!KillerRankingMod.WASABARI.locked(p);}
    public void request(class_3222 p,NeungsaRequestPayload request){
        switch(request.operation()){case NeungsaRequestPayload.START->start(p);case NeungsaRequestPayload.ECHO->echo(p);case NeungsaRequestPayload.UNLOCK->unlock(p);case NeungsaRequestPayload.IAIDO->chargeIaido(p);case NeungsaRequestPayload.IAIDO_RELEASE->releaseIaido(p);case NeungsaRequestPayload.IAIDO_CANCEL->cancelIaido(p);default->{ }}
    }
    public void unlock(class_3222 p){
        if(!branch(p)||!p.method_5805()||p.method_7325()||SkillCombatLock.blocksAttack(p))return;
        var state=NeungsaSkillState.get(p);if(state.unlocked()){sync(p);return;}
        var profile=PlayerProfiles.get(p);
        if(profile.pointUnits()<KillerPoints.whole(NeungsaSlashRules.COST)){
            dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c능사 해금에는 1,000포인트가 필요합니다."));sync(p);return;
        }
        PlayerProfiles.set(p,profile.addPoints(-NeungsaSlashRules.COST));dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_PURCHASE,1f,1f);NeungsaSkillState.set(p,state.owned());
        KillerRankingMod.assignAndSync(p);
        p.method_43496(class_2561.method_43470("§5능사 해금 완료! 능사 카타나: Z 무형참격 / X 발도술 / C 연속참격"));
    }
    public void start(class_3222 p){
        if(!eligible(p)||SkillCombatLock.blocksAttack(p)||NeungsaSkillState.get(p).cooldown(now(p))>0)return;
        var direction=p.method_5720().method_1029();if(direction.method_1027()<.9)return;
        var cast=new Cast(p,now(p),p.method_33571().method_1031(0,-.30,0),direction,p.method_6047(),p.method_37908().method_27983());
        casts.put(p.method_5667(),cast);NeungsaSkillState.set(p,NeungsaSkillState.get(p).cast(now(p)));
        broadcast(cast,false);sync(p);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.NEUNGSA_SLASH_CAST,class_3419.field_15248,1f,1f);
    }
    public boolean active(class_3222 p){return casts.containsKey(p.method_5667())||iaidos.containsKey(p.method_5667())||echoes.containsKey(p.method_5667());}
    public void echo(class_3222 p){
        if(!eligible(p)||SkillCombatLock.blocksAttack(p)||NeungsaSkillState.get(p).echoCooldown(now(p))>0)return;
        var direction=p.method_5720().method_1029();if(direction.method_1027()<.9)return;
        var c=new Cast(p,now(p),p.method_33571().method_1031(0,-.30,0),direction,p.method_6047(),p.method_37908().method_27983());
        echoes.put(p.method_5667(),c);NeungsaSkillState.set(p,NeungsaSkillState.get(p).echo(now(p)));
        broadcastEcho(c,false);sync(p);
    }
    public int echoRemaining(class_3222 p){var c=echoes.get(p.method_5667());return c==null?0:NeungsaEchoRules.remaining(c.started(),now(p));}
    private void broadcastEcho(Cast c,boolean end){var viewers=new HashSet<>(PlayerLookup.tracking(c.owner()));viewers.add(c.owner());for(var v:viewers)sendEcho(c,v,end);}
    private void sendEcho(Cast c,class_3222 viewer,boolean end){
        if(ServerPlayNetworking.canSend(viewer,NeungsaEchoVisualPayload.TYPE))ServerPlayNetworking.send(viewer,new NeungsaEchoVisualPayload(c.owner().method_5667(),(int)Math.clamp(now(c.owner())-c.started(),0,NeungsaEchoRules.DURATION),end?0:echoRemaining(c.owner()),c.origin().field_1352,c.origin().field_1351,c.origin().field_1350,(float)c.direction().field_1352,(float)c.direction().field_1351,(float)c.direction().field_1350));
    }
    private static void strikeEcho(Cast c,int age){
        var p=c.owner();var level=p.method_51469();var start=c.origin();var end=start.method_1019(c.direction().method_1021(NeungsaEchoRules.REACH));
        var wall=level.method_17742(new class_3959(start,end,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
        double reach=wall.method_17783()==class_239.class_240.field_1332?start.method_1022(wall.method_17784()):NeungsaEchoRules.REACH;
        for(var e:level.method_8390(class_1309.class,new class_238(start,end).method_1014(NeungsaEchoRules.HALF_WIDTH),e->enemy(p,e))){
            var b=e.method_5829();var entry=NeungsaSlashRules.entry(start,c.direction(),b,reach,NeungsaEchoRules.HALF_WIDTH,NeungsaEchoRules.HALF_HEIGHT);
            if(entry.isEmpty())continue;
            var line=start.method_1019(c.direction().method_1021(entry.getAsDouble()));
            var hit=new class_243(Math.clamp(line.field_1352,b.field_1323,b.field_1320),Math.clamp(line.field_1351,b.field_1322,b.field_1325),Math.clamp(line.field_1350,b.field_1321,b.field_1324));
            var obstruction=level.method_17742(new class_3959(start,hit,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
            if(obstruction.method_17783()==class_239.class_240.field_1332&&start.method_1022(obstruction.method_17784())+.001<start.method_1022(hit))continue;
            if(!RushDamage.hit(p,e,NeungsaEchoRules.DAMAGE,age==NeungsaEchoRules.FINAL_HIT))continue;
            var viewers=new HashSet<>(PlayerLookup.tracking(e));viewers.add(p);if(e instanceof class_3222 target)viewers.add(target);
            for(var v:viewers)if(ServerPlayNetworking.canSend(v,NeungsaCutEffectPayload.TYPE))ServerPlayNetworking.send(v,new NeungsaCutEffectPayload(e.method_5628(),e.method_5667()));
        }
        boolean big=age==NeungsaEchoRules.OPEN_HIT||age==NeungsaEchoRules.FINAL_HIT;
        level.method_8396(null,p.method_24515(),big?dev.killerranking.KillerRankingSounds.NEUNGSA_BIG_CUT:dev.killerranking.KillerRankingSounds.NEUNGSA_ECHO_CUT,class_3419.field_15248,big?1f:.55f,big?1f:.95f+(age%6)*.04f);
    }
    public void chargeIaido(class_3222 p){
        if(!eligible(p)||SkillCombatLock.blocksAttack(p)||NeungsaSkillState.get(p).iaidoCooldown(now(p))>0)return;
        var c=new Iaido(p);iaidos.put(p.method_5667(),c);broadcastIaido(c,false);sync(p);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.NEUNGSA_SHEATHE,class_3419.field_15248,.8f,1f);
    }
    /** Immediate short draw remains available to the existing server-side combat regression fixture. */
    public void iaido(class_3222 p){chargeIaido(p);releaseIaido(p);}
    public void releaseIaido(class_3222 p){
        var c=iaidos.get(p.method_5667());if(c==null||c.phase!=NeungsaIaidoRules.CHARGING)return;
        if(!valid(c)||NeungsaSkillState.get(p).iaidoCooldown(now(p))>0){cancelIaido(p);return;}
        c.full=NeungsaIaidoRules.full(now(p)-c.started);c.phase=NeungsaIaidoRules.SLASHING;c.started=now(p);
        c.origin=p.method_33571().method_1031(0,-.30,0);c.feet=p.method_19538();c.direction=p.method_5720().method_1029();
        NeungsaSkillState.set(p,NeungsaSkillState.get(p).iaido(now(p)));
        broadcastIaido(c,false);sync(p);KillerRankingMod.COMBAT_STATUS.sync(p);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.NEUNGSA_IAIDO,class_3419.field_15248,c.full?1.1f:.8f,c.full?1f:1.15f);
    }
    public int iaidoPhase(class_3222 p){var c=iaidos.get(p.method_5667());return c==null?0:c.phase;}
    public int iaidoAge(class_3222 p){var c=iaidos.get(p.method_5667());return c==null?0:(int)Math.clamp(now(p)-c.started,0,NeungsaIaidoRules.MAX_HOLD);}
    public boolean dashing(class_3222 p){var c=iaidos.get(p.method_5667());return c!=null&&c.full&&c.phase==NeungsaIaidoRules.SLASHING&&iaidoAge(p)<=NeungsaIaidoRules.DASH_TICKS;}
    public int iaidoRemaining(class_3222 p){var c=iaidos.get(p.method_5667());return c==null||c.phase!=NeungsaIaidoRules.SLASHING||!valid(c)?0:NeungsaIaidoRules.remaining(c.started,now(p));}
    public boolean iaidoActive(class_3222 p){return iaidoRemaining(p)>0;}
    public int remaining(class_3222 p){var c=casts.get(p.method_5667());return c==null?0:(int)Math.clamp(NeungsaSlashRules.DURATION-(now(p)-c.started()),0,NeungsaSlashRules.DURATION);}
    private static boolean valid(Cast c){return eligible(c.owner())&&c.dimension().equals(c.owner().method_37908().method_27983())&&c.weapon()==c.owner().method_6047();}
    private static boolean valid(Iaido c){return eligible(c.owner)&&c.dimension.equals(c.owner.method_37908().method_27983())&&c.weapon==c.owner.method_6047();}
    public void refresh(class_3222 p){var c=casts.get(p.method_5667());var i=iaidos.get(p.method_5667());var e=echoes.get(p.method_5667());if(c!=null&&!valid(c)||i!=null&&!valid(i)||e!=null&&!valid(e))cancel(p);}
    public void tick(MinecraftServer server){
        for(var c:new ArrayList<>(echoes.values())){
            var p=c.owner();int age=(int)(now(p)-c.started());
            if(!valid(c)||age>=NeungsaEchoRules.DURATION){cancel(p);continue;}
            if(NeungsaEchoRules.hit(age))strikeEcho(c,age);
            if(age%5==0)broadcastEcho(c,false);
        }
        for(var c:new ArrayList<>(iaidos.values())){
            var p=c.owner;int age=iaidoAge(p);
            if(!valid(c)){cancelIaido(p);continue;}
            if(c.phase==NeungsaIaidoRules.CHARGING){
                if(age>=NeungsaIaidoRules.MAX_HOLD){cancelIaido(p);continue;}
                if(age==NeungsaIaidoRules.CHARGE)p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.NEUNGSA_CHARGE,class_3419.field_15248,.9f,1f);
            }else{
                if(age>=NeungsaIaidoRules.DURATION){cancelIaido(p);continue;}
                if(c.full&&age>0&&age<=NeungsaIaidoRules.DASH_TICKS){
                    if(!c.blocked){
                        var before=p.method_19538();var step=c.direction.method_1021(NeungsaIaidoRules.DASH/NeungsaIaidoRules.DASH_TICKS);
                        p.method_5784(class_1313.field_6308,step);c.blocked=p.method_19538().method_1020(before).method_1026(c.direction)<step.method_1033()-.03;
                        c.travelled=Math.clamp(p.method_19538().method_1020(c.feet).method_1026(c.direction),0,NeungsaIaidoRules.DASH);
                    }
                    p.method_18799(class_243.field_1353);p.field_6017=0;
                    var at=p.method_19538();p.method_48105(p.method_51469(),at.field_1352,at.field_1351,at.field_1350,Set.of(class_2709.field_12401,class_2709.field_12397),p.method_36454(),p.method_36455());
                    if(age>=2)strikeIaido(c,Math.min(NeungsaIaidoRules.DASH,c.travelled+.30));
                }else if(!c.full&&age==NeungsaIaidoRules.HIT)strikeIaido(c,NeungsaIaidoRules.REACH);
            }
            if(age%5==0)broadcastIaido(c,false);
        }
        for(var cast:new ArrayList<>(casts.values())){
            var p=cast.owner();if(!valid(cast)){cancel(p);continue;}
            int age=(int)(now(p)-cast.started());
            if(age>=NeungsaSlashRules.DURATION){cancel(p);continue;}
            if(age==NeungsaSlashRules.HIT)strike(cast);
            if(age%5==0)broadcast(cast,false);
        }
        if(server.method_3780()%2==0)for(var p:server.method_3760().method_14571())sync(p);
    }
    private static boolean enemy(class_3222 p,class_1309 e){return e!=p&&e.method_5805()&&!e.method_7325()&&e.method_5732()
        &&!p.method_5722(e)&&p.method_18395(e)&&!(e instanceof class_3222 v&&(v.method_7337()||!p.method_7256(v)));}
    private static void strike(Cast c){
        var p=c.owner();var level=p.method_51469();var start=c.origin();var end=start.method_1019(c.direction().method_1021(NeungsaSlashRules.REACH));
        var first=level.method_17742(new class_3959(start,end,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
        double limit=first.method_17783()==class_239.class_240.field_1332?start.method_1022(first.method_17784()):NeungsaSlashRules.REACH;
        // Resolve impacts against the original wall before removing its surface. No same-cast damage through that wall.
        var box=new class_238(start,end).method_1014(NeungsaSlashRules.HALF_WIDTH);
        for(var e:level.method_8390(class_1309.class,box,e->enemy(p,e))){
            var bounds=e.method_5829();var entry=NeungsaSlashRules.entry(start,c.direction(),bounds,limit);
            if(entry.isEmpty())continue;
            var centerline=start.method_1019(c.direction().method_1021(entry.getAsDouble()));
            var hit=new class_243(Math.clamp(centerline.field_1352,bounds.field_1323,bounds.field_1320),Math.clamp(centerline.field_1351,bounds.field_1322,bounds.field_1325),Math.clamp(centerline.field_1350,bounds.field_1321,bounds.field_1324));
            var obstruction=level.method_17742(new class_3959(start,hit,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
            if(obstruction.method_17783()==class_239.class_240.field_1332&&start.method_1022(obstruction.method_17784())+.001<start.method_1022(hit))continue;
            if(RushDamage.hit(p,e,NeungsaSlashRules.DAMAGE,true)){
                level.method_14199(class_2398.field_11205,hit.field_1352,hit.field_1351,hit.field_1350,5,.08,.08,.08,.025);
                level.method_8396(null,e.method_24515(),dev.killerranking.KillerRankingSounds.HIT_BLADE,class_3419.field_15248,.8f,1.1f);
            }
        }
        if(first.method_17783()==class_239.class_240.field_1332&&p.method_7294()){
            for(var pos:NeungsaSlashRules.surface(first.method_17777(),first.method_17780(),c.direction())){
                var state=level.method_8320(pos);
                if(state.method_26215()||!state.method_26227().method_15769()||state.method_31709()||state.method_26214(level,pos)<0
                    ||!level.method_8505(p,pos)||!p.method_7343(pos,first.method_17780(),c.weapon()))continue;
                // Only exposed cells on the original contact plane; no tucked-away neighbouring cell.
                var facePoint=class_243.method_24953(pos).method_1019(class_243.method_24954(first.method_17780().method_10163()).method_1021(.501));
                var visible=level.method_17742(new class_3959(start,facePoint,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
                if(visible.method_17783()==class_239.class_240.field_1332&&!visible.method_17777().equals(pos))continue;
                level.method_8651(pos,true,p);
            }
        }
    }
    private static void strikeIaido(Iaido c,double reach){
        var p=c.owner;var level=p.method_51469();var start=c.origin;var end=start.method_1019(c.direction.method_1021(reach));
        var wall=level.method_17742(new class_3959(start,end,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
        double limit=wall.method_17783()==class_239.class_240.field_1332?start.method_1022(wall.method_17784()):reach;
        double width=c.full?NeungsaIaidoRules.DASH_HALF_WIDTH:NeungsaIaidoRules.HALF_WIDTH;
        for(var e:level.method_8390(class_1309.class,new class_238(start,end).method_1014(Math.max(width,NeungsaIaidoRules.HALF_HEIGHT)),e->enemy(p,e)&&!c.hits.contains(e.method_5667()))){
            var b=e.method_5829();var d=NeungsaSlashRules.entry(start,c.direction,b,limit,width,NeungsaIaidoRules.HALF_HEIGHT);
            if(d.isEmpty())continue;
            var line=start.method_1019(c.direction.method_1021(d.getAsDouble()));
            var hit=new class_243(Math.clamp(line.field_1352,b.field_1323,b.field_1320),Math.clamp(line.field_1351,b.field_1322,b.field_1325),Math.clamp(line.field_1350,b.field_1321,b.field_1324));
            var obstruction=level.method_17742(new class_3959(start,hit,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
            if(obstruction.method_17783()==class_239.class_240.field_1332&&start.method_1022(obstruction.method_17784())+.001<start.method_1022(hit))continue;
            c.hits.add(e.method_5667());if(!RushDamage.hit(p,e,NeungsaIaidoRules.damage(c.full),true))continue;
            var viewers=new HashSet<>(PlayerLookup.tracking(e));viewers.add(p);if(e instanceof class_3222 target)viewers.add(target);
            for(var viewer:viewers)if(ServerPlayNetworking.canSend(viewer,NeungsaCutEffectPayload.TYPE))ServerPlayNetworking.send(viewer,new NeungsaCutEffectPayload(e.method_5628(),e.method_5667()));
            level.method_8396(null,e.method_24515(),dev.killerranking.KillerRankingSounds.HIT_BLADE,class_3419.field_15248,.85f,1.2f);
        }
    }
    private void sendIaido(Iaido c,class_3222 viewer,boolean end){
        // The cast may already be removed when its final visual packet is sent.
        int age=(int)Math.clamp(now(c.owner)-c.started,0,NeungsaIaidoRules.MAX_HOLD),remaining=c.phase==NeungsaIaidoRules.CHARGING?NeungsaIaidoRules.MAX_HOLD-age:Math.max(0,NeungsaIaidoRules.DURATION-age);
        if(ServerPlayNetworking.canSend(viewer,NeungsaIaidoVisualPayload.TYPE))ServerPlayNetworking.send(viewer,new NeungsaIaidoVisualPayload(c.owner.method_5667(),age,end?0:remaining,end?0:c.phase,c.full,c.feet.field_1352,c.feet.field_1351,c.feet.field_1350,(float)c.direction.field_1352,(float)c.direction.field_1351,(float)c.direction.field_1350));
    }
    private void broadcastIaido(Iaido c,boolean end){var viewers=new HashSet<>(PlayerLookup.tracking(c.owner));viewers.add(c.owner);for(var v:viewers)sendIaido(c,v,end);}
    private void cancelIaido(class_3222 p){var c=iaidos.remove(p.method_5667());if(c!=null){broadcastIaido(c,true);KillerRankingMod.COMBAT_STATUS.sync(p);}sync(p);}
    public void cancel(class_3222 p){var echo=echoes.remove(p.method_5667());if(echo!=null)broadcastEcho(echo,true);var c=casts.remove(p.method_5667());if(c!=null)broadcast(c,true);cancelIaido(p);sync(p);}
    public void forget(class_1297 e){if(e instanceof class_3222 p)cancel(p);sent.remove(e.method_5667());}
    public void clear(){for(var c:new ArrayList<>(echoes.values()))cancel(c.owner());echoes.clear();for(var c:new ArrayList<>(casts.values()))cancel(c.owner());for(var c:new ArrayList<>(iaidos.values()))cancel(c.owner);casts.clear();iaidos.clear();sent.clear();}
    private void broadcast(Cast c,boolean ending){var viewers=new HashSet<>(PlayerLookup.tracking(c.owner()));viewers.add(c.owner());for(var v:viewers)send(c,v,ending);}
    private void send(Cast c,class_3222 viewer,boolean ending){
        if(ServerPlayNetworking.canSend(viewer,NeungsaSlashVisualPayload.TYPE))ServerPlayNetworking.send(viewer,
            new NeungsaSlashVisualPayload(c.owner().method_5667(),(int)Math.clamp(now(c.owner())-c.started(),0,NeungsaSlashRules.DURATION),ending?0:remaining(c.owner())));
    }
    public void send(class_3222 p,class_3222 viewer){var echo=echoes.get(p.method_5667());if(echo!=null)sendEcho(echo,viewer,false);var c=casts.get(p.method_5667());if(c!=null)send(c,viewer,false);var i=iaidos.get(p.method_5667());if(i!=null)sendIaido(i,viewer,false);}
    public void sync(class_3222 p){
        var state=NeungsaSkillState.get(p);var status=new NeungsaStatusPayload(branch(p),state.unlocked(),remaining(p),state.cooldown(now(p)),iaidoRemaining(p),state.iaidoCooldown(now(p)),iaidoPhase(p),iaidoAge(p),echoRemaining(p),state.echoCooldown(now(p)));
        if(!status.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,NeungsaStatusPayload.TYPE)){ServerPlayNetworking.send(p,status);sent.put(p.method_5667(),status);}
    }
}
