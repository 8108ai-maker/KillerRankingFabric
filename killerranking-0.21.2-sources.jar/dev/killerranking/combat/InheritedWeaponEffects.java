package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.PlayerProfiles;
import dev.killerranking.data.TraitActivation;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/** Shared cadence for the inherited knife/hatchet pair, in either hand order. */
public final class InheritedWeaponEffects {
    public static final class_2960 SPEED_ID = class_2960.method_60655("killerranking", "madness_inherited_weapons");
    public static final double PAIRED_WEAPON_SPEED = -2.2; // Player base 4 + weapon modifier = 1.8.
    public static final double PAIRED_SPEED_MULTIPLIER = 0.8;
    public static final double DAMAGE_MULTIPLIER = 1.3;
    public static final int SPEED_BONUS = 20;
    private static final ThreadLocal<class_1657> SWAPPED_PAIR = new ThreadLocal<>();

    public static boolean paired(class_1657 player) {
        return SWAPPED_PAIR.get() == player || paired(player.method_6047(), player.method_6079());
    }

    public static boolean paired(class_1799 main, class_1799 off) {
        return main.method_31574(KillerRankingMod.GOSSI_INHERITED_KNIFE) && off.method_31574(KillerRankingMod.EUNBAL_HATCHET)
            || main.method_31574(KillerRankingMod.EUNBAL_HATCHET) && off.method_31574(KillerRankingMod.GOSSI_INHERITED_KNIFE);
    }

    /** Better Combat temporarily puts the off-hand stack in both inventory slots. */
    public static Runnable preservePair(class_1657 player, Runnable action) {
        if (!paired(player)) return action;
        return () -> {
            class_1657 previous = SWAPPED_PAIR.get();
            SWAPPED_PAIR.set(player);
            try { action.run(); }
            finally {
                if (previous == null) SWAPPED_PAIR.remove(); else SWAPPED_PAIR.set(previous);
            }
        };
    }

    public static boolean madnessBonus(class_3222 player) {
        return player.method_5805() && !player.method_7325() && TraitActivation.enabled(player)
            && PlayerProfiles.get(player).trait() == Trait.MIXED_MADNESS && paired(player);
    }

    public static void refresh(class_3222 player) {
        applySpeedBonus(player.method_5996(class_5134.field_23723), madnessBonus(player));
    }

    public static void applySpeedBonus(class_1324 attribute, boolean enabled) {
        if (attribute == null) return;
        var previous = attribute.method_6199(SPEED_ID);
        if (!enabled) {
            if (previous != null) attribute.method_6200(SPEED_ID);
        } else if (previous == null || previous.comp_2449() != SPEED_BONUS / 100.0) {
            attribute.method_55696(new class_1322(SPEED_ID, SPEED_BONUS / 100.0,
                class_1322.class_1323.field_6331));
        }
    }

    /** Average the pair, retain existing modifiers, then reduce its shared cadence by 20%. */
    public static double pairedSpeed(class_1324 attribute) {
        double base = attribute.method_6201() + PAIRED_WEAPON_SPEED;
        for (var modifier : attribute.method_6195()) {
            if (!modifier.comp_2447().equals(class_1792.field_8001)
                && modifier.comp_2450() == class_1322.class_1323.field_6328) base += modifier.comp_2449();
        }
        double result = base;
        for (var modifier : attribute.method_6195()) {
            if (!modifier.comp_2447().equals(class_1792.field_8001)
                && modifier.comp_2450() == class_1322.class_1323.field_6330) result += base * modifier.comp_2449();
        }
        for (var modifier : attribute.method_6195()) {
            if (!modifier.comp_2447().equals(class_1792.field_8001)
                && modifier.comp_2450() == class_1322.class_1323.field_6331) result *= 1 + modifier.comp_2449();
        }
        return attribute.method_6198().comp_349().method_6165(result * PAIRED_SPEED_MULTIPLIER);
    }

    private InheritedWeaponEffects() { }
}
