package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import java.util.Comparator;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3222;

/** The client preview and server confirmation use the same eye ray and range rules. */
public final class ShoulderStabTargeting {
    public static boolean enemy(class_1657 p,class_1309 e) {
        return e!=p&&e.method_5805()&&!e.method_7325()&&e.method_5732()&&!e.method_5765()
            &&!p.method_5722(e)&&p.method_18395(e)&&!(e instanceof class_1657 other&&(other.method_7337()
            ||p instanceof class_3222 server&&!server.method_7256(other)))
            &&(!(p instanceof class_3222)||!KillerRankingMod.ROOK.locked(e));
    }
    public static class_1309 selected(class_1657 p) {
        var eye=p.method_33571();var end=eye.method_1019(p.method_5720().method_1021(ShoulderStabRules.REACH));
        return p.method_37908().method_8390(class_1309.class,p.method_5829().method_1014(ShoulderStabRules.REACH),
            e->enemy(p,e)&&ShoulderStabRules.inRange(p.method_5858(e))&&p.method_6057(e)
                &&e.method_5829().method_1014(.15).method_992(eye,end).isPresent())
            .stream().min(Comparator.comparingDouble(e->e.method_5829().method_1014(.15).method_992(eye,end).orElse(end).method_1025(eye))).orElse(null);
    }
    private ShoulderStabTargeting() { }
}
