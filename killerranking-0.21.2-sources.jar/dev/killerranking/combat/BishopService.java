package dev.killerranking.combat;
import dev.killerranking.*;
import dev.killerranking.data.*;
import dev.killerranking.entity.BishopFollower;
import dev.killerranking.network.*;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.resources.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import java.util.*;

public final class BishopService {
    private static final class_2960 WEAKNESS=KillerRankingMod.id("bishop_personal_damage");
    private static final class Squad {
        final long started,expires,readyAt;final class_5321<class_1937> dimension;final List<UUID> units=new ArrayList<>();final int attackStamp,hurtStamp,level,formationOffset;
        boolean spawned;Squad(class_3222 p,int offset){started=now(p);expires=started+BishopRules.CAST+BishopRules.DURATION;level=PlayerProfiles.get(p).traitLevel();readyAt=started+BishopRules.cooldown(level);formationOffset=offset;dimension=p.method_37908().method_27983();attackStamp=p.method_6083();hurtStamp=p.method_6117();}
    }
    private final Map<UUID,List<Squad>> squads=new HashMap<>();
    private final BishopDesignations designations=new BishopDesignations();
    private final Map<UUID,Long> designationRequests=new HashMap<>();
    public static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    public static boolean branch(class_3222 p){return CleaveService.branch(p);}
    public boolean eligible(class_3222 p){return branch(p)&&BishopState.get(p).unlocked()&&TraitActivation.enabled(p)&&p.method_5805()&&!p.method_7325();}
    public static boolean otherOwned(class_3222 p){return RushState.get(p).unlocked()||CheckmateState.get(p).unlocked()||RookState.get(p).unlocked()||CleaveState.get(p).unlocked();}
    public void request(class_3222 p,BishopRequestPayload r){switch(r.operation()){case BishopRequestPayload.SUMMON->summon(p);case BishopRequestPayload.BARRAGE->KillerRankingMod.BISHOP_BARRAGE.start(p);case BishopRequestPayload.DESIGNATE->designate(p);case BishopRequestPayload.UNLOCK->unlock(p);default->{}}}
    public void unlock(class_3222 p){
        if(!branch(p)||!p.method_5805()||p.method_7325()||KillerRankingMod.ROOK.locked(p))return;
        if(BishopState.get(p).unlocked()){sync(p);return;}
        if(otherOwned(p)){dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c투기 스킬은 하나만 해금할 수 있습니다. 나이트·룩·폰 6·비숍 중 선택하세요."));return;}
        var profile=PlayerProfiles.get(p);
        if(profile.pointUnits()<KillerPoints.whole(BishopRules.COST)){dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c비숍 해금에는 1,000포인트가 필요합니다."));return;}
        PlayerProfiles.set(p,profile.addPoints(-BishopRules.COST));dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_PURCHASE,1f,1f);setOwned(p,true);
        p.method_43496(class_2561.method_43470("§d비숍 해금! Z 신의 부름 / X 상대지정 / C 형제들의 도움"));
    }
    public void setOwned(class_3222 p,boolean owned){
        KillerRankingMod.BISHOP_BARRAGE.cancel(p);
        dismiss(p);
        if(owned){
            KillerRankingMod.ROOK.cancel(p);RookState.set(p,RookState.get(p).owned(false));
            KillerRankingMod.CLEAVE.cancel(p);CleaveState.set(p,CleaveState.get(p).owned(false));
            KillerRankingMod.CHECKMATE.cancel(p);CheckmateState.set(p,CheckmateState.get(p).owned(false));
            KillerRankingMod.RUSH.cancel(p);RushState.set(p,new RushState(false,RushState.get(p).readyAt()));
            SpiritState.set(p,new SpiritState(SpiritState.get(p).branch(),false));
        }
        BishopState.set(p,BishopState.get(p).owned(owned));KillerRankingMod.assignAndSync(p);
    }
    private List<Squad> waves(class_3222 p){return squads.getOrDefault(p.method_5667(),List.of());}
    public boolean casting(class_3222 p){return waves(p).stream().anyMatch(s->!s.spawned);}
    public int count(class_3222 p){return units(p).size();}
    public List<BishopFollower> units(class_3222 p){return waves(p).stream().filter(s->s.dimension.equals(p.method_37908().method_27983())).flatMap(s->s.units.stream()).map(p.method_51469()::method_14190).filter(e->e instanceof BishopFollower&&e.method_5805()).map(e->(BishopFollower)e).toList();}
    public boolean manages(class_3222 p,UUID entity){return waves(p).stream().anyMatch(s->s.dimension.equals(p.method_37908().method_27983())&&s.units.contains(entity));}
    public void designate(class_3222 p){
        if(!eligible(p)||KillerRankingMod.ROOK.locked(p))return;
        // Limit repeated packet work, without tying designation to either skill cooldown.
        if(now(p)-designationRequests.getOrDefault(p.method_5667(),now(p)-4)<4)return;
        designationRequests.put(p.method_5667(),now(p));
        var target=BishopDesignationTargeting.selected(p);
        if(target==null){p.method_7353(class_2561.method_43470("§7바라보는 공격 가능한 대상이 없습니다."),true);return;}
        var old=designations.set(p.method_5667(),target.method_5667(),target.method_37908().method_27983().method_29177().toString());
        if(old!=null&&!old.equals(designations.get(p.method_5667())))releaseEffect(p.field_13995,old);
        target.method_37222(new net.minecraft.class_1293(KillerRankingMod.BISHOP_DESIGNATION,-1,0,false,false,true),p);
        p.method_7353(class_2561.method_43470("§d상대지정: ").method_10852(target.method_5477()),true);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.BISHOP_VANISH,class_3419.field_15248,.6f,.9f);
        sync(p);
    }
    public class_1309 designated(class_3222 p){
        var mark=designations.get(p.method_5667());
        if(!eligible(p)||mark==null||!mark.dimension().equals(p.method_37908().method_27983().method_29177().toString()))return null;
        var entity=p.method_51469().method_14190(mark.target());
        return entity instanceof class_1309 target&&BishopTargets.allowed(p,target)&&target.method_6059(KillerRankingMod.BISHOP_DESIGNATION)?target:null;
    }
    private void releaseEffect(MinecraftServer server,BishopDesignations.Mark mark){
        if(mark==null||designations.used(mark))return;
        for(var level:server.method_3738())if(mark.dimension().equals(level.method_27983().method_29177().toString())){
            var entity=level.method_14190(mark.target());if(entity instanceof class_1309 target)target.method_6016(KillerRankingMod.BISHOP_DESIGNATION);return;
        }
    }
    public void clearDesignation(class_3222 p){releaseEffect(p.field_13995,designations.remove(p.method_5667()));}
    public void targetRemoved(class_1309 target){
        var mark=new BishopDesignations.Mark(target.method_5667(),target.method_37908().method_27983().method_29177().toString());
        for(var owner:designations.owners())if(mark.equals(designations.get(owner))){
            designations.remove(owner);var player=target.method_5682().method_3760().method_14602(owner);if(player!=null)sync(player);
        }
        target.method_6016(KillerRankingMod.BISHOP_DESIGNATION);
    }
    public void cleanOrphanEffect(class_1309 target){
        if(!designations.used(new BishopDesignations.Mark(target.method_5667(),target.method_37908().method_27983().method_29177().toString())))
            target.method_6016(KillerRankingMod.BISHOP_DESIGNATION);
    }
    public void summon(class_3222 p){
        refresh(p);
        if(!eligible(p)||p.method_5765()||p.method_6115()||SkillCombatLock.blocksAttack(p)||p.method_5816()||p.method_5771()||BishopState.get(p).cooldown(now(p))>0||casting(p))return;
        if(count(p)+BishopRules.count(PlayerProfiles.get(p).traitLevel())>BishopRules.MAX_UNITS){p.method_43502(class_2561.method_43470("§c현재 형제들이 모두 전투 중입니다."),true);return;}
        int offset=waves(p).stream().mapToInt(s->s.formationOffset+BishopRules.count(s.level)).max().orElse(0);
        var squad=new Squad(p,offset);squads.computeIfAbsent(p.method_5667(),id->new ArrayList<>()).add(squad);var old=BishopState.get(p);BishopState.set(p,new BishopState(true,squad.readyAt,old.barrageReadyAt()));
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.BISHOP_SUMMON,class_3419.field_15248,1f,1f);sync(p);
    }
    public void effects(class_3222 p){
        var attribute=p.method_5996(class_5134.field_23721);
        if(!eligible(p)){attribute.method_6200(WEAKNESS);return;}
        if(!attribute.method_6196(WEAKNESS))attribute.method_26835(new class_1322(WEAKNESS,BishopRules.PERSONAL_DAMAGE-1,class_1322.class_1323.field_6331));
    }
    public void refresh(class_3222 p){
        effects(p);if(designations.get(p.method_5667())!=null&&designated(p)==null)clearDesignation(p);
        var list=squads.get(p.method_5667());if(list==null)return;
        if(!eligible(p)||list.stream().anyMatch(s->!s.dimension.equals(p.method_37908().method_27983()))){dismiss(p);return;}
        for(var iterator=list.iterator();iterator.hasNext();){var squad=iterator.next();
            if(now(p)>=squad.expires){discard(p,squad);iterator.remove();continue;}
            if(squad.spawned){squad.units.removeIf(id->{var entity=p.method_51469().method_14190(id);return entity==null||!entity.method_5805();});if(squad.units.isEmpty())iterator.remove();}
        }
        if(list.isEmpty())squads.remove(p.method_5667());
    }
    private void spawn(class_3222 p,Squad squad){
        squad.spawned=true;int desired=BishopRules.count(squad.level);
        for(int index=0;index<desired;index++){
            class_243 floor=null;
            for(int attempt=0;attempt<18&&floor==null;attempt++){
                double angle=(index+attempt*.37)*Math.PI/3,radius=1.8+attempt*.12;
                var at=p.method_19538().method_1031(Math.cos(angle)*radius,0,Math.sin(angle)*radius);
                for(int dy=2;dy>=-2;dy--){var pos=class_2338.method_49638(at).method_10069(0,dy,0);var block=p.method_51469().method_8320(pos.method_10074());
                    var candidate=new class_243(at.field_1352,pos.method_10264(),at.field_1350);
                    if(!block.method_26220(p.method_51469(),pos.method_10074()).method_1110()&&p.method_51469().method_8621().method_11952(pos)
                        &&p.method_51469().method_8320(pos).method_26227().method_15769()&&p.method_51469().method_18026(new net.minecraft.class_238(candidate.field_1352-.3,candidate.field_1351,candidate.field_1350-.3,candidate.field_1352+.3,candidate.field_1351+1.9,candidate.field_1350+.3))){floor=candidate;break;}
                }
            }
            if(floor==null)continue;
            var unit=KillerRankingMod.BISHOP_FOLLOWER.method_5883(p.method_51469());if(unit==null)continue;
            unit.summon(p,squad.expires,squad.formationOffset+index,squad.level);unit.armAt(squad.attackStamp,squad.hurtStamp);unit.method_5808(floor.field_1352,floor.field_1351,floor.field_1350,p.method_36454(),0);
            if(p.method_51469().method_8649(unit)){squad.units.add(unit.method_5667());p.method_51469().method_14199(class_2398.field_11249,floor.field_1352,floor.field_1351+.7,floor.field_1350,14,.25,.65,.25,.05);}
        }
        if(squad.units.isEmpty()){var old=BishopState.get(p);if(old.readyAt()==squad.readyAt)BishopState.set(p,new BishopState(true,0,old.barrageReadyAt()));p.method_43502(class_2561.method_43470("§c부하가 설 공간이 없습니다. 넓은 곳에서 사용하세요."),true);}
    }
    public void tick(MinecraftServer server){for(var p:server.method_3760().method_14571()){
        refresh(p);for(var squad:waves(p))if(!squad.spawned&&now(p)-squad.started>=BishopRules.CAST)spawn(p,squad);
        if(server.method_3780()%10==0)sync(p);
    }}
    public void send(class_3222 p,class_3222 viewer){if(ServerPlayNetworking.canSend(viewer,BishopStatusPayload.TYPE))ServerPlayNetworking.send(viewer,status(p));KillerRankingMod.BISHOP_BARRAGE.send(p,viewer);}
    private BishopStatusPayload status(class_3222 p){var state=BishopState.get(p);var list=waves(p);
        int remaining=list.stream().filter(s->s.spawned&&!s.units.isEmpty()).mapToInt(s->(int)Math.clamp(s.expires-now(p),0,BishopRules.DURATION)).min().orElse(0);
        int cast=list.stream().filter(s->!s.spawned).mapToInt(s->(int)Math.clamp(BishopRules.CAST-(now(p)-s.started),0,BishopRules.CAST)).max().orElse(0);
        var target=designated(p);String targetName=target==null?"":target.method_5477().getString();
        return new BishopStatusPayload(p.method_5667(),branch(p),state.unlocked(),otherOwned(p),eligible(p),count(p),remaining,state.cooldown(now(p)),cast,KillerRankingMod.BISHOP_BARRAGE.remaining(p),state.barrageCooldown(now(p)),targetName);}
    public void sync(class_3222 p){var value=status(p);if(ServerPlayNetworking.canSend(p,BishopStatusPayload.TYPE))ServerPlayNetworking.send(p,value);for(var viewer:PlayerLookup.tracking(p))if(ServerPlayNetworking.canSend(viewer,BishopStatusPayload.TYPE))ServerPlayNetworking.send(viewer,value);}
    private void discard(class_3222 p,Squad squad){var level=p.field_13995.method_3847(squad.dimension);if(level!=null)for(var id:squad.units){var e=level.method_14190(id);if(e!=null)e.method_31472();}}
    public void dismiss(class_3222 p){clearDesignation(p);var list=squads.remove(p.method_5667());if(list!=null)for(var squad:list)discard(p,squad);}
    public void forget(class_3222 p){designationRequests.remove(p.method_5667());KillerRankingMod.BISHOP_BARRAGE.cancel(p);dismiss(p);p.method_5996(class_5134.field_23721).method_6200(WEAKNESS);}
    public void clear(MinecraftServer server){for(var p:server.method_3760().method_14571())forget(p);squads.clear();designations.clear();designationRequests.clear();KillerRankingMod.BISHOP_BARRAGE.clear();}
}
