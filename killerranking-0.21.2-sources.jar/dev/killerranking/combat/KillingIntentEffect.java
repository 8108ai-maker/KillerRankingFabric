package dev.killerranking.combat;

import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;

public final class KillingIntentEffect {
	public static final class_2960 ID = class_2960.method_60655("killerranking", "killing_intent_bonus");
	private KillingIntentEffect() { }
	public static void apply(class_1324 attribute, int percent) {
		if (attribute == null) return;
		var previous = attribute.method_6199(ID);
		double amount = percent / 100.0;
		if (amount <= 0) { if (previous != null) attribute.method_6200(ID); }
		else if (previous == null || Double.compare(previous.comp_2449(), amount) != 0) {
			attribute.method_55696(new class_1322(ID, amount, class_1322.class_1323.field_6331));
		}
	}
}
