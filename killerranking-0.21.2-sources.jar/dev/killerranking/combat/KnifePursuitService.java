package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8111;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;
import org.joml.Vector3f;
import java.util.*;

/** One selected target; visual weapon never consumes or duplicates the real inventory item. */
public final class KnifePursuitService {
    private static final UUID NONE=new UUID(0,0);
    private static final class Action {
        final class_3222 owner;final class_1309 target;final class_1799 weapon;
        final long started;final int phase;final class_243 origin,throwOrigin;final float yaw;final class_5321<class_1937> dimension;
        class_243 destination,lastSafe,lastKnife,embeddedAt;boolean embedded,extracted;
        Action(class_3222 p,class_1309 e,int phase,class_243 destination){
            owner=p;target=e;this.phase=phase;this.destination=destination;started=now(p);
            weapon=p.method_6047();dimension=p.method_37908().method_27983();origin=p.method_19538();lastSafe=origin;
            throwOrigin=p.method_33571().method_1031(0,-.2,0);lastKnife=throwOrigin;
            var d=e==null?p.method_5720():e.method_19538().method_1020(origin);
            yaw=(float)Math.toDegrees(Math.atan2(-d.field_1352,d.field_1350));
            embeddedAt=e==null?throwOrigin:embed(e,yaw);
        }
        Action(Action thrown,class_243 at){
            owner=thrown.owner;target=thrown.target;weapon=thrown.weapon;started=now(owner);phase=KnifePursuitRules.DEFLECTED;
            origin=owner.method_19538();throwOrigin=at;lastKnife=at;embeddedAt=at;destination=origin;lastSafe=origin;yaw=thrown.yaw;dimension=thrown.dimension;
        }
    }
    private final Map<UUID,Action> actions=new HashMap<>();
    private final Map<UUID,KnifePursuitStatusPayload> sent=new HashMap<>();
    private static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    public static boolean available(class_3222 p){return SalmosaSkillService.available(p);}
    private static boolean eligible(class_3222 p){return available(p)&&TraitActivation.enabled(p)&&p.method_5805()&&!p.method_31481()&&!p.method_7325()
        &&p.method_6047().method_31574(KillerRankingMod.SALMOSA_MID_DAGGER)&&!p.method_5765()&&!p.method_6115()&&!KillerRankingMod.ROOK.locked(p);}
    public boolean active(class_3222 p){return actions.containsKey(p.method_5667());}
    public boolean casting(class_3222 p){var a=actions.get(p.method_5667());return a!=null&&a.phase==KnifePursuitRules.CAST;}
    public int phase(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:a.phase;}
    public int age(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:(int)(now(p)-a.started);}
    public record Counter(class_1309 target,class_243 knife,class_243 catchKnife){ }
    public Counter counter(class_3222 p){
        var a=actions.get(p.method_5667());if(a==null||a.phase!=KnifePursuitRules.DEFLECTED||!valid(a)||!KnifePursuitRules.counterWindow(age(p)))return null;
        return new Counter(a.target,KnifePursuitRules.deflected(a.throwOrigin,age(p)),KnifePursuitRules.deflected(a.throwOrigin,age(p)+ShoulderStabRules.COUNTER_CATCH));
    }
    public void request(class_3222 p,KnifePursuitRequestPayload request){switch(request.operation()){
        case KnifePursuitRequestPayload.START->start(p);
        case KnifePursuitRequestPayload.RELEASE->release(p,request.target());
        case KnifePursuitRequestPayload.CANCEL->cancel(p);
        default->{ }
    }}
    public void start(class_3222 p){
        if(!eligible(p)||SkillCombatLock.blocksAttack(p)||KnifePursuitState.get(p).cooldown(now(p))>0)return;
        actions.put(p.method_5667(),new Action(p,null,KnifePursuitRules.AIM,p.method_19538()));broadcast(p);sync(p);
    }
    public void release(class_3222 p,int targetId){
        var aim=actions.get(p.method_5667());if(aim==null||aim.phase!=KnifePursuitRules.AIM)return;
        var target=KnifePursuitTargeting.selected(p);
        if(!valid(aim)||target==null||target.method_5628()!=targetId||KnifePursuitState.get(p).cooldown(now(p))>0){cancel(p);return;}
        var destination=landing(p,target);
        if(destination==null||!clearSegment(p,p.method_19538(),destination)){cancel(p);p.method_7353(class_2561.method_43470("§7칼날 추격: 접근 경로에 장애물이 있습니다."),true);return;}
        var action=new Action(p,target,KnifePursuitRules.CAST,destination);
        actions.put(p.method_5667(),action);KnifePursuitState.set(p,KnifePursuitState.get(p).cast(now(p)));broadcast(p);sync(p);
    }
    private static boolean valid(Action a){return eligible(a.owner)&&a.dimension.equals(a.owner.method_37908().method_27983())&&a.weapon==a.owner.method_6047()
        &&(a.phase==KnifePursuitRules.AIM?now(a.owner)-a.started<KnifePursuitRules.MAX_HOLD:
            a.target.method_37908()==a.owner.method_37908()&&KnifePursuitTargeting.enemy(a.owner,a.target)&&!KillerRankingMod.ROOK.locked(a.target)
                &&a.owner.method_5858(a.target)<24*24);}
    public void refresh(class_3222 p){var a=actions.get(p.method_5667());if(a!=null&&!valid(a))cancel(p);}
    public void tick(MinecraftServer server){
        for(var a:new ArrayList<>(actions.values())){
            var p=a.owner;if(!valid(a)){cancel(p);continue;}
            int age=(int)(now(p)-a.started);
            if(a.phase==KnifePursuitRules.DEFLECTED){
                if(age>=KnifePursuitRules.AIR_DURATION){cancel(p);continue;}
                a.embeddedAt=KnifePursuitRules.deflected(a.throwOrigin,age);
            }
            if(a.phase==KnifePursuitRules.CAST){
                if(age>=KnifePursuitRules.DURATION){cancel(p);continue;}
                if(age==KnifePursuitRules.THROW)sound(a,dev.killerranking.KillerRankingSounds.KNIFE_PURSUIT_THROW,.9f,1f);
                if(age>=KnifePursuitRules.THROW&&age<=KnifePursuitRules.IMPACT&&!a.embedded){
                    var at=KnifePursuitRules.flight(a.throwOrigin,embed(a.target,a.yaw),age);
                    if(p.method_51469().method_17742(new class_3959(a.lastKnife,at,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p)).method_17783()!=class_239.class_240.field_1333){cancel(p);continue;}
                    a.lastKnife=at;
                    if(age==KnifePursuitRules.IMPACT){
                        if(a.target instanceof class_3222 defender&&KillerRankingMod.PARRY.tryParryProjectile(defender,p)){
                            actions.put(p.method_5667(),new Action(a,at));broadcast(p);sync(p);continue;
                        }
                        var holder=p.method_56673().method_30530(class_7924.field_42534).method_40290(class_8111.field_42328);
                        if(!RushDamage.hit(p,a.target,new class_1282(holder,p,p),KnifePursuitRules.THROW_DAMAGE,false)){cancel(p);continue;}
                        if(actions.get(p.method_5667())!=a)continue;
                        a.embedded=true;blood(a);sound(a,dev.killerranking.KillerRankingSounds.KNIFE_PURSUIT_EMBED,.9f,1f);broadcast(p);
                    }
                }
                if(age==KnifePursuitRules.BLINK){
                    a.destination=landing(p,a.target);
                    if(!a.embedded||a.destination==null||!clearSegment(p,a.origin,a.destination)){cancel(p);continue;}
                    sound(a,KillerRankingMod.KNIFE_PURSUIT_BLINK,.9f,1);
                    p.method_51469().method_14199(class_2398.field_11203,p.method_23317(),p.method_23318()+.9,p.method_23321(),12,.18,.5,.18,.045);
                    var facing=a.target.method_19538().method_1020(a.destination);
                    p.method_36456((float)Math.toDegrees(Math.atan2(-facing.field_1352,facing.field_1350)));
                    p.field_6283=p.field_6241=p.method_36454();
                    move(p,a.destination);a.lastSafe=a.destination;
                    sound(a,KillerRankingMod.KNIFE_PURSUIT_BLINK,.55f,1.2f);
                    p.method_51469().method_14199(class_2398.field_11203,p.method_23317(),p.method_23318()+.9,p.method_23321(),12,.18,.5,.18,.045);
                    broadcast(p);
                }else if(age<KnifePursuitRules.BLINK)move(p,a.origin);
                else if(age<KnifePursuitRules.EXTRACT)move(p,a.destination);
                if(age==KnifePursuitRules.EXTRACT&&!a.extracted){
                    if(!a.embedded||p.method_5858(a.target)>6.25||!p.method_6057(a.target)){cancel(p);continue;}
                    a.extracted=true;
                    if(RushDamage.hit(p,a.target,KnifePursuitRules.EXTRACT_DAMAGE,false)){
                        if(actions.get(p.method_5667())!=a)continue;
                        KillerRankingMod.WASABARI.hemorrhage(p,a.target,WasabariRules.EFFECT_TICKS);
                        a.weapon.method_7970(2,p,class_1304.field_6173);blood(a);sound(a,dev.killerranking.KillerRankingSounds.HIT_PIERCE,1f,.9f);
                    }
                    broadcast(p);
                }
                a.embeddedAt=embed(a.target,a.yaw);
            }
            if(server.method_3780()%2==0&&actions.get(p.method_5667())==a)broadcast(p);
        }
        if(server.method_3780()%2==0)for(var p:server.method_3760().method_14571())sync(p);
    }
    public static class_243 embed(class_1309 e,float yaw){return e.method_19538().method_1031(0,e.method_17682()*.62,0)
        .method_1020(class_243.method_1030(0,yaw).method_1021(Math.max(.08,e.method_17681()*.5-.07)));}
    private static class_243 landing(class_3222 p,class_1309 e){
        // The destination is in front of the selected enemy, with room for both bodies.
        var away=class_243.method_1030(0,e.method_36454());
        var point=e.method_19538().method_1019(away.method_1021((p.method_17681()+e.method_17681())*.5+.35));
        if(!p.method_51469().method_22340(class_2338.method_49638(point)))return null;
        var hit=p.method_51469().method_17742(new class_3959(point.method_1031(0,1.5,0),point.method_1031(0,-3,0),class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
        if(hit.method_17783()!=class_239.class_240.field_1332||hit.method_17780()!=class_2350.field_11036)return null;
        var at=new class_243(point.field_1352,hit.method_17784().field_1351,point.field_1350);
        return p.method_51469().method_8316(class_2338.method_49638(at.method_1031(0,.01,0))).method_15769()&&clearBox(p,at)?at:null;
    }
    private static boolean clearBox(class_3222 p,class_243 at){return !p.method_51469().method_20812(p,p.method_5829().method_997(at.method_1020(p.method_19538())).method_1011(.001)).iterator().hasNext();}
    private static boolean clearSegment(class_3222 p,class_243 from,class_243 to){int n=Math.max(1,(int)Math.ceil(from.method_1022(to)/.15));for(int i=1;i<=n;i++)if(!clearBox(p,from.method_35590(to,(double)i/n)))return false;return true;}
    private static void move(class_3222 p,class_243 at){p.method_18799(class_243.field_1353);p.field_6017=0;if(p.method_19538().method_1025(at)>.00001)
        p.method_48105(p.method_51469(),at.field_1352,at.field_1351,at.field_1350,Set.of(),p.method_36454(),p.method_36455());}
    private static void blood(Action a){var at=embed(a.target,a.yaw);a.owner.method_51469().method_14199(new class_2390(new Vector3f(.83f,.02f,.06f),1),at.field_1352,at.field_1351,at.field_1350,12,.17,.17,.17,.03);}
    private static void sound(Action a,net.minecraft.class_3414 event,float volume,float pitch){a.owner.method_51469().method_8396(null,a.owner.method_24515(),event,class_3419.field_15248,volume,pitch);}
    public void cancel(class_3222 p){var a=actions.remove(p.method_5667());if(a!=null){p.field_6017=0;send(a,true);sync(p);}}
    public void forget(class_1297 e){for(var a:new ArrayList<>(actions.values()))if(a.owner==e||a.target==e)cancel(a.owner);sent.remove(e.method_5667());}
    public void clear(){for(var a:new ArrayList<>(actions.values()))cancel(a.owner);actions.clear();sent.clear();}
    public void sync(class_3222 p){var a=actions.get(p.method_5667());var status=new KnifePursuitStatusPayload(available(p),a==null?0:a.phase,a==null?0:age(p),KnifePursuitState.get(p).cooldown(now(p)));
        if(!status.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,KnifePursuitStatusPayload.TYPE)){ServerPlayNetworking.send(p,status);sent.put(p.method_5667(),status);}}
    private void broadcast(class_3222 p){var a=actions.get(p.method_5667());if(a!=null)send(a,false);}
    private void send(Action a,boolean ending){var viewers=new HashSet<>(PlayerLookup.tracking(a.owner));viewers.add(a.owner);if(a.target!=null){viewers.addAll(PlayerLookup.tracking(a.target));if(a.target instanceof class_3222 p)viewers.add(p);}for(var viewer:viewers)send(a,viewer,ending);}
    public void send(class_3222 p,class_3222 viewer){var a=actions.get(p.method_5667());if(a!=null)send(a,viewer,false);}
    private void send(Action a,class_3222 viewer,boolean ending){if(ServerPlayNetworking.canSend(viewer,KnifePursuitVisualPayload.TYPE))ServerPlayNetworking.send(viewer,new KnifePursuitVisualPayload(a.owner.method_5667(),a.target==null?NONE:a.target.method_5667(),ending?0:a.phase,(int)Math.clamp(now(a.owner)-a.started,0,KnifePursuitRules.MAX_HOLD),a.yaw,a.throwOrigin,a.embeddedAt,a.destination,a.embedded&&!a.extracted));}
}
