package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.PlayerProfiles;
import dev.killerranking.data.SpiritState;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public final class SpiritEffects {
    public static final class_2960 ID = class_2960.method_60655("killerranking", "spirit_bonus");
    public static void apply(class_1324 attribute, int percent) {
        if (attribute == null) return;
        if (percent == 0) { attribute.method_6200(ID); return; }
        double amount = percent / 100.0;
        var previous = attribute.method_6199(ID);
        if (previous == null || previous.comp_2449() != amount) attribute.method_55696(
            new class_1322(ID, amount, class_1322.class_1323.field_6331));
    }
    public static void refresh(class_3222 player) {
        var profile = PlayerProfiles.get(player);
        var state = SpiritState.get(player);
        var branch = profile.trait() == Trait.FIGHTING_SPIRIT && dev.killerranking.data.TraitActivation.enabled(player) && player.method_5805() && !player.method_7325() ? state.branch() : SpiritBranch.NONE;
        apply(player.method_5996(class_5134.field_23721), branch.attack(profile.traitLevel()));
        apply(player.method_5996(class_5134.field_23723), branch.attackSpeed(profile.traitLevel()));
        apply(player.method_5996(class_5134.field_23719), branch.movement(profile.traitLevel(), state.checkmate()));
    }
    public static int defense(class_3222 player) {
        var p = PlayerProfiles.get(player);
        if (!dev.killerranking.data.TraitActivation.enabled(player) || p.trait() != Trait.FIGHTING_SPIRIT || !player.method_5805() || player.method_7325()) return 0;
        var branch = SpiritState.get(player).branch();
        return branch == SpiritBranch.NONE ? CombatRules.spiritPercent(CombatRules.healthRatio(player.method_6032(), player.method_6063()), p.traitLevel(), KillerRankingMod.CONFIG) : branch.defense(p.traitLevel());
    }
    private SpiritEffects() { }
}
