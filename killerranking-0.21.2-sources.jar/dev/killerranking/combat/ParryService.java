package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.PlayerProfiles;
import dev.killerranking.network.ParryEffectPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

public final class ParryService {
	private final TickTimers activeWindows = new TickTimers();
	private final TickTimers cooldowns = new TickTimers();
    private final ParryProtection protection = new ParryProtection();
    private final Map<UUID, Boolean> nextKatanaSides = new HashMap<>();
    private final AutomaticParryState automatic = new AutomaticParryState();
    private final Map<UUID, net.minecraft.class_5321<net.minecraft.class_1937>> automaticDimensions = new HashMap<>();

    private static boolean automaticEligible(class_3222 player) {
        return CleaveService.branch(player) && dev.killerranking.data.CleaveState.get(player).unlocked()
            && dev.killerranking.data.TraitActivation.enabled(player) && player.method_5805() && !player.method_7325()
            && player.method_6047().method_31574(KillerRankingMod.PAWN6_KATANA) && !player.method_6115()
            && !KillerRankingMod.CLEAVE.active(player) && !KillerRankingMod.ROOK.active(player)
            && !KillerRankingMod.ROOK.locked(player) && !KillerRankingMod.RUSH.active(player) && !KillerRankingMod.CHECKMATE.active(player);
    }
    public boolean automatic(class_3222 player) {
        return automatic.active(player.method_5667(), player.field_13995.method_30002().method_8510()) && automaticEligible(player)
            && player.method_37908().method_27983().equals(automaticDimensions.get(player.method_5667()));
    }
    public void holdAutomatic(class_3222 player, boolean held) {
        if (!held) { stopAutomatic(player); return; }
        if (!automaticEligible(player) || activeWindows.get(player.method_5667()) > 0) { stopAutomatic(player); return; }
        if (automatic.contains(player.method_5667()) && !player.method_37908().method_27983().equals(automaticDimensions.get(player.method_5667()))) {
            stopAutomatic(player); return;
        }
        boolean started = automatic.hold(player.method_5667(), player.field_13995.method_30002().method_8510());
        automaticDimensions.put(player.method_5667(), player.method_37908().method_27983());
        if (started) { broadcastAutomatic(player); KillerRankingMod.COMBAT_STATUS.sync(player); }
    }
    public void stopAutomatic(class_3222 player) {
        if (!automatic.contains(player.method_5667())) return;
        automatic.release(player.method_5667()); automaticDimensions.remove(player.method_5667());
        broadcastAutomatic(player); KillerRankingMod.COMBAT_STATUS.sync(player);
    }
    public void refreshAutomatic(class_3222 player) {
        if (automatic.contains(player.method_5667()) && !automatic(player)) stopAutomatic(player);
    }
    public void sendAutomatic(class_3222 player, class_3222 viewer) {
        if (ServerPlayNetworking.canSend(viewer, dev.killerranking.network.AutoParryStatusPayload.TYPE))
            ServerPlayNetworking.send(viewer, new dev.killerranking.network.AutoParryStatusPayload(player.method_5667(), automatic(player)));
    }
    private void broadcastAutomatic(class_3222 player) {
        for (class_3222 viewer : player.method_51469().method_18456()) if (viewer.method_5858(player) <= 4096) sendAutomatic(player, viewer);
    }

	public void tryStart(class_3222 player) {
		if (automatic(player)||KillerRankingMod.NEUNGSA_SKILL.active(player)) return;
		if (KillerRankingMod.MADNESS_LEAP.active(player) || KillerRankingMod.CLEAVE.active(player) || KillerRankingMod.ROOK.locked(player) || KillerRankingMod.ROOK.active(player) || KillerRankingMod.RUSH.active(player) || KillerRankingMod.CHECKMATE.active(player)) return;
		if (!player.method_5805() || player.method_7325() || cooldowns.get(player.method_5667()) > 0 || activeWindows.get(player.method_5667()) > 0) return;
		var profile = PlayerProfiles.get(player);
		int window = dev.killerranking.data.TraitActivation.enabled(player) && profile.trait() == Trait.FIGHTING_SPIRIT ? TraitLevels.parryWindow(profile.traitLevel()) : 5;
		activeWindows.set(player.method_5667(), window);
		cooldowns.set(player.method_5667(), KillerRankingMod.CONFIG.parryCooldownTicks);
		boolean reversed = nextKatanaSides.getOrDefault(player.method_5667(), false);
		nextKatanaSides.put(player.method_5667(), !reversed);
		// Begin the defensive motion when the server accepts the key press.
		dev.killerranking.KillerRankingSounds.play(player, dev.killerranking.KillerRankingSounds.PARRY_GUARD, 0.6F, dev.killerranking.KillerRankingSounds.vary(player, 1.0F, 0.05F));
		for (class_3222 listener : player.method_51469().method_18456()) {
			if (listener.method_5858(player) <= 4096) ServerPlayNetworking.send(listener, new ParryEffectPayload(player.method_5667(), reversed));
		}
		KillerRankingMod.COMBAT_STATUS.sync(player);
	}

	public boolean tryParry(class_3222 defender, class_1309 attacker) {
        return tryParryHit(defender,attacker,false);
    }
    /** A thrown dagger is checked at contact; its thrower can be farther than melee reach. */
    public boolean tryParryProjectile(class_3222 defender,class_1309 attacker){
        return tryParryHit(defender,attacker,true);
    }
    private boolean tryParryHit(class_3222 defender,class_1309 attacker,boolean projectile){
        boolean auto = automatic(defender);
        boolean iaido=KillerRankingMod.NEUNGSA_SKILL.iaidoActive(defender);
		if (KillerRankingMod.ROOK.locked(defender) || !defender.method_5805() || defender.method_7325() || (!auto&&!iaido && activeWindows.get(defender.method_5667()) <= 0) || !projectile&&defender.method_5858(attacker) > 20.25D) return false;
		activeWindows.remove(defender.method_5667());
        if (auto) cooldowns.remove(defender.method_5667());
        else cooldowns.reduce(defender.method_5667(), 10); // Ordinary success refunds 0.5 seconds.
        protection.onSuccess(defender.method_5667(), defender.field_13995.method_30002().method_8510());
		if(!projectile)attacker.method_6092(new class_1293(class_1294.field_5909, 20, 4));
        if (!auto&&!projectile) attacker.method_6005(0.8D, defender.method_23317() - attacker.method_23317(), defender.method_23321() - attacker.method_23321());
        if (auto) {
            var strike = automatic.strike(defender.method_5667(), defender.field_13995.method_30002().method_8510());
            boolean reversed = nextKatanaSides.getOrDefault(defender.method_5667(), false);
            nextKatanaSides.put(defender.method_5667(), !reversed);
            var payload = new dev.killerranking.network.AutoParryEffectPayload(defender.method_5667(), reversed, strike.echo(), strike.sequence(),
                defender.method_23317(), defender.method_23318(), defender.method_23321(), defender.method_36454(), defender.method_36455());
            for (class_3222 viewer : defender.method_51469().method_18456()) if (viewer.method_5858(defender) <= 4096
                && ServerPlayNetworking.canSend(viewer, dev.killerranking.network.AutoParryEffectPayload.TYPE)) ServerPlayNetworking.send(viewer, payload);
        }
        var direction=attacker.method_19538().method_1020(defender.method_19538()).method_18805(1,0,1).method_1029();
        if(direction.method_1027()<.01)direction=defender.method_5720().method_18805(1,0,1).method_1029();
        var contact=defender.method_19538().method_1031(0,defender.method_5751()*.90,0).method_1019(direction.method_1021(.9));
        var impact=new dev.killerranking.network.ParryImpactPayload(defender.method_5667(),contact.field_1352,contact.field_1351,contact.field_1350);
		for(class_3222 listener:defender.method_51469().method_18456())if(listener.method_5858(defender)<=4096
            &&ServerPlayNetworking.canSend(listener,dev.killerranking.network.ParryImpactPayload.TYPE))ServerPlayNetworking.send(listener,impact);
		dev.killerranking.KillerRankingSounds.play(defender.method_51469(), contact,
			auto ? dev.killerranking.KillerRankingSounds.PARRY_AUTO : dev.killerranking.KillerRankingSounds.PARRY_SUCCESS,
			1.0F, dev.killerranking.KillerRankingSounds.vary(defender, 1.0F, 0.04F));
		defender.method_7353(class_2561.method_43470("§b패링 성공! 0.3초 무적"), true);
		KillerRankingMod.COMBAT_STATUS.sync(defender);
		return true;
	}

	public void tick(MinecraftServer server) {
		activeWindows.tick();
		cooldowns.tick();
        protection.expire(server.method_30002().method_8510());
		for (class_3222 player : server.method_3760().method_14571()) {
            refreshAutomatic(player);
            if (automatic(player) && server.method_3780() % 5 == 0) broadcastAutomatic(player);
			if (!player.method_5805() || player.method_7325()) forget(player.method_5667());
		}
	}

	public int cooldown(class_3222 player) { return cooldowns.get(player.method_5667()); }
    public void resetCooldown(class_3222 player) {
        cooldowns.remove(player.method_5667());
        KillerRankingMod.COMBAT_STATUS.sync(player);
    }
	public int window(class_3222 player) { return Math.max(KillerRankingMod.NEUNGSA_SKILL.iaidoRemaining(player),automatic(player) ? 1 : activeWindows.get(player.method_5667())); }
    public boolean isProtected(class_3222 player) {
        return player.method_5805() && !player.method_7325() && protection.active(player.method_5667(), player.field_13995.method_30002().method_8510());
    }
	public void forget(UUID id) { activeWindows.remove(id); cooldowns.remove(id); protection.forget(id); nextKatanaSides.remove(id); automatic.release(id); automaticDimensions.remove(id); }
	public void clear() { activeWindows.clear(); cooldowns.clear(); protection.clear(); nextKatanaSides.clear(); automatic.clear(); automaticDimensions.clear(); }
}
