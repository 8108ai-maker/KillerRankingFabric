package dev.killerranking.combat;

import net.minecraft.class_243;

/** Bounded pursuit and pattern selection; no teleporting, stat inflation or retreat rush. */
public final class BishopTactics {
    public static int attack(int cycle,int formation,double gap,double escapingSpeed){
        if(gap>1.85||escapingSpeed>.12&&gap>1.25)return BishopRules.STAB_COMBO;
        return Math.floorMod(cycle+formation,3)==1?BishopRules.STAB_COMBO:BishopRules.COMBO;
    }
    public static class_243 lead(class_243 target,class_243 velocity,int ticks){
        var horizontal=new class_243(velocity.field_1352,0,velocity.field_1350).method_1021(ticks);
        if(!Double.isFinite(horizontal.method_1027()))return target;
        if(horizontal.method_1027()>.64)horizontal=horizontal.method_1029().method_1021(.8);
        return target.method_1019(horizontal);
    }
    public static double step(double gap,boolean thrust){
        return Double.isFinite(gap)?Math.clamp((gap-(thrust?1.1:1.25))*.7,0,thrust?.46:.4):0;
    }
    public static class_243 approach(class_243 self,class_243 target,int formation){
        var towards=target.method_1020(self);towards=new class_243(towards.field_1352,0,towards.field_1350);
        if(towards.method_1027()<.001)return target;
        towards=towards.method_1029();double side=formation%2==0?1:-1;
        // Different entry lanes spread the squad without forcing a detour away from the enemy.
        return target.method_1031(-towards.field_1350*side*.75,0,towards.field_1352*side*.75).method_1020(towards.method_1021(1.15));
    }
    private BishopTactics(){ }
}
