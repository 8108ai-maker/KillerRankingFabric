package dev.killerranking.combat;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.data.*;
import dev.killerranking.entity.BishopFollower;
import dev.killerranking.network.BishopBarrageVisualPayload;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.phys.*;
import net.minecraft.sounds.*;
import java.util.*;

/** Four brief attackers introduce a fixed, server-owned five-second cutting zone. */
public final class BishopBarrageService {
    private static final class Action {
        final long started;final class_243 origin,direction;final float yaw;final class_5321<class_1937> dimension;
        final List<UUID> echoes=new ArrayList<>();
        Action(class_3222 p){started=BishopService.now(p);origin=p.method_19538();yaw=p.method_36454();dimension=p.method_37908().method_27983();double angle=Math.toRadians(yaw);direction=new class_243(-Math.sin(angle),0,Math.cos(angle));}
    }
    private final Map<UUID,Action> actions=new HashMap<>();
    public boolean active(class_3222 p){return actions.containsKey(p.method_5667());}
    public int remaining(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:(int)Math.clamp(BishopBarrageRules.DURATION-(BishopService.now(p)-a.started),0,BishopBarrageRules.DURATION);}
    public boolean manages(class_3222 p,UUID unit){var a=actions.get(p.method_5667());return a!=null&&a.dimension.equals(p.method_37908().method_27983())&&a.echoes.contains(unit);}
    public List<BishopFollower> echoes(class_3222 p){var a=actions.get(p.method_5667());return a==null?List.of():a.echoes.stream().map(p.method_51469()::method_14190).filter(e->e instanceof BishopFollower&&e.method_5805()).map(e->(BishopFollower)e).toList();}
    public void start(class_3222 p){
        if(!KillerRankingMod.BISHOP.eligible(p)||active(p)||BishopState.get(p).barrageCooldown(BishopService.now(p))>0
            ||p.method_5765()||p.method_6115()||p.method_5816()||p.method_5771()||SkillCombatLock.blocksAttack(p))return;
        var a=new Action(p);actions.put(p.method_5667(),a);
        var old=BishopState.get(p);BishopState.set(p,new BishopState(old.unlocked(),old.readyAt(),a.started+BishopRules.cooldown(PlayerProfiles.get(p).traitLevel())));
        var side=new class_243(a.direction.field_1350,0,-a.direction.field_1352);
        for(int i=0;i<4;i++){
            var unit=KillerRankingMod.BISHOP_FOLLOWER.method_5883(p.method_51469());if(unit==null)continue;
            var at=a.origin.method_1019(side.method_1021(i<2?1.4:-1.4)).method_1019(a.direction.method_1021(i%2==0?.65:-.65));
            unit.barrage(p,a.started+BishopBarrageRules.ECHO_TICKS,i,PlayerProfiles.get(p).traitLevel());
            unit.method_5808(at.field_1352,at.field_1351,at.field_1350,a.yaw,0);unit.field_6283=unit.field_6220=a.yaw;unit.method_5847(a.yaw);unit.field_6259=a.yaw;
            if(p.method_51469().method_8649(unit))a.echoes.add(unit.method_5667());
        }
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.BISHOP_BARRAGE,class_3419.field_15248,1f,1f);
        broadcast(p);KillerRankingMod.BISHOP.sync(p);
    }
    public void tick(MinecraftServer server){for(var p:server.method_3760().method_14571()){
        var a=actions.get(p.method_5667());if(a==null)continue;
        if(!KillerRankingMod.BISHOP.eligible(p)||!a.dimension.equals(p.method_37908().method_27983())){cancel(p);continue;}
        int age=(int)Math.min(Integer.MAX_VALUE,BishopService.now(p)-a.started);
        if(age==BishopBarrageRules.ECHO_TICKS){
            p.method_51469().method_43128(null,a.origin.field_1352,a.origin.field_1351+1,a.origin.field_1350,dev.killerranking.KillerRankingSounds.BISHOP_VANISH,class_3419.field_15248,.7f,1.1f);
        }
        if(BishopBarrageRules.contact(age))strike(p,a);
        if(age>=BishopBarrageRules.DURATION){cancel(p);continue;}
        if(age%10==0)broadcast(p);
    }}
    private void strike(class_3222 p,Action a){
        var region=new class_238(a.origin.field_1352-7,a.origin.field_1351-.5,a.origin.field_1350-7,a.origin.field_1352+7,a.origin.field_1351+3.5,a.origin.field_1350+7);
        for(var e:p.method_51469().method_8390(net.minecraft.class_1309.class,region,e->BishopTargets.allowed(p,e))){
            var center=e.method_5829().method_1005();var to=center.method_1020(a.origin);
            double forward=to.method_1026(a.direction),side=to.field_1352*a.direction.field_1350-to.field_1350*a.direction.field_1352;
            if(!BishopBarrageRules.inZone(forward,side,to.field_1351,e.method_17681()*.5))continue;
            var trace=p.method_51469().method_17742(new class_3959(a.origin.method_1031(0,p.method_5751(),0),e.method_33571(),class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
            if(trace.method_17783()!=class_239.class_240.field_1333)continue;
            RushDamage.hit(p,e,BishopBarrageRules.DAMAGE,false);
        }
        int age=(int)(BishopService.now(p)-a.started);
        if(age>BishopBarrageRules.ECHO_TICKS&&age%4==0)p.method_51469().method_43128(null,a.origin.field_1352,a.origin.field_1351+1,a.origin.field_1350,dev.killerranking.KillerRankingSounds.BISHOP_CUT,class_3419.field_15248,.45f,.95f+(age%12)*.03f);
    }
    public void send(class_3222 p,class_3222 viewer){
        var a=actions.get(p.method_5667());var at=a==null?p.method_19538():a.origin;
        if(ServerPlayNetworking.canSend(viewer,BishopBarrageVisualPayload.TYPE))ServerPlayNetworking.send(viewer,new BishopBarrageVisualPayload(p.method_5667(),remaining(p),at.field_1352,at.field_1351,at.field_1350,a==null?p.method_36454():a.yaw));
    }
    private void broadcast(class_3222 p){send(p,p);for(var viewer:PlayerLookup.tracking(p))send(p,viewer);}
    public void cancel(class_3222 p){var a=actions.remove(p.method_5667());if(a==null)return;
        var level=p.field_13995.method_3847(a.dimension);if(level!=null)for(var id:a.echoes){var e=level.method_14190(id);if(e!=null)e.method_31472();}
        broadcast(p);KillerRankingMod.BISHOP.sync(p);
    }
    public void clear(){actions.clear();}
}
