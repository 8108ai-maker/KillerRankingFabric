package dev.killerranking.combat;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_2390;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.joml.Vector3f;

/** Vanilla saves, expires and cures the debuff. Its pulses do not depend on an active cast. */
public final class HemorrhageEffect extends class_1291 {
    public HemorrhageEffect(){super(class_4081.field_18272,0xBA123C);}
    @Override public boolean method_5552(int remaining,int amplifier){return WasabariRules.bleedPulse(remaining);}
    @Override public boolean method_5572(class_1309 victim,int amplifier){
        if(victim.method_37908() instanceof class_3218 level&&victim.method_5805()
            &&BleedingDamage.hit(KillerRankingMod.WASABARI.bleeder(victim),victim,WasabariRules.BLEED_DAMAGE))
            level.method_14199(new class_2390(new Vector3f(.78f,.025f,.055f),.8f),victim.method_23317(),victim.method_23318()+.25,victim.method_23321(),6,.16,.08,.16,.02);
        return true;
    }
}
