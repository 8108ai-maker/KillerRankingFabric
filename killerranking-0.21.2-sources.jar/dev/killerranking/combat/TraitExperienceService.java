package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.PlayerProfile;
import dev.killerranking.data.PlayerProfiles;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public final class TraitExperienceService {
    public static int required(int level) {
        return TraitExperience.required(level, KillerRankingMod.CONFIG.traitLevel2Xp, KillerRankingMod.CONFIG.traitLevel3Xp);
    }
    private static boolean eligible(class_3222 p) { return dev.killerranking.data.TraitActivation.enabled(p) && !p.method_7325() && !p.method_7337(); }
    public static void tick(MinecraftServer server) {
        for (var player : server.method_3760().method_14571()) {
            if (!eligible(player) || !player.method_5805()) continue;
            var before = PlayerProfiles.get(player);
            boolean active = before.trait() == Trait.KILLING_INTENT ? KillerRankingMod.COMBAT_STATUS.killingIntentActive(player)
                : before.trait() == Trait.MIXED_MADNESS && CombatRules.madnessActive(CombatRules.healthRatio(player.method_6032(), player.method_6063()));
            apply(player, before, TraitExperience.activeTick(before, active, KillerRankingMod.CONFIG.traitLevel2Xp, KillerRankingMod.CONFIG.traitLevel3Xp));
        }
    }
    public static void hit(class_1309 victim, class_1282 source) {
        if (!(source.method_5529() instanceof class_1309 attacker) || attacker == victim) return;
        if (attacker instanceof class_3222 player && player.method_5805()) awardHit(player);
        else if(attacker instanceof dev.killerranking.entity.BishopFollower follower&&follower.owner()!=null&&follower.owner().method_5805())awardHit(follower.owner());
        // A lethal received hit counts too; copyOnDeath preserves the resulting XP.
        if (victim instanceof class_3222 player) awardHit(player);
    }
    private static void awardHit(class_3222 player) {
        if (!eligible(player)) return;
        var before = PlayerProfiles.get(player);
        if (TraitExperience.passive(before.trait())) apply(player, before,
            TraitExperience.add(before, 1, KillerRankingMod.CONFIG.traitLevel2Xp, KillerRankingMod.CONFIG.traitLevel3Xp));
    }
    private static void apply(class_3222 player, PlayerProfile before, PlayerProfile after) {
        if (before.equals(after)) return;
        PlayerProfiles.set(player, after);
        if (before.traitLevel() != after.traitLevel()) {
            KillerRankingMod.assignAndSync(player);
            if (after.traitLevel() > before.traitLevel()) dev.killerranking.KillerRankingSounds.play(player, dev.killerranking.KillerRankingSounds.LEVEL_UP, 1.0F, 1.0F);
            player.method_43502(class_2561.method_43470("§a특성 레벨 상승! " + after.trait().koreanName() + " Lv." + after.traitLevel()), true);
        }
    }
    private TraitExperienceService() { }
}
