package dev.killerranking.combat;

import net.minecraft.class_1309;
import net.minecraft.class_3222;

/** Native hurt gates still decide whether the blow connects. Only its final damage is replaced. */
public final class CheckmateDamage {
    private static final ThreadLocal<class_1309> CURRENT=new ThreadLocal<>();
    public static boolean current(class_1309 target) { return CURRENT.get()==target; }
    public static float finalDamage(class_1309 target,float damage) {
        return CURRENT.get()==target&&damage>0
            ?CheckmateRules.damageToHalfHeart(target.method_6032(),target.method_6067()):damage;
    }
    public static boolean hit(class_3222 attacker,class_1309 target) {
        float damage=CheckmateRules.damageToHalfHeart(target.method_6032(),target.method_6067());
        if(damage<=0) return false;
        var previous=CURRENT.get();CURRENT.set(target);
        try { return target.method_5643(attacker.method_48923().method_48802(attacker),damage); }
        finally { if(previous==null) CURRENT.remove();else CURRENT.set(previous); }
    }
    private CheckmateDamage() { }
}
