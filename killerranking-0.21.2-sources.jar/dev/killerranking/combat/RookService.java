package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import java.util.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;

/** Authoritative short-range grab, bounded choice window and three mutually exclusive finishers. */
public final class RookService {
    private record Aim(long started,class_5321<class_1937> dimension) { }
    private static final class Hold {
        final class_3222 owner;final class_1309 victim;final class_5321<class_1937> dimension;
        final class_243 origin,anchor,direction;final boolean noAi;
        class_243 ownerAnchor;long started;int phase=RookRules.CHOICE;boolean released;
        Hold(class_3222 p,class_1309 v,class_243 anchor,class_243 ownerAt) {
            owner=p;victim=v;dimension=p.method_37908().method_27983();origin=p.method_19538();ownerAnchor=ownerAt;
            this.anchor=anchor;direction=horizontal(p);started=now(p);noAi=v instanceof class_1308 mob&&mob.method_5987();
        }
    }
    private record Flight(class_3222 owner,class_1309 victim,long started,class_5321<class_1937> dimension,boolean impacted) { }
    private final Map<UUID,Aim> aims=new HashMap<>();
    private final Map<UUID,Hold> holds=new HashMap<>(),victims=new HashMap<>();
    private final Map<UUID,Flight> flights=new HashMap<>();
    private final Map<UUID,RookStatusPayload> sent=new HashMap<>();
    public static boolean branch(class_3222 p) { return PlayerProfiles.get(p).trait()==Trait.FIGHTING_SPIRIT&&SpiritState.get(p).branch()==SpiritBranch.KING_AND_KILL; }
    private static long now(class_3222 p) { return p.field_13995.method_30002().method_8510(); }
    private static class_243 horizontal(class_3222 p) { var look=p.method_5720();var v=new class_243(look.field_1352,0,look.field_1350);return v.method_1027()>.01?v.method_1029():class_243.method_1030(0,p.method_36454()); }
    private boolean eligible(class_3222 p) { return branch(p)&&RookState.get(p).unlocked()&&p.method_5805()&&!p.method_7325()&&TraitActivation.enabled(p)&&!p.method_6115()&&!p.method_5765()&&!captured(p); }
    public boolean active(class_3222 p) { return aims.containsKey(p.method_5667())||holds.containsKey(p.method_5667()); }
    public boolean captured(class_1297 e) { return !e.method_37908().field_9236&&(victims.containsKey(e.method_5667())||KillerRankingMod.WASABARI.captured(e)); }
    public boolean locked(class_1297 e) { return !e.method_37908().field_9236&&(captured(e)||holds.containsKey(e.method_5667())||KillerRankingMod.HEAVY_PUNCH.locked(e)||KillerRankingMod.WASABARI.locked(e)); }
    public int phase(class_3222 p) { var h=holds.get(p.method_5667());return h!=null?h.phase:aims.containsKey(p.method_5667())?RookRules.AIM:RookRules.IDLE; }
    public int remaining(class_3222 p) {
        var h=holds.get(p.method_5667());var a=aims.get(p.method_5667());
        return h!=null?(int)Math.max(0,RookRules.duration(h.phase)-(now(p)-h.started)):a!=null?(int)Math.max(0,RookRules.AIM_DURATION-(now(p)-a.started)):0;
    }
    public void request(class_3222 p,RookRequestPayload request) {
        switch(request.operation()) {
            case RookRequestPayload.START->start(p);
            case RookRequestPayload.CONFIRM->confirm(p,request.target());
            case RookRequestPayload.CANCEL->cancel(p);
            case RookRequestPayload.THROW,RookRequestPayload.PUNCH,RookRequestPayload.MOUNT->choose(p,request.operation());
            case RookRequestPayload.UNLOCK->unlock(p);
        }
    }
    public void unlock(class_3222 p) {
        if(!branch(p)||!p.method_5805()||p.method_7325()||captured(p))return;
        if(RookState.get(p).unlocked()){sync(p);return;}
        if(BishopState.get(p).unlocked()||CleaveState.get(p).unlocked()||!RookRules.canUnlock(RushState.get(p).unlocked(),CheckmateState.get(p).unlocked(),false)) {
            dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c투기 스킬은 하나만 해금할 수 있습니다. 나이트·룩·폰 6·비숍 중 하나를 선택하세요."));sync(p);return;
        }
        var profile=PlayerProfiles.get(p);
        if(profile.pointUnits()<KillerPoints.whole(RookRules.COST)){dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c잡기 해금에는 1,000포인트가 필요합니다."));sync(p);return;}
        PlayerProfiles.set(p,profile.addPoints(-RookRules.COST));dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_PURCHASE,1f,1f);setOwned(p,true);
        p.method_43496(class_2561.method_43470("§f잡기 해금 완료! Z를 눌러 지정 → 놓아서 잡기 → 5초 안에 Z/X/C 선택"));
    }
    public void setOwned(class_3222 p,boolean owned) {
        if(owned) {
            KillerRankingMod.BISHOP.forget(p);BishopState.set(p,BishopState.get(p).owned(false));
            KillerRankingMod.CLEAVE.cancel(p);CleaveState.set(p,CleaveState.get(p).owned(false));
            KillerRankingMod.RUSH.cancel(p);KillerRankingMod.CHECKMATE.cancel(p);
            RushState.set(p,new RushState(false,RushState.get(p).readyAt()));
            CheckmateState.set(p,CheckmateState.get(p).owned(false));
            SpiritState.set(p,new SpiritState(SpiritState.get(p).branch(),false));
        }else cancel(p);
        RookState.set(p,RookState.get(p).owned(owned));KillerRankingMod.assignAndSync(p);
    }
    public void start(class_3222 p) {
        if(KillerRankingMod.CLEAVE.active(p)||!eligible(p)||active(p)||locked(p)||RookState.get(p).cooldown(now(p))>0||KillerRankingMod.RUSH.active(p)||KillerRankingMod.CHECKMATE.active(p)||KillerRankingMod.PARRY.window(p)>0)return;
        aims.put(p.method_5667(),new Aim(now(p),p.method_37908().method_27983()));sync(p);
    }
    private boolean enemy(class_3222 p,class_1309 e) {
        return e!=p&&e.method_5805()&&!e.method_31481()&&!e.method_7325()&&e.method_5732()&&!e.method_5765()&&!e.method_5782()
            &&!p.method_5722(e)&&p.method_18395(e)&&!locked(e)&&!(e instanceof class_3222 other&&other.method_7337());
    }
    public class_1309 selected(class_3222 p) {
        var eye=p.method_33571();var end=eye.method_1019(p.method_5720().method_1021(RookRules.REACH));
        return p.method_51469().method_8390(class_1309.class,p.method_5829().method_1014(RookRules.REACH),e->enemy(p,e)
            &&p.method_5858(e)<=RookRules.REACH*RookRules.REACH&&p.method_6057(e)
            &&e.method_5829().method_1014(.12).method_992(eye,end).isPresent()).stream()
            .min(Comparator.comparingDouble(e->e.method_5829().method_1014(.12).method_992(eye,end).orElse(end).method_1025(eye))).orElse(null);
    }
    public void confirm(class_3222 p,int targetId) {
        var aim=aims.remove(p.method_5667());
        if(aim==null)return;
        var target=selected(p);
        if(targetId<0||target==null||target.method_5628()!=targetId||!eligible(p)||!aim.dimension.equals(p.method_37908().method_27983())
            ||now(p)-aim.started>=RookRules.AIM_DURATION||RookState.get(p).cooldown(now(p))>0){sync(p);return;}
        var anchor=target.method_19538();
        var ownerAt=anchor.method_1020(horizontal(p).method_1021(.72+target.method_17681()*.5));
        if(!clearBox(target,anchor)||!clearBox(p,ownerAt)||!clearSegment(p,p.method_19538(),ownerAt)){sync(p);return;}
        var h=new Hold(p,target,anchor,ownerAt);holds.put(p.method_5667(),h);victims.put(target.method_5667(),h);
        if(target instanceof class_1308 mob){mob.method_5942().method_6340();mob.method_5977(true);}
        target.method_6021();p.method_6021();RookState.set(p,RookState.get(p).cast(now(p)));
        freeze(h);sound(p,dev.killerranking.KillerRankingSounds.ROOK_GRAB,1f);broadcast(h);sync(p);if(target instanceof class_3222 v)sync(v);
    }
    public void choose(class_3222 p,int action) {
        var h=holds.get(p.method_5667());
        if(h==null||h.phase!=RookRules.CHOICE||remaining(p)<=0||action<RookRules.THROW||action>RookRules.MOUNT||!valid(h))return;
        if(action==RookRules.MOUNT) {
            // Mount the grounded victim's torso, rather than standing on a
            // still-upright target. The render pose lays the victim on its back.
            var seat=h.anchor.method_1020(h.direction.method_1021(.15)).method_1031(0,RookMountPose.seatHeight(h.victim),0);
            if(!clearBox(p,seat)||!clearSegment(p,p.method_19538(),seat)){p.method_7353(class_2561.method_43470("§7올라탈 공간이 없습니다. Z 또는 X를 선택하세요."),true);return;}
            h.ownerAnchor=seat;
        }
        h.phase=action;h.started=now(p);freeze(h);
        if(RookRules.strike(action,0))strike(h);
        broadcast(h);sync(p);
    }
    private static boolean clearBox(class_1309 e,class_243 at) {
        return !e.method_37908().method_20812(e,e.method_5829().method_997(at.method_1020(e.method_19538())).method_1011(.001)).iterator().hasNext();
    }
    private static boolean clearSegment(class_1309 e,class_243 from,class_243 to) {
        int steps=Math.max(1,(int)Math.ceil(from.method_1022(to)/.15));
        for(int i=1;i<=steps;i++)if(!clearBox(e,from.method_35590(to,(double)i/steps)))return false;return true;
    }
    private boolean valid(Hold h) {
        return eligible(h.owner)&&h.owner.method_37908().method_27983().equals(h.dimension)&&h.victim.method_37908().method_27983().equals(h.dimension)
            &&h.victim.method_5805()&&!h.victim.method_31481()&&!h.victim.method_7325()&&!h.owner.method_5765()&&!h.victim.method_5765()
            &&!(h.victim instanceof class_3222 p&&p.method_7337())&&h.owner.method_19538().method_1025(h.ownerAnchor)<2.25
            &&(h.released||h.victim.method_19538().method_1025(h.anchor)<9&&clearBox(h.victim,h.anchor))&&clearBox(h.owner,h.ownerAnchor);
    }
    private static void position(class_1309 e,class_243 at) {
        e.method_18799(class_243.field_1353);e.field_6017=0;
        if(e.method_19538().method_1025(at)>.0001) {
            if(e instanceof class_3222 p)p.method_48105(p.method_51469(),at.field_1352,at.field_1351,at.field_1350,Set.of(class_2709.field_12401,class_2709.field_12397),p.method_36454(),p.method_36455());
            else e.method_5859(at.field_1352,at.field_1351,at.field_1350);
        }
    }
    private void freeze(Hold h) {
        position(h.owner,h.ownerAnchor);
        if(!h.released)position(h.victim,h.anchor);
    }
    private static void sound(class_3222 p,net.minecraft.class_3414 sound,float pitch) {p.method_51469().method_8396(null,p.method_24515(),sound,class_3419.field_15248,.6f,pitch);}
    private void strike(Hold h) {
        boolean heavy=h.phase==RookRules.MOUNT;
        if(RushDamage.hit(h.owner,h.victim,heavy?RookRules.MOUNT_DAMAGE:RookRules.PUNCH_DAMAGE,false)) {
            var v=h.victim;double height=heavy?RookMountPose.impactHeight(v):v.method_17682()*.7;
            h.owner.method_51469().method_14199(heavy?class_2398.field_11205:class_2398.field_11203,v.method_23317(),v.method_23318()+height,v.method_23321(),heavy?10:5,.13,.12,.13,.04);
            sound(h.owner,heavy?dev.killerranking.KillerRankingSounds.HEAVY_PUNCH_IMPACT:dev.killerranking.KillerRankingSounds.ROOK_PUNCH,heavy?.9f:1f);
        }
    }
    private void releaseVictim(Hold h) {
        if(h.released)return;h.released=true;victims.remove(h.victim.method_5667(),h);
        if(h.victim instanceof class_1308 mob)mob.method_5977(h.noAi);
        h.victim.field_6017=0;if(h.victim instanceof class_3222 p)sync(p);
    }
    private void launch(Hold h) {
        RushDamage.hit(h.owner,h.victim,RookRules.THROW_DAMAGE,false);releaseVictim(h);
        launchTarget(h.owner,h.victim,h.direction);
        sound(h.owner,dev.killerranking.KillerRankingSounds.ROOK_THROW,1f);broadcast(h);
    }
    /** Shared physical throw: the caller supplies its own contact damage. */
    public void launchTarget(class_3222 owner,class_1309 victim,class_243 direction) {
        if(!victim.method_5805()||victim.method_31481()||owner.method_37908()!=victim.method_37908())return;
        var forward=direction.method_18805(1,0,1).method_1029();if(forward.method_1027()<.9)return;
        victim.method_18799(forward.method_1021(1.65).method_1031(0,.38,0));victim.field_6037=true;victim.field_6007=true;
        flights.put(victim.method_5667(),new Flight(owner,victim,now(owner),owner.method_37908().method_27983(),false));
    }
    public void refresh(class_3222 p) {
        RookBodySize.refresh(p);
        var aim=aims.get(p.method_5667());if(aim!=null&&(!eligible(p)||!aim.dimension.equals(p.method_37908().method_27983())||now(p)-aim.started>=RookRules.AIM_DURATION))cancel(p);
        var h=holds.get(p.method_5667());if(h!=null&&!valid(h))cancel(p);
    }
    public void tick(MinecraftServer server) {
        for(var p:server.method_3760().method_14571())refresh(p);
        for(var h:new ArrayList<>(holds.values())) {
            if(!valid(h)||remaining(h.owner)<=0){cancel(h.owner);continue;}
            int age=(int)(now(h.owner)-h.started);freeze(h);
            if(h.phase==RookRules.THROW&&!h.released&&age>=RookRules.THROW_RELEASE)launch(h);
            if(age>0&&RookRules.strike(h.phase,age))strike(h);
            if(age%5==0)broadcast(h);
        }
        for(var f:new ArrayList<>(flights.values())) {
            var v=f.victim();long age=now(f.owner())-f.started();
            if(age>RookRules.FLIGHT_DURATION||!v.method_5805()||v.method_31481()||!v.method_37908().method_27983().equals(f.dimension())){flights.remove(v.method_5667());continue;}
            // Vanilla disables travel entirely for NoAI mobs. Preserve their
            // AI flag, while giving the external throw ordinary block collision.
            if(age>0&&v instanceof class_1308 mob&&mob.method_5987()) {
                var velocity=v.method_18798();v.method_5784(net.minecraft.class_1313.field_6308,velocity);
                v.method_18799(v.method_24828()?velocity.method_18805(.98,0,.98):velocity.method_18805(.98,.98,.98).method_1031(0,-v.method_56989(),0));
            }
            var speed=v.method_18798();var horizontal=new class_243(speed.field_1352,0,speed.field_1350);
            var hit=v.method_37908().method_17742(new class_3959(v.method_19538().method_1031(0,v.method_17682()*.5,0),v.method_19538().method_1031(0,v.method_17682()*.5,0).method_1019(horizontal.method_1029().method_1021(.4)),class_3959.class_3960.field_17558,class_3959.class_242.field_1348,v));
            if(!f.impacted()&&age>0&&(v.field_5976||horizontal.method_1027()>.02&&hit.method_17783()==class_239.class_240.field_1332&&hit.method_17780().method_10166()!=net.minecraft.class_2350.class_2351.field_11052)) {
                // Keep gravity running after impact, including targets whose AI is disabled.
                flights.put(v.method_5667(),new Flight(f.owner(),v,f.started(),f.dimension(),true));RushDamage.hit(f.owner(),v,RookRules.WALL_DAMAGE,false);
                v.method_18799(speed.method_18805(.15,1,.15));v.field_6037=true;
                f.owner().method_51469().method_14199(class_2398.field_11203,v.method_23317(),v.method_23318()+v.method_17682()*.5,v.method_23321(),12,.15,.2,.15,.06);
                sound(f.owner(),dev.killerranking.KillerRankingSounds.ROOK_SLAM,1f);
            }
        }
        if(server.method_3780()%2==0)for(var p:server.method_3760().method_14571())sync(p);
    }
    public void cancel(class_3222 p) {
        aims.remove(p.method_5667());var h=holds.remove(p.method_5667());
        if(h!=null){releaseVictim(h);broadcast(new RookVisualPayload(p.method_5667(),h.victim.method_5667(),0,0,0),p);}
        sync(p);
    }
    public void forget(class_1297 e) {
        var captive=victims.get(e.method_5667());if(captive!=null)cancel(captive.owner);
        if(e instanceof class_3222 p){cancel(p);sent.remove(p.method_5667());}
        flights.values().removeIf(f->f.victim()==e||f.owner()==e);
    }
    public void clear() {for(var h:holds.values())releaseVictim(h);holds.clear();victims.clear();aims.clear();flights.clear();sent.clear();}
    public void sync(class_3222 p) {
        var target=phase(p)==RookRules.AIM?selected(p):holds.containsKey(p.method_5667())?holds.get(p.method_5667()).victim:null;
        var state=RookState.get(p);var payload=new RookStatusPayload(branch(p),state.unlocked(),BishopState.get(p).unlocked()||RushState.get(p).unlocked()||CheckmateState.get(p).unlocked()||CleaveState.get(p).unlocked(),phase(p),target==null?-1:target.method_5628(),remaining(p),state.cooldown(now(p)),captured(p));
        if(!payload.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,RookStatusPayload.TYPE)){ServerPlayNetworking.send(p,payload);sent.put(p.method_5667(),payload);}
    }
    private void broadcast(Hold h) {broadcast(new RookVisualPayload(h.owner.method_5667(),h.released?null:h.victim.method_5667(),h.phase,(int)(now(h.owner)-h.started),remaining(h.owner)),h.owner);}
    private void broadcast(RookVisualPayload payload,class_3222 owner) {
        var viewers=new HashSet<>(PlayerLookup.tracking(owner));viewers.add(owner);
        var h=holds.get(owner.method_5667());if(h!=null&&h.victim instanceof class_3222 victim)viewers.add(victim);
        for(var viewer:viewers)if(ServerPlayNetworking.canSend(viewer,RookVisualPayload.TYPE))ServerPlayNetworking.send(viewer,payload);
    }
    public void send(class_3222 owner,class_3222 viewer) {
        var h=holds.get(owner.method_5667());if(h!=null&&ServerPlayNetworking.canSend(viewer,RookVisualPayload.TYPE))ServerPlayNetworking.send(viewer,new RookVisualPayload(owner.method_5667(),h.released?null:h.victim.method_5667(),h.phase,(int)(now(owner)-h.started),remaining(owner)));
    }
}
