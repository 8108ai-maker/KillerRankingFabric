package dev.killerranking.combat;

import java.util.List;
import java.util.OptionalDouble;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;

/** Invisible flight stops at the first surface; block removal never continues into its next layer. */
public final class NeungsaSlashRules {
    public static final int COST=1000, COOLDOWN=240, DURATION=16, HIT=5;
    public static final double REACH=12, HALF_WIDTH=1.5, HALF_HEIGHT=.35;
    public static final float DAMAGE=16;
    public static List<class_2338> surface(class_2338 contact, class_2350 face, class_243 direction) {
        boolean alongX=face.method_10166()==class_2350.class_2351.field_11051
            || face.method_10166()==class_2350.class_2351.field_11052 && Math.abs(direction.field_1350)>=Math.abs(direction.field_1352);
        class_2338 side=alongX?new class_2338(1,0,0):new class_2338(0,0,1);
        return java.util.stream.IntStream.rangeClosed(-2,2)
            .mapToObj(i->contact.method_10069(side.method_10263()*i,0,side.method_10260()*i)).toList();
    }
    /** Widen only across the cut: its forward range and height do not grow with the width. */
    public static OptionalDouble entry(class_243 start,class_243 forward,class_238 bounds,double limit){
        return entry(start,forward,bounds,limit,HALF_WIDTH,HALF_HEIGHT);
    }
    public static OptionalDouble entry(class_243 start,class_243 forward,class_238 bounds,double limit,double halfWidth,double halfHeight){
        class_243 side=new class_243(forward.field_1350,0,-forward.field_1352);
        side=side.method_1027()<1.0e-8?new class_243(1,0,0):side.method_1029();
        class_243 up=forward.method_1036(side).method_1029();
        var relative=bounds.method_1005().method_1020(start);
        double near=relative.method_1026(forward)-support(bounds,forward);
        double far=relative.method_1026(forward)+support(bounds,forward);
        if(far<0||near>limit+.001
            ||Math.abs(relative.method_1026(side))>halfWidth+support(bounds,side)
            ||Math.abs(relative.method_1026(up))>halfHeight+support(bounds,up))return OptionalDouble.empty();
        return OptionalDouble.of(Math.max(0,near));
    }
    private static double support(class_238 box,class_243 axis){
        return (Math.abs(axis.field_1352)*box.method_17939()+Math.abs(axis.field_1351)*box.method_17940()+Math.abs(axis.field_1350)*box.method_17941())*.5;
    }
    public static int cooldown(long readyAt,long now) {
        return (int)Math.clamp(readyAt-now,0,COOLDOWN);
    }
    private NeungsaSlashRules(){ }
}
