package dev.killerranking.combat;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.SalmosaStatusPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class SalmosaSkillService {
    public static final int COST=1000;
    public static boolean branch(class_3222 p){return PlayerProfiles.get(p).trait()==Trait.POISON_AURA;}
    public static boolean available(class_3222 p){return branch(p)&&SalmosaState.get(p).unlocked();}
    public static void unlock(class_3222 p){
        if(!branch(p)||!p.method_5805()||p.method_7325()||SkillCombatLock.blocksAttack(p))return;
        if(SalmosaState.get(p).unlocked()){sync(p);return;}
        var profile=PlayerProfiles.get(p);
        if(profile.pointUnits()<KillerPoints.whole(COST)){dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c살모사 해금에는 1,000포인트가 필요합니다."));sync(p);return;}
        PlayerProfiles.set(p,profile.addPoints(-COST));dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_PURCHASE,1f,1f);SalmosaState.set(p,SalmosaState.OWNED);
        KillerRankingMod.assignAndSync(p);
        p.method_43496(class_2561.method_43470("§5살모사 해금 완료! 1,000포인트 사용 · Z 와사바리 / X 칼날 추격 / C 어깨 찌르기"));
    }
    public static void sync(class_3222 p){
        if(ServerPlayNetworking.canSend(p,SalmosaStatusPayload.TYPE))ServerPlayNetworking.send(p,new SalmosaStatusPayload(branch(p),SalmosaState.get(p).unlocked()));
    }
    private SalmosaSkillService(){ }
}
