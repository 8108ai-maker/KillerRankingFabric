package dev.killerranking.combat;

import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.world.phys.*;

/** Trace loaded entities, independent of the player's normal interaction reach. */
public final class BishopDesignationTargeting {
    public static double entry(class_243 eye, class_243 direction, class_238 box) {
        if (!Double.isFinite(direction.method_1027()) || direction.method_1027() < 1e-12) return Double.POSITIVE_INFINITY;
        var ray = direction.method_1029();
        if (box.method_1006(eye)) return 0;
        double reach = eye.method_1022(box.method_1005()) + box.method_995() * 2 + 1;
        return box.method_992(eye, eye.method_1019(ray.method_1021(reach))).map(p -> p.method_1022(eye)).orElse(Double.POSITIVE_INFINITY);
    }
    public static class_1309 selected(class_3222 owner) {
        var eye = owner.method_33571(); var ray = owner.method_5720();
        class_1309 selected = null; double nearest = Double.POSITIVE_INFINITY;
        for (var entity : owner.method_51469().method_27909()) {
            if (!(entity instanceof class_1309 target) || target == owner || !target.method_5805()
                    || target.method_7325() || !target.method_5863()) continue;
            // The caster's escort formation must not block its own targeting ray.
            if(target instanceof dev.killerranking.entity.BishopFollower follower&&owner.method_5667().equals(follower.ownerId()))continue;
            double distance = entry(eye, ray, target.method_5829().method_1014(.1));
            if (distance < nearest) { nearest = distance; selected = target; }
        }
        // An ally in front blocks selection of an enemy behind it, just like a wall.
        if (!BishopTargets.allowed(owner, selected)) return null;
        if (!loadedPath(owner, eye, ray, nearest)) return null;
        var hit = owner.method_51469().method_17742(new class_3959(eye, eye.method_1019(ray.method_1021(nearest)),
            class_3959.class_3960.field_17558, class_3959.class_242.field_1348, owner));
        return hit.method_17783() == class_239.class_240.field_1333 ? selected : null;
    }
    private static boolean loadedPath(class_3222 owner,class_243 eye,class_243 ray,double distance){
        int x=(int)Math.floor(eye.field_1352/16),z=(int)Math.floor(eye.field_1350/16);
        int sx=ray.field_1352>=0?1:-1,sz=ray.field_1350>=0?1:-1;
        double tx=Math.abs(ray.field_1352)<1e-12?Double.POSITIVE_INFINITY:(((sx>0?x+1:x)*16)-eye.field_1352)/ray.field_1352;
        double tz=Math.abs(ray.field_1350)<1e-12?Double.POSITIVE_INFINITY:(((sz>0?z+1:z)*16)-eye.field_1350)/ray.field_1350;
        double dx=Math.abs(ray.field_1352)<1e-12?Double.POSITIVE_INFINITY:16/Math.abs(ray.field_1352);
        double dz=Math.abs(ray.field_1350)<1e-12?Double.POSITIVE_INFINITY:16/Math.abs(ray.field_1350);
        while(true){
            if(!owner.method_51469().method_8393(x,z))return false;
            if(Math.min(tx,tz)>distance)return true;
            if(tx<tz){x+=sx;tx+=dx;}else if(tz<tx){z+=sz;tz+=dz;}else{x+=sx;z+=sz;tx+=dx;tz+=dz;}
        }
    }
    private BishopDesignationTargeting() { }
}
