package dev.killerranking.combat;

import dev.killerranking.data.MoraleState;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3222;

public final class MoraleService {
    public static void afterHit(class_1309 victim, class_1282 source, double actualDamage) {
        if (victim.method_37908().field_9236 || BleedingDamage.current(victim)
            || !(source.method_5529() instanceof class_1309 attacker) || attacker == victim) return;
        if (victim instanceof class_3222 player && !player.method_7325())
            MoraleState.set(player, MoraleRules.received(MoraleState.get(player)));
        if (actualDamage > 0 && attacker instanceof class_3222 player && !player.method_7325())
            MoraleState.set(player, MoraleRules.dealt(MoraleState.get(player), actualDamage));
    }
    private MoraleService() { }
}
