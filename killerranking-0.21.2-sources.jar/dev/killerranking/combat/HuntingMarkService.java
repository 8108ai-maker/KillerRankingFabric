package dev.killerranking.combat;

import dev.killerranking.Trait;
import dev.killerranking.data.PlayerProfiles;
import dev.killerranking.network.HuntingMarkPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class HuntingMarkService {
    private final HuntingMarks marks = new HuntingMarks();
    private final Map<UUID, Long> lastBleed = new HashMap<>();
    private static boolean eligible(class_3222 p) { return p != null && dev.killerranking.data.TraitActivation.enabled(p) && p.method_5805() && !p.method_7325() && PlayerProfiles.get(p).trait() == Trait.POISON_AURA; }
    public void onHit(class_3222 hunter, class_1309 target) {
        if (!eligible(hunter) || target == hunter || !target.method_5805()) return;
        int level = PlayerProfiles.get(hunter).traitLevel();
        marks.set(hunter.method_5667(), target.method_5667(), target.method_37908().method_27983().method_29177().toString(), hunter.field_13995.method_30002().method_8510(),
            TraitLevels.poisonTicks(level));
        dev.killerranking.KillerRankingSounds.play(target, dev.killerranking.KillerRankingSounds.HUNT_MARK_APPLY, 0.7F, 1.0F);
        sync(hunter);
    }
    public void tick(MinecraftServer server) {
        long now = server.method_30002().method_8510();
        lastBleed.entrySet().removeIf(e -> now - e.getValue() > 200);
        for (var owner : marks.owners()) {
            var hunter = server.method_3760().method_14602(owner);
            if (hunter == null) { marks.remove(owner); continue; }
            var due = marks.due(owner, now);
            if (eligible(hunter) && due != null && due.dimension().equals(hunter.method_37908().method_27983().method_29177().toString())) {
                var entity = hunter.method_51469().method_14190(due.target());
                if (entity instanceof class_1309 victim && victim.method_5805() && !victim.method_31481()
                    && now - lastBleed.getOrDefault(due.target(), now - 20) >= 20) {
                    lastBleed.put(due.target(), now);
                    if (BleedingDamage.hit(hunter, victim)) hunter.method_51469().method_14199(
                        new net.minecraft.class_2390(new org.joml.Vector3f(.8f,.025f,.07f), .85f),
                        victim.method_23317(), victim.method_23318()+victim.method_17682()*.5, victim.method_23321(), 5, .15,.15,.15, .01);
                }
                marks.advance(owner, now);
            }
            var target = target(hunter);
            if (target == null) clear(hunter);
            else if (server.method_3780() % 5 == 0) sync(hunter);
        }
    }
    private class_1309 target(class_3222 hunter) {
        if (!eligible(hunter)) return null;
        var mark = marks.get(hunter.method_5667(), hunter.field_13995.method_30002().method_8510());
        if (mark == null || !mark.dimension().equals(hunter.method_37908().method_27983().method_29177().toString())) return null;
        var entity = hunter.method_51469().method_14190(mark.target());
        return entity instanceof class_1309 living && living.method_5805() && !living.method_31481() ? living : null;
    }
    private void sync(class_3222 hunter) {
        var target = target(hunter);
        if (target == null) { clear(hunter); return; }
        var mark = marks.get(hunter.method_5667(), hunter.field_13995.method_30002().method_8510());
        String name = target.method_5477().getString();
        if (name.length() > 80) name = name.substring(0, 80);
        send(hunter, new HuntingMarkPayload(true, name, target.method_23317(), target.method_23318(), target.method_23321(),
            (int) (mark.expires() - hunter.field_13995.method_30002().method_8510()), 1));
    }
    private void send(class_3222 hunter, HuntingMarkPayload payload) {
        if (ServerPlayNetworking.canSend(hunter, HuntingMarkPayload.TYPE)) ServerPlayNetworking.send(hunter, payload);
    }
    public void clear(class_3222 hunter) { marks.remove(hunter.method_5667()); send(hunter, HuntingMarkPayload.CLEAR); }
    public void clear() { marks.clear(); lastBleed.clear(); }
}
