package dev.killerranking.combat;

import dev.killerranking.Trait;
import dev.killerranking.data.MadnessSurvivalState;
import dev.killerranking.data.PlayerProfiles;
import dev.killerranking.data.TraitActivation;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_8111;
import net.minecraft.server.MinecraftServer;

public final class MadnessSurvivalService {
    public static long now(class_3222 p) { return p.field_13995.method_30002().method_8510(); }
    public static boolean eligible(class_3222 p) {
        return p.method_5805() && !p.method_7325() && !p.method_7337() && TraitActivation.enabled(p)
            && PlayerProfiles.get(p).trait() == Trait.MIXED_MADNESS;
    }
    public static void cancel(class_3222 p) {
        var old = MadnessSurvivalState.get(p);
        var next = old.cancelProtection();
        if (next != old) {
            MadnessSurvivalState.set(p, next);
            if (p.method_5805() && !p.method_7325() && !p.method_7337()) {
                p.method_6092(new class_1293(class_1294.field_5909, MadnessSurvival.AFTER_EFFECT_TICKS, 0));
                p.method_6092(new class_1293(class_1294.field_38092, MadnessSurvival.AFTER_EFFECT_TICKS, 0));
            }
        }
    }
    public static void refresh(class_3222 p) {
        var state = MadnessSurvivalState.get(p);
        if (state.protectedUntil() > 0 && state.protectedTicks(now(p)) == 0) cancel(p);
        if (!eligible(p)) { cancel(p); return; }
        if (MadnessSurvival.atHalfHeart(p.method_6032())) activate(p);
    }
    private static boolean activate(class_3222 p) {
        var before = MadnessSurvivalState.get(p);
        long time = now(p);
        if (!before.ready(time)) return false;
        MadnessSurvivalState.set(p, before.activate(time));
        if (p.method_6032() < MadnessSurvival.HALF_HEART) p.method_6033(MadnessSurvival.HALF_HEART);
        dev.killerranking.KillerRankingSounds.play(p, dev.killerranking.KillerRankingSounds.MADNESS_SURVIVE, 1.0F, 1.0F);
        p.method_43496(class_2561.method_43470("§c미친 고씨 발동 · 15초간 체력 반 칸 유지 · 종료 후 구속Ⅰ·어둠 5초 · 재사용 300초"));
        return true;
    }
    public static void tick(MinecraftServer server) { for (var p : server.method_3760().method_14571()) refresh(p); }
    public static int protectedTicks(class_3222 p) { return eligible(p) ? MadnessSurvivalState.get(p).protectedTicks(now(p)) : 0; }
    public static int cooldownTicks(class_3222 p) { return MadnessSurvivalState.get(p).cooldownTicks(now(p)); }
    /** Invoked only after armor, resistance and absorption have determined actual health damage. */
    public static float limitDamage(class_3222 p, class_1282 source, float damage) {
        if (source.method_49708(class_8111.field_44869) || !eligible(p) || damage <= 0) return damage;
        refresh(p);
        if (protectedTicks(p) > 0 || MadnessSurvival.crossesHalfHeart(p.method_6032(), damage) && activate(p))
            return Math.min(damage, MadnessSurvival.damageToHalfHeart(p.method_6032()));
        return damage;
    }
    private MadnessSurvivalService() { }
}
