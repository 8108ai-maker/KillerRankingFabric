package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public final class RushService {
    private record Cast(long started,class_5321<class_1937> dimension) { }
    private final Map<UUID,Cast> casts=new HashMap<>();
    private final Map<UUID,RushStatusPayload> sent=new HashMap<>();
    public static boolean branch(class_3222 p) {
        return PlayerProfiles.get(p).trait()==Trait.FIGHTING_SPIRIT && SpiritState.get(p).branch()==SpiritBranch.TTEOKBAL;
    }
    private static boolean eligible(class_3222 p) { return branch(p)&&p.method_5805()&&!p.method_7325()&&TraitActivation.enabled(p); }
    private static long now(class_3222 p) { return p.field_13995.method_30002().method_8510(); }
    public void unlock(class_3222 p) {
        if(!branch(p)||!p.method_5805()||p.method_7325()) return;
        var state=RushState.get(p);var profile=PlayerProfiles.get(p);
        if(state.unlocked()) { sync(p);return; }
        if(BishopState.get(p).unlocked()||CheckmateState.get(p).unlocked()||RookState.get(p).unlocked()||CleaveState.get(p).unlocked()) { dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c투기 스킬은 연타·체크 메이트·잡기·일도양단·신의 부름 중 하나만 해금할 수 있습니다."));sync(p);return; }
        if(profile.pointUnits()<KillerPoints.whole(RushRules.COST)) { dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c연타 해금에는 1,000포인트가 필요합니다."));sync(p);return; }
        PlayerProfiles.set(p,profile.addPoints(-RushRules.COST));RushState.set(p,state.unlock());
        dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_PURCHASE,1f,1f);p.method_43496(class_2561.method_43470("§a떡발의 연타 해금 완료! 1,000포인트 사용 · 기본 키 Z"));
        KillerRankingMod.assignAndSync(p);sync(p);
    }
    public void start(class_3222 p) {
        if(KillerRankingMod.CLEAVE.active(p)||!eligible(p)||KillerRankingMod.ROOK.locked(p)||KillerRankingMod.ROOK.active(p)||KillerRankingMod.CHECKMATE.active(p)||p.method_6115()||casts.containsKey(p.method_5667())||KillerRankingMod.PARRY.window(p)>0) return;
        var state=RushState.get(p);
        if(!state.unlocked()||state.cooldown(now(p))>0) return;
        RushState.set(p,state.cast(now(p)));casts.put(p.method_5667(),new Cast(now(p),p.method_37908().method_27983()));
        broadcast(p);sync(p);
    }
    public boolean active(class_3222 p) { return remaining(p)>0; }
    public int remaining(class_3222 p) {
        var cast=casts.get(p.method_5667());return cast==null?0:(int)Math.clamp(RushRules.DURATION-(now(p)-cast.started()),0,RushRules.DURATION);
    }
    public void refresh(class_3222 p) {
        var cast=casts.get(p.method_5667());
        if(cast!=null && (!eligible(p)||!cast.dimension().equals(p.method_37908().method_27983())||p.method_6115())) cancel(p);
    }
    public void tick(MinecraftServer server) {
        for(var p:server.method_3760().method_14571()) {
            refresh(p);var cast=casts.get(p.method_5667());
            if(cast!=null) {
                int age=(int)(now(p)-cast.started());
                if(age>=RushRules.DURATION) cancel(p);
                else {
                    if(RushRules.strikesAt(age)) strike(p,age==RushRules.DURATION-1);
                    if(age%10==0) broadcast(p);
                }
            }
            if(server.method_3780()%2==0) sync(p);
        }
    }
    private void strike(class_3222 p,boolean finisher) {
        var eye=p.method_33571();var direction=p.method_5720();
        class_1309 target=p.method_51469().method_8390(class_1309.class,p.method_5829().method_1014(RushRules.RANGE),
            e->e!=p&&e.method_5805()&&!e.method_7325()&&e.method_5732()&&!p.method_5722(e)&&p.method_18395(e))
            .stream().filter(e->{
                var point=e.method_5829().method_1005();var to=point.method_1020(eye);double distance=to.method_1027();
                return RushRules.inFront(distance,distance<.0001?1:direction.method_1026(to.method_1029()))&&p.method_6057(e);
            }).min(Comparator.comparingDouble(p::method_5858)).orElse(null);
        boolean hit=target!=null&&RushDamage.hit(p,target,finisher);
        if(hit) {
            var contact=target.method_5829().method_1005().method_1019(direction.method_1021(-target.method_17681()*.45));
            p.method_51469().method_43128(null,contact.field_1352,contact.field_1351,contact.field_1350,dev.killerranking.KillerRankingSounds.RUSH_PUNCH,
                class_3419.field_15248,finisher?.9f:.65f,.65f+p.method_59922().method_43057()*.16f);
            p.method_51469().method_14199(class_2398.field_11205,contact.field_1352,contact.field_1351,contact.field_1350,finisher?9:5,.09,.12,.09,.12);
            p.method_51469().method_14199(class_2398.field_11208,contact.field_1352,contact.field_1351,contact.field_1350,finisher?4:2,.06,.08,.06,.05);
        } else {
            p.method_51469().method_43128(null,p.method_23317(),p.method_23318()+1,p.method_23321(),dev.killerranking.KillerRankingSounds.SWING_FIST,
                class_3419.field_15248,.22f,.95f+p.method_59922().method_43057()*.15f);
        }
    }
    public void cancel(class_3222 p) { if(casts.remove(p.method_5667())!=null) { broadcast(p);sync(p); } }
    public void forget(class_3222 p) { cancel(p);sent.remove(p.method_5667()); }
    public void clear() { casts.clear();sent.clear(); }
    public void sync(class_3222 p) {
        var state=RushState.get(p);var value=new RushStatusPayload(branch(p),state.unlocked(),remaining(p),state.cooldown(now(p)));
        if(!value.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,RushStatusPayload.TYPE)) {
            ServerPlayNetworking.send(p,value);sent.put(p.method_5667(),value);
        }
    }
    private void broadcast(class_3222 p) { send(p,p);for(var viewer:PlayerLookup.tracking(p)) send(p,viewer); }
    public void send(class_3222 p,class_3222 viewer) {
        int remaining=remaining(p);int age=remaining==0?0:RushRules.DURATION-remaining;
        if(ServerPlayNetworking.canSend(viewer,RushVisualPayload.TYPE)) ServerPlayNetworking.send(viewer,new RushVisualPayload(p.method_5667(),remaining,age));
    }
}
