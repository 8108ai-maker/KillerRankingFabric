package dev.killerranking.combat;

import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

/** A scoped damage-over-time hit cannot renew marks, generate XP/morale, or inherit attack bonuses. */
public final class BleedingDamage {
    public static final class_5321<class_8110> TYPE = class_5321.method_29179(class_7924.field_42534,
        class_2960.method_60655("killerranking", "bleeding"));
    private static final ThreadLocal<class_1309> CURRENT = new ThreadLocal<>();
    private static final ThreadLocal<Float> AMOUNT = new ThreadLocal<>();
    public static boolean current(class_1309 victim) { return CURRENT.get() == victim; }
    public static float amount(class_1309 victim) { return current(victim)&&AMOUNT.get()!=null?AMOUNT.get():1; }
    public static boolean hit(class_3222 hunter, class_1309 target) {
        return hit(hunter,target,1);
    }
    public static boolean hit(class_3222 hunter,class_1309 target,float amount) {
        class_1309 previous = CURRENT.get(); CURRENT.set(target);
        Float previousAmount=AMOUNT.get();AMOUNT.set(amount);
        try {
            var holder=target.method_56673().method_30530(class_7924.field_42534).method_40290(TYPE);
            var source = hunter==null?new class_1282(holder):new class_1282(holder,hunter);
            return RushDamage.hit(hunter, target, source, amount, false);
        } finally { if (previous == null) CURRENT.remove(); else CURRENT.set(previous);if(previousAmount==null)AMOUNT.remove();else AMOUNT.set(previousAmount); }
    }
    private BleedingDamage() { }
}
