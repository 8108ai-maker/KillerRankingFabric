package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public final class CheckmateService {
    private static final class Aim {
        final long started;final class_5321<class_1937> dimension;final class_1799 weapon;
        final class_243 origin;final List<class_243> tiles;
        Aim(class_3222 p,List<class_243> tiles) {
            started=now(p);dimension=p.method_37908().method_27983();weapon=p.method_6047();
            origin=p.method_19538();this.tiles=List.copyOf(tiles);
        }
    }
    private static final class Cast {
        final long started;
        final class_5321<class_1937> dimension;
        final class_1799 weapon;
        final class_243 origin;
        final List<class_243> tiles;
        final int selected;
        class_243 lastSafe;
        boolean struck;
        Cast(class_3222 p,long started,List<class_243> tiles,int selected) {
            this.started=started;dimension=p.method_37908().method_27983();weapon=p.method_6047();
            origin=p.method_19538();lastSafe=origin;this.tiles=List.copyOf(tiles);this.selected=selected;
        }
        class_243 destination() { return tiles.get(selected); }
    }
    private final Map<UUID,Cast> casts=new HashMap<>();
    private final Map<UUID,Aim> aims=new HashMap<>();
    private final Map<UUID,CheckmateStatusPayload> sent=new HashMap<>();
    public static boolean branch(class_3222 p) {
        return PlayerProfiles.get(p).trait()==Trait.FIGHTING_SPIRIT&&SpiritState.get(p).branch()==SpiritBranch.KING_AND_KILL;
    }
    private static boolean eligible(class_3222 p) {
        return branch(p)&&CheckmateState.get(p).unlocked()&&p.method_5805()&&!p.method_7325()&&TraitActivation.enabled(p)
            &&p.method_6047().method_31574(KillerRankingMod.NIGHT_BARBED_BAT)&&!p.method_6115()&&!p.method_5765()&&!KillerRankingMod.ROOK.locked(p);
    }
    private static long now(class_3222 p) { return p.field_13995.method_30002().method_8510(); }
    public void unlock(class_3222 p) {
        if(!branch(p)||!p.method_5805()||p.method_7325()) return;
        if(CheckmateState.get(p).unlocked()) { sync(p);return; }
        if(BishopState.get(p).unlocked()||RushState.get(p).unlocked()||RookState.get(p).unlocked()||CleaveState.get(p).unlocked()) { dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c투기 스킬은 하나만 해금할 수 있습니다. 나이트·룩·폰 6·비숍 중 하나를 선택하세요."));sync(p);return; }
        var profile=PlayerProfiles.get(p);
        if(profile.pointUnits()<KillerPoints.whole(CheckmateRules.COST)) { dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c체크 메이트 해금에는 1,000포인트가 필요합니다."));sync(p);return; }
        PlayerProfiles.set(p,profile.addPoints(-CheckmateRules.COST));dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_PURCHASE,1f,1f);
        setOwned(p,true);
        p.method_43496(class_2561.method_43470("§f체크 메이트 해금 완료! 1,000포인트 사용 · 기본 키 Z"));
    }
    /** Existing operator ownership commands also grant/revoke the actual skill. Cooldown is retained. */
    public void setOwned(class_3222 p,boolean owned) {
        if(owned) {
            KillerRankingMod.BISHOP.forget(p);BishopState.set(p,BishopState.get(p).owned(false));
            KillerRankingMod.CLEAVE.cancel(p);CleaveState.set(p,CleaveState.get(p).owned(false));
            KillerRankingMod.ROOK.cancel(p);RookState.set(p,RookState.get(p).owned(false));
            KillerRankingMod.RUSH.cancel(p);RushState.set(p,new RushState(false,RushState.get(p).readyAt()));
        }
        CheckmateState.set(p,CheckmateState.get(p).owned(owned));
        SpiritState.set(p,new SpiritState(SpiritState.get(p).branch(),owned));
        KillerRankingMod.assignAndSync(p);
    }
    public void start(class_3222 p) {
        if(KillerRankingMod.CLEAVE.active(p)||!eligible(p)||!p.method_24828()||p.method_5816()||p.method_5771()||active(p)
            ||KillerRankingMod.RUSH.active(p)||KillerRankingMod.PARRY.window(p)>0) return;
        var state=CheckmateState.get(p);
        if(state.cooldown(now(p))>0) return;
        var origin=p.method_19538();var tiles=new ArrayList<class_243>();
        for(var move:CheckmateBoard.MOVES) {
            var candidate=CheckmateBoard.endpoint(origin,move);var floor=floor(p,candidate);
            if(floor!=null) tiles.add(floor);
        }
        if(tiles.isEmpty()) { p.method_7353(class_2561.method_43470("§7체크 메이트로 도약할 공간과 도착 발판이 없습니다."),true);return; }
        aims.put(p.method_5667(),new Aim(p,tiles));
        broadcast(p);sync(p);
    }
    /** Releasing Z is the only operation that commits a destination and spends cooldown. */
    public void confirm(class_3222 p,int selected) {
        var aim=aims.get(p.method_5667());
        if(aim==null) return;
        if(selected<0||selected>=aim.tiles.size()||!validAim(p,aim)
            ||CheckmateState.get(p).cooldown(now(p))>0) { cancel(p);return; }
        var destination=aim.tiles.get(selected);var currentFloor=floor(p,destination);
        if(currentFloor==null||currentFloor.method_1025(destination)>.01||!clearPath(p,p.method_19538(),destination)) {
            cancel(p);p.method_7353(class_2561.method_43470("§7선택한 칸으로 도약할 공간이 없습니다."),true);return;
        }
        aims.remove(p.method_5667());
        CheckmateState.set(p,CheckmateState.get(p).cast(now(p)));
        casts.put(p.method_5667(),new Cast(p,now(p),aim.tiles,selected));broadcast(p);sync(p);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.CHECKMATE_JUMP,class_3419.field_15248,.9f,1f);
    }
    private static boolean validAim(class_3222 p,Aim aim) {
        return eligible(p)&&p.method_24828()&&!p.method_5816()&&!p.method_5771()
            &&aim.dimension.equals(p.method_37908().method_27983())&&aim.weapon==p.method_6047()
            &&aim.origin.method_1025(p.method_19538())<=.1225&&now(p)-aim.started<CheckmateRules.AIM_DURATION;
    }
    public boolean aiming(class_3222 p) { return aims.containsKey(p.method_5667()); }
    public boolean active(class_3222 p) { return aiming(p)||remaining(p)>0; }
    public int remaining(class_3222 p) {
        var c=casts.get(p.method_5667());return c==null?0:(int)Math.clamp(CheckmateRules.DURATION-(now(p)-c.started),0,CheckmateRules.DURATION);
    }
    public void refresh(class_3222 p) {
        var spirit=SpiritState.get(p);var skill=CheckmateState.get(p);
        // Import old releases' checkmate flag without charging existing owners.
        if(spirit.checkmate()&&!skill.unlocked()) { skill=skill.owned(true);CheckmateState.set(p,skill); }
        if(branch(p)&&skill.unlocked()!=spirit.checkmate()) SpiritState.set(p,new SpiritState(spirit.branch(),skill.unlocked()));
        var c=casts.get(p.method_5667());
        if(c!=null&&(!eligible(p)||!c.dimension.equals(p.method_37908().method_27983())||c.weapon!=p.method_6047())) cancel(p);
        var aim=aims.get(p.method_5667());if(aim!=null&&!validAim(p,aim)) cancel(p);
    }
    public void tick(MinecraftServer server) {
        for(var p:server.method_3760().method_14571()) {
            refresh(p);var c=casts.get(p.method_5667());
            if(c!=null) {
                int age=(int)(now(p)-c.started);
                if(age>=CheckmateRules.DURATION) cancel(p);
                else {
                    if(age<=CheckmateRules.HIT) {
                        var desired=CheckmateBoard.position(c.origin,c.destination(),age);
                        if(!clearSegment(p,c.lastSafe,desired)) { cancel(p);continue; }
                        p.method_18799(class_243.field_1353);p.field_6017=0;
                        // Relative rotation preserves mouse input that arrives between server position corrections.
                        p.method_48105(p.method_51469(),desired.field_1352,desired.field_1351,desired.field_1350,
                            Set.of(class_2709.field_12397,class_2709.field_12401),p.method_36454(),p.method_36455());
                        c.lastSafe=desired;
                    }
                    if(age>=CheckmateRules.HIT&&!c.struck) { c.struck=true;p.method_24830(true);strike(p,c); }
                    if(age%8==0) broadcast(p);
                }
            }
            if(aims.containsKey(p.method_5667())&&server.method_3780()%4==0) broadcast(p);
            if(server.method_3780()%2==0) sync(p);
        }
    }
    private static class_243 floor(class_3222 p,class_243 point) {
        if(!p.method_51469().method_22340(class_2338.method_49638(point))) return null;
        var hit=p.method_51469().method_17742(new class_3959(point.method_1031(0,1.5,0),point.method_1031(0,-3,0),class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
        if(hit.method_17783()!=class_239.class_240.field_1332||hit.method_17780()!=net.minecraft.class_2350.field_11036) return null;
        var landing=new class_243(point.field_1352,hit.method_17784().field_1351,point.field_1350);
        if(!p.method_51469().method_8316(class_2338.method_49638(landing.method_1031(0,.01,0))).method_15769()) return null;
        return clearBox(p,landing)?landing:null;
    }
    private static boolean clearBox(class_3222 p,class_243 position) {
        var box=p.method_5829().method_997(position.method_1020(p.method_19538())).method_1011(.001);
        return !p.method_51469().method_20812(p,box).iterator().hasNext();
    }
    private static boolean clearSegment(class_3222 p,class_243 a,class_243 b) {
        int steps=Math.max(1,(int)Math.ceil(a.method_1022(b)/.18));
        for(int i=1;i<=steps;i++) if(!clearBox(p,a.method_35590(b,(double)i/steps))) return false;
        return true;
    }
    private static boolean clearPath(class_3222 p,class_243 origin,class_243 destination) {
        var previous=origin;
        for(int age=CheckmateRules.HOP;age<=CheckmateRules.HIT;age++) {
            var next=CheckmateBoard.position(origin,destination,age);
            if(!clearSegment(p,previous,next)) return false;previous=next;
        }
        return true;
    }
    private static boolean enemy(class_3222 p,class_1309 e) {
        return e!=p&&e.method_5805()&&!e.method_7325()&&e.method_5732()&&!p.method_5722(e)&&p.method_18395(e);
    }
    private void strike(class_3222 p,Cast c) {
        var landing=c.destination();double half=CheckmateBoard.HALF;
        var area=new class_238(landing.field_1352-half,landing.field_1351-.25,landing.field_1350-half,landing.field_1352+half,landing.field_1351+2.5,landing.field_1350+half);
        class_1309 target=p.method_51469().method_8390(class_1309.class,area,
            e->enemy(p,e)&&CheckmateBoard.occupies(landing,e.method_5829(),e.method_23318())&&p.method_6057(e))
            .stream().min(Comparator.comparingDouble(e->e.method_19538().method_1025(landing))).orElse(null);
        boolean hit=target!=null&&CheckmateDamage.hit(p,target);
        if(hit) {
            c.weapon.method_7970(2,p,class_1304.field_6173);
            target.method_6005(.65,c.origin.field_1352-target.method_23317(),c.origin.field_1350-target.method_23321());
            p.method_51469().method_14199(class_2398.field_11205,target.method_23317(),target.method_23318()+target.method_17682()*.55,target.method_23321(),10,.2,.25,.2,.08);
        }
        var impact=landing;
        p.method_51469().method_14199(class_2398.field_11203,impact.field_1352,impact.field_1351+.12,impact.field_1350,18,.65,.08,.65,.045);
        p.method_51469().method_14199(class_2398.field_17909,impact.field_1352,impact.field_1351+.5,impact.field_1350,1,0,0,0,0);
        p.method_51469().method_43128(null,impact.field_1352,impact.field_1351,impact.field_1350,dev.killerranking.KillerRankingSounds.CHECKMATE_SLAM,
            class_3419.field_15248,.8f,.65f);
        if(hit)p.method_51469().method_43128(null,impact.field_1352,impact.field_1351,impact.field_1350,dev.killerranking.KillerRankingSounds.HIT_BLUNT,class_3419.field_15248,.8f,.8f);
    }
    public void cancel(class_3222 p) {
        boolean changed=casts.remove(p.method_5667())!=null;
        changed=aims.remove(p.method_5667())!=null||changed;
        if(changed) { p.field_6017=0;broadcast(p);sync(p); }
    }
    public void forget(class_3222 p) { cancel(p);sent.remove(p.method_5667()); }
    public void clear() { casts.clear();aims.clear();sent.clear(); }
    public void sync(class_3222 p) {
        var state=CheckmateState.get(p);
        var value=new CheckmateStatusPayload(branch(p),state.unlocked(),BishopState.get(p).unlocked()||RushState.get(p).unlocked()||RookState.get(p).unlocked()||CleaveState.get(p).unlocked(),remaining(p),state.cooldown(now(p)));
        if(!value.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,CheckmateStatusPayload.TYPE)) {
            ServerPlayNetworking.send(p,value);sent.put(p.method_5667(),value);
        }
    }
    private void broadcast(class_3222 p) { send(p,p);for(var viewer:PlayerLookup.tracking(p)) send(p,viewer); }
    public void send(class_3222 p,class_3222 viewer) {
        int remaining=remaining(p),age=remaining==0?0:CheckmateRules.DURATION-remaining;
        var cast=casts.get(p.method_5667());
        var aim=aims.get(p.method_5667());
        if(aim!=null) { age=(int)(now(p)-aim.started);remaining=CheckmateRules.AIM_DURATION-age; }
        if(ServerPlayNetworking.canSend(viewer,CheckmateVisualPayload.TYPE)) ServerPlayNetworking.send(viewer,new CheckmateVisualPayload(p.method_5667(),remaining,age,
            cast!=null?cast.origin:aim!=null?aim.origin:class_243.field_1353,cast!=null?cast.tiles:aim!=null?aim.tiles:List.of(),
            cast!=null?cast.selected:aim!=null?CheckmateBoard.select(p.method_33571(),p.method_5720(),aim.tiles):-1,aim!=null));
    }
}
