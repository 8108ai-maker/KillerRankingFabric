package dev.killerranking.combat;
import dev.killerranking.*;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import java.util.*;

public final class CleaveService {
    private static final class Action {
        long started;int phase=CleaveRules.CHARGING;boolean full,blocked,struck;
        final class_5321<class_1937> dimension;final class_1799 weapon;
        class_243 origin,direction;
        final Set<UUID> hits=new HashSet<>();
        Action(class_3222 p){started=now(p);dimension=p.method_37908().method_27983();weapon=p.method_6047();}
    }
    private final Map<UUID,Action> actions=new HashMap<>();
    private final Map<UUID,CleaveStatusPayload> sent=new HashMap<>();
    public static boolean branch(class_3222 p){return PlayerProfiles.get(p).trait()==Trait.FIGHTING_SPIRIT&&SpiritState.get(p).branch()==SpiritBranch.KING_AND_KILL;}
    private static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    private static boolean eligible(class_3222 p){return branch(p)&&CleaveState.get(p).unlocked()&&TraitActivation.enabled(p)&&p.method_5805()&&!p.method_7325()
        &&p.method_6047().method_31574(KillerRankingMod.PAWN6_KATANA)&&!p.method_6115()&&!p.method_5765()&&!p.method_5816()&&!p.method_5771()&&!KillerRankingMod.ROOK.locked(p);}
    public void request(class_3222 p,CleaveRequestPayload r){switch(r.operation()){
        case CleaveRequestPayload.START->start(p);case CleaveRequestPayload.RELEASE->release(p);
        case CleaveRequestPayload.CANCEL->cancel(p);case CleaveRequestPayload.UNLOCK->unlock(p);
    }}
    public void unlock(class_3222 p){
        if(!branch(p)||!p.method_5805()||p.method_7325()||KillerRankingMod.ROOK.locked(p))return;
        if(CleaveState.get(p).unlocked()){sync(p);return;}
        if(BishopState.get(p).unlocked()||RushState.get(p).unlocked()||CheckmateState.get(p).unlocked()||RookState.get(p).unlocked()){
            dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c투기 스킬은 하나만 해금할 수 있습니다. 나이트·룩·폰 6·비숍 중 하나를 선택하세요."));sync(p);return;
        }
        var profile=PlayerProfiles.get(p);
        if(profile.pointUnits()<KillerPoints.whole(CleaveRules.COST)){dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_DENY,.8f,1f);p.method_43496(class_2561.method_43470("§c일도양단 해금에는 1,000포인트가 필요합니다."));sync(p);return;}
        PlayerProfiles.set(p,profile.addPoints(-CleaveRules.COST));dev.killerranking.KillerRankingSounds.play(p,dev.killerranking.KillerRankingSounds.UI_PURCHASE,1f,1f);setOwned(p,true);
        p.method_43496(class_2561.method_43470("§f폰 6 스킬 해금 완료! 카타나를 들고 Z 일도양단 / X 꾹 눌러 자동 패링"));
    }
    public void setOwned(class_3222 p,boolean owned){
        cancel(p);
        if(owned){
            KillerRankingMod.BISHOP.forget(p);BishopState.set(p,BishopState.get(p).owned(false));
            KillerRankingMod.ROOK.cancel(p);RookState.set(p,RookState.get(p).owned(false));
            KillerRankingMod.CHECKMATE.cancel(p);CheckmateState.set(p,CheckmateState.get(p).owned(false));
            KillerRankingMod.RUSH.cancel(p);RushState.set(p,new RushState(false,RushState.get(p).readyAt()));
            SpiritState.set(p,new SpiritState(SpiritState.get(p).branch(),false));
        }
        CleaveState.set(p,CleaveState.get(p).owned(owned));KillerRankingMod.assignAndSync(p);
    }
    public void start(class_3222 p){
        if(!eligible(p)||!p.method_24828()||active(p)||CleaveState.get(p).cooldown(now(p))>0||KillerRankingMod.ROOK.active(p)
            ||KillerRankingMod.CHECKMATE.active(p)||KillerRankingMod.RUSH.active(p)||KillerRankingMod.PARRY.window(p)>0)return;
        actions.put(p.method_5667(),new Action(p));broadcast(p);sync(p);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.CLEAVE_CHARGE,class_3419.field_15248,.9f,1f);
    }
    public void release(class_3222 p){
        var a=actions.get(p.method_5667());if(a==null||a.phase!=CleaveRules.CHARGING)return;
        if(!valid(p,a)||CleaveState.get(p).cooldown(now(p))>0){cancel(p);return;}
        a.full=CleaveRules.full(age(p));a.phase=CleaveRules.SLASHING;a.started=now(p);a.origin=p.method_19538();
        var look=p.method_5720();a.direction=new class_243(look.field_1352,0,look.field_1350).method_1029();
        if(a.direction.method_1027()<.001){double yaw=Math.toRadians(p.method_36454());a.direction=new class_243(-Math.sin(yaw),0,Math.cos(yaw));}
        CleaveState.set(p,CleaveState.get(p).cast(now(p)));broadcast(p);sync(p);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.CLEAVE_DASH,class_3419.field_15248,.9f,a.full?.85f:1.0f);
    }
    private boolean valid(class_3222 p,Action a){return eligible(p)&&a.dimension.equals(p.method_37908().method_27983())&&a.weapon==p.method_6047();}
    public boolean active(class_3222 p){return actions.containsKey(p.method_5667());}
    public boolean slashing(class_3222 p){return phase(p)==CleaveRules.SLASHING;}
    public int phase(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:a.phase;}
    public int age(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:(int)Math.clamp(now(p)-a.started,0,CleaveRules.MAX_HOLD);}
    public void refresh(class_3222 p){var a=actions.get(p.method_5667());if(a!=null&&!valid(p,a))cancel(p);}
    public void tick(MinecraftServer server){
        for(var p:server.method_3760().method_14571()){
            refresh(p);var a=actions.get(p.method_5667());
            if(a!=null){
                int age=age(p);
                if(a.phase==CleaveRules.CHARGING){
                    if(age>=CleaveRules.MAX_HOLD){cancel(p);continue;}
                    if(age==CleaveRules.CHARGE)p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.PARRY_GUARD,class_3419.field_15248,.8f,1.2f);
                    if(age%5==0)broadcast(p);
                }else if(age>=CleaveRules.CAST)cancel(p);
                else{
                    if(a.full){pin(p,a.origin);if(age>=CleaveRules.FULL_HIT&&!a.struck){a.struck=true;strike(p,a);}}
                    else{
                        if(age>0&&age<=CleaveRules.DASH_TICKS&&!a.blocked){
                            var before=p.method_19538();p.method_5784(class_1313.field_6308,a.direction.method_1021(CleaveRules.DASH/CleaveRules.DASH_TICKS));
                            a.blocked=p.method_19538().method_1025(before)<.20;pin(p,p.method_19538());
                        }
                        if(age>=4&&age<=CleaveRules.DASH_TICKS)strike(p,a);
                    }
                    if(age%5==0)broadcast(p);
                }
            }
            if(server.method_3780()%2==0)sync(p);
        }
    }
    private static void pin(class_3222 p,class_243 at){
        p.method_18799(class_243.field_1353);p.field_6017=0;
        p.method_48105(p.method_51469(),at.field_1352,at.field_1351,at.field_1350,Set.of(class_2709.field_12401,class_2709.field_12397),p.method_36454(),p.method_36455());
    }
    private void strike(class_3222 p,Action a){
        double range=a.full?CleaveRules.FULL_RANGE:CleaveRules.DASH_REACH;
        for(var e:p.method_51469().method_8390(class_1309.class,p.method_5829().method_1009(range,2.25,range),
            e->e!=p&&e.method_5805()&&!e.method_7325()&&e.method_5732()&&!p.method_5722(e)&&p.method_18395(e)&&!a.hits.contains(e.method_5667()))){
            var to=e.method_5829().method_1005().method_1020(p.method_19538().method_1031(0,1,0));
            double forward=to.method_1026(a.direction),side=to.field_1352*a.direction.field_1350-to.field_1350*a.direction.field_1352;
            if(!CleaveRules.inSlash(forward,side,to.field_1351,a.full)||!p.method_6057(e))continue;
            a.hits.add(e.method_5667());
            if(RushDamage.hit(p,e,CleaveRules.damage(a.full),true)){
                e.method_6005(a.full?.65:.35,-a.direction.field_1352,-a.direction.field_1350);
                p.method_51469().method_14199(class_2398.field_11205,e.method_23317(),e.method_23318()+e.method_17682()*.55,e.method_23321(),8,.15,.25,.15,.06);
            }
        }
        if(a.full||!a.struck){
            a.struck=true;a.weapon.method_7970(a.full?3:2,p,class_1304.field_6173);
            p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.CLEAVE_RELEASE,class_3419.field_15248,a.full?1.1f:.8f,a.full?.9f:1.15f);
            if(a.full)p.method_51469().method_14199(class_2398.field_17909,p.method_23317(),p.method_23318()+1,p.method_23321(),1,0,0,0,0);
        }
    }
    public void cancel(class_3222 p){if(actions.remove(p.method_5667())!=null){broadcast(p);sync(p);}}
    public void forget(class_3222 p){cancel(p);sent.remove(p.method_5667());}
    public void clear(){actions.clear();sent.clear();}
    public void sync(class_3222 p){
        var state=CleaveState.get(p);var value=new CleaveStatusPayload(branch(p),state.unlocked(),BishopState.get(p).unlocked()||RushState.get(p).unlocked()||CheckmateState.get(p).unlocked()||RookState.get(p).unlocked(),phase(p),age(p),state.cooldown(now(p)));
        if(!value.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,CleaveStatusPayload.TYPE)){ServerPlayNetworking.send(p,value);sent.put(p.method_5667(),value);}
    }
    private void broadcast(class_3222 p){send(p,p);for(var viewer:PlayerLookup.tracking(p))send(p,viewer);}
    public void send(class_3222 p,class_3222 viewer){
        var a=actions.get(p.method_5667());float yaw=a!=null&&a.direction!=null?(float)Math.toDegrees(Math.atan2(-a.direction.field_1352,a.direction.field_1350)):p.method_36454();
        var payload=new CleaveVisualPayload(p.method_5667(),phase(p),age(p),a!=null&&(a.full||a.phase==CleaveRules.CHARGING&&CleaveRules.full(age(p))),yaw);
        if(ServerPlayNetworking.canSend(viewer,CleaveVisualPayload.TYPE))ServerPlayNetworking.send(viewer,payload);
    }
}
