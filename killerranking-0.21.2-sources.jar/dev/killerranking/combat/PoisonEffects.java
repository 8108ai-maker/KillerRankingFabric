package dev.killerranking.combat;

import dev.killerranking.Trait;
import dev.killerranking.data.PlayerProfiles;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public final class PoisonEffects {
    public static final class_2960 RESISTANCE = class_2960.method_60655("killerranking", "poison_knockback_resistance");
    public static int resistance(int level) { return TraitLevels.clamp(level) * 20; }
    public static final class_2960 SPEED = class_2960.method_60655("killerranking", "poison_speed");
    public static int speed(int level) { return TraitLevels.bonusPercent(15, level); }
    public static void applyPercent(class_1324 attribute, class_2960 id, int percent) {
        if (attribute == null) return;
        if (percent == 0) { attribute.method_6200(id); return; }
        double amount = percent / 100.0;
        var previous = attribute.method_6199(id);
        if (previous == null || previous.comp_2449() != amount) attribute.method_55696(
            new class_1322(id, amount, class_1322.class_1323.field_6331));
    }
    public static void apply(class_1324 attribute, int percent) {
        if (attribute == null) return;
        if (percent <= 0) { attribute.method_6200(RESISTANCE); return; }
        double amount = Math.clamp(percent / 100.0, 0, 1);
        var previous = attribute.method_6199(RESISTANCE);
        if (previous == null || previous.comp_2449() != amount) attribute.method_55696(
            new class_1322(RESISTANCE, amount, class_1322.class_1323.field_6328));
    }
    public static void refresh(class_3222 player) {
        var p = PlayerProfiles.get(player);
        boolean enabled = player.method_5805() && !player.method_7325() && dev.killerranking.data.TraitActivation.enabled(player) && p.trait() == Trait.POISON_AURA;
        apply(player.method_5996(class_5134.field_23718), enabled ? resistance(p.traitLevel()) : 0);
        applyPercent(player.method_5996(class_5134.field_23723), SPEED, enabled ? speed(p.traitLevel()) : 0);
        applyPercent(player.method_5996(class_5134.field_23719), SPEED, enabled ? speed(p.traitLevel()) : 0);
    }
    private PoisonEffects() { }
}
