package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.data.CheckmateState;
import dev.killerranking.data.TraitActivation;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_3222;

public final class KnightWeaponEffects {
    public static boolean owner(class_3222 p) {
        return p.method_5805() && !p.method_7325() && TraitActivation.enabled(p)
            && CheckmateService.branch(p) && CheckmateState.get(p).unlocked();
    }
    public static boolean holding(class_3222 p) {
        return owner(p) && (p.method_6047().method_31574(KillerRankingMod.NIGHT_BARBED_BAT)
            || p.method_6079().method_31574(KillerRankingMod.NIGHT_BARBED_BAT));
    }
    public static boolean striking(class_3222 p) {
        return owner(p) && p.method_6047().method_31574(KillerRankingMod.NIGHT_BARBED_BAT);
    }
    public static void refresh(class_3222 p) {
        if (!holding(p)) return;
        // Two-tick leases expire promptly on unequip, while stronger/longer potion effects keep vanilla priority.
        p.method_6092(new class_1293(class_1294.field_5904, 2, 0, true, false, true));
        p.method_6092(new class_1293(class_1294.field_5913, 2, 0, true, false, true));
    }
    private KnightWeaponEffects() { }
}
