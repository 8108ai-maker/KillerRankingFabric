package dev.killerranking.combat;

import java.util.List;
import net.minecraft.class_238;
import net.minecraft.class_243;

/** Two-block squares; the knight route is committed only when the aiming key is released. */
public final class CheckmateBoard {
    public static final double CELL=2, HALF=1, HEIGHT=4;
    public record Offset(int x,int z) { }
    public static final List<Offset> MOVES=List.of(new Offset(1,2),new Offset(-1,2),
        new Offset(2,1),new Offset(2,-1),new Offset(1,-2),new Offset(-1,-2),new Offset(-2,-1),new Offset(-2,1));
    public static class_243 endpoint(class_243 origin,Offset move) { return origin.method_1031(move.x()*CELL,0,move.z()*CELL); }
    public static class_243 corner(class_243 origin,class_243 destination) {
        return Math.abs(destination.field_1352-origin.field_1352)>Math.abs(destination.field_1350-origin.field_1350)
            ?new class_243(destination.field_1352,origin.field_1351,origin.field_1350):new class_243(origin.field_1352,origin.field_1351,destination.field_1350);
    }
    /** Travel two cells along one axis, then one perpendicular cell, in a single high arc. */
    public static class_243 position(class_243 origin,class_243 destination,double age) {
        double t=Math.clamp((age-CheckmateRules.HOP)/(CheckmateRules.HIT-CheckmateRules.HOP),0,1);
        var turn=corner(origin,destination);
        var horizontal=t<=2.0/3?origin.method_35590(turn,t*1.5):turn.method_35590(destination,(t-2.0/3)*3);
        return new class_243(horizontal.field_1352,origin.field_1351+(destination.field_1351-origin.field_1351)*t+4*HEIGHT*t*(1-t),horizontal.field_1350);
    }
    public static boolean occupies(class_243 tile,class_238 entity,double feetY) {
        return entity.field_1320>tile.field_1352-HALF&&entity.field_1323<tile.field_1352+HALF
            &&entity.field_1324>tile.field_1350-HALF&&entity.field_1321<tile.field_1350+HALF
            &&feetY>=tile.field_1351-.25&&feetY<=tile.field_1351+1.25;
    }
    /** Ray selection has no preference for occupied squares. Looking elsewhere cancels the cast. */
    public static int select(class_243 eye,class_243 look,List<class_243> tiles) {
        if(look.field_1351>=-1e-6) return -1;
        int selected=-1;double nearest=Double.POSITIVE_INFINITY;
        for(int i=0;i<tiles.size();i++) {
            var tile=tiles.get(i);double distance=(tile.field_1351+.025-eye.field_1351)/look.field_1351;
            if(distance<=0||distance>16||distance>=nearest) continue;
            var hit=eye.method_1019(look.method_1021(distance));
            if(Math.abs(hit.field_1352-tile.field_1352)<=HALF&&Math.abs(hit.field_1350-tile.field_1350)<=HALF) { selected=i;nearest=distance; }
        }
        return selected;
    }
    private CheckmateBoard() { }
}
