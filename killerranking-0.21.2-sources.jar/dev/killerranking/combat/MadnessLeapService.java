package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public final class MadnessLeapService {
    private static final class Action {
        final int phase;final long started;final class_5321<class_1937> dimension;final class_1799 weapon;
        final class_243 origin,destination;final UUID target;final float yaw;
        class_243 lastSafe;boolean struck;
        Action(class_3222 p,int phase,class_1309 target,class_243 destination) {
            this.phase=phase;started=now(p);dimension=p.method_37908().method_27983();weapon=p.method_6047();
            origin=p.method_19538();lastSafe=origin;this.destination=destination;this.target=target==null?null:target.method_5667();
            var d=destination.method_1020(origin);yaw=phase==MadnessLeapRules.CAST?(float)Math.toDegrees(Math.atan2(-d.field_1352,d.field_1350)):p.method_36454();
        }
    }
    private final Map<UUID,Action> actions=new HashMap<>();
    private final Map<UUID,MadnessLeapStatusPayload> sent=new HashMap<>();
    public static boolean available(class_3222 p){return PlayerProfiles.get(p).trait()==Trait.MIXED_MADNESS;}
    private static boolean eligible(class_3222 p) {
        return available(p)&&TraitActivation.enabled(p)&&p.method_5805()&&!p.method_7325()
            &&p.method_6047().method_31574(KillerRankingMod.EUNBAL_HATCHET)&&!p.method_6115()&&!p.method_5765()
            &&!p.method_5816()&&!p.method_5771()&&!KillerRankingMod.ROOK.locked(p);
    }
    private static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    public void request(class_3222 p,MadnessLeapRequestPayload request) {
        switch(request.operation()) {
            case MadnessLeapRequestPayload.START->start(p);
            case MadnessLeapRequestPayload.RELEASE->release(p,request.target());
            case MadnessLeapRequestPayload.CANCEL->cancel(p);
            default->{ }
        }
    }
    public void start(class_3222 p) {
        if(!eligible(p)||!p.method_24828()||SkillCombatLock.blocksAttack(p)||MadnessLeapState.get(p).cooldown(now(p))>0)return;
        actions.put(p.method_5667(),new Action(p,MadnessLeapRules.AIM,null,class_243.field_1353));broadcast(p);sync(p);
    }
    public void release(class_3222 p,int targetId) {
        var aim=actions.get(p.method_5667());if(aim==null||aim.phase!=MadnessLeapRules.AIM)return;
        var target=MadnessLeapTargeting.selected(p);
        if(!valid(p,aim)||!p.method_24828()||target==null||target.method_5628()!=targetId||MadnessLeapState.get(p).cooldown(now(p))>0){cancel(p);return;}
        // Stop before the target's body instead of teleporting the two entities into one another.
        var away=p.method_19538().method_1020(target.method_19538()).method_18805(1,0,1).method_1029();
        var point=target.method_19538().method_1019(away.method_1021((p.method_17681()+target.method_17681())*.5+.3));
        var destination=floor(p,point);
        if(destination==null||!clearPath(p,p.method_19538(),destination)) {
            cancel(p);p.method_7353(class_2561.method_43470("§7도약할 경로에 장애물이 있습니다."),true);return;
        }
        MadnessLeapState.set(p,MadnessLeapState.get(p).cast(now(p)));
        actions.put(p.method_5667(),new Action(p,MadnessLeapRules.CAST,target,destination));broadcast(p);sync(p);
        p.method_51469().method_8396(null,p.method_24515(),dev.killerranking.KillerRankingSounds.MADNESS_LEAP_JUMP,class_3419.field_15248,1f,1f);
    }
    private static boolean valid(class_3222 p,Action a) {
        return eligible(p)&&a.dimension.equals(p.method_37908().method_27983())&&a.weapon==p.method_6047()
            &&(a.phase!=MadnessLeapRules.AIM||p.method_24828()&&now(p)-a.started<MadnessLeapRules.MAX_HOLD);
    }
    public boolean active(class_3222 p){return actions.containsKey(p.method_5667());}
    public boolean casting(class_3222 p){var a=actions.get(p.method_5667());return a!=null&&a.phase==MadnessLeapRules.CAST;}
    public int phase(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:a.phase;}
    public void refresh(class_3222 p){var a=actions.get(p.method_5667());if(a!=null&&!valid(p,a))cancel(p);}
    public void tick(MinecraftServer server) {
        for(var p:server.method_3760().method_14571()) {
            refresh(p);var a=actions.get(p.method_5667());
            if(a!=null&&a.phase==MadnessLeapRules.CAST) {
                int age=(int)(now(p)-a.started);
                if(age>=MadnessLeapRules.DURATION){cancel(p);continue;}
                var desired=MadnessLeapRules.position(a.origin,a.destination,age);
                if(!clearSegment(p,a.lastSafe,desired)){cancel(p);continue;}
                p.method_18799(class_243.field_1353);p.field_6017=0;
                p.method_48105(p.method_51469(),desired.field_1352,desired.field_1351,desired.field_1350,
                    Set.of(class_2709.field_12397,class_2709.field_12401),p.method_36454(),p.method_36455());
                a.lastSafe=desired;
                if(age>=MadnessLeapRules.HIT&&!a.struck){a.struck=true;p.method_24830(true);strike(p,a);}
            }
            if(a!=null&&server.method_3780()%4==0)broadcast(p);
            if(server.method_3780()%2==0)sync(p);
        }
    }
    private void strike(class_3222 p,Action a) {
        var entity=p.method_51469().method_14190(a.target);
        boolean hit=entity instanceof class_1309 target&&MadnessLeapTargeting.enemy(p,target)
            &&target.method_5829().method_1009(1.25,.9,1.25).method_1006(p.method_19538().method_1031(0,.65,0))
            &&p.method_6057(target)&&RushDamage.hit(p,target,MadnessLeapRules.DAMAGE,true);
        if(hit){
            a.weapon.method_7970(2,p,class_1304.field_6173);
            p.method_51469().method_14199(class_2398.field_11205,entity.method_23317(),entity.method_23318()+entity.method_17682()*.6,entity.method_23321(),12,.25,.3,.25,.08);
        }
        var at=a.destination;
        p.method_51469().method_14199(class_2398.field_11203,at.field_1352,at.field_1351+.1,at.field_1350,14,.45,.06,.45,.04);
        p.method_51469().method_43128(null,at.field_1352,at.field_1351,at.field_1350,dev.killerranking.KillerRankingSounds.MADNESS_LEAP_LAND,class_3419.field_15248,1f,hit?1f:.9f);
    }
    private static class_243 floor(class_3222 p,class_243 point) {
        if(!p.method_51469().method_22340(class_2338.method_49638(point)))return null;
        var hit=p.method_51469().method_17742(new class_3959(point.method_1031(0,1.5,0),point.method_1031(0,-3,0),class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
        if(hit.method_17783()!=class_239.class_240.field_1332||hit.method_17780()!=class_2350.field_11036)return null;
        var landing=new class_243(point.field_1352,hit.method_17784().field_1351,point.field_1350);
        return p.method_51469().method_8316(class_2338.method_49638(landing.method_1031(0,.01,0))).method_15769()&&clearBox(p,landing)?landing:null;
    }
    private static boolean clearBox(class_3222 p,class_243 position) {
        var box=p.method_5829().method_997(position.method_1020(p.method_19538())).method_1011(.001);
        return !p.method_51469().method_20812(p,box).iterator().hasNext();
    }
    private static boolean clearSegment(class_3222 p,class_243 from,class_243 to) {
        int steps=Math.max(1,(int)Math.ceil(from.method_1022(to)/.18));
        for(int i=1;i<=steps;i++)if(!clearBox(p,from.method_35590(to,(double)i/steps)))return false;
        return true;
    }
    private static boolean clearPath(class_3222 p,class_243 from,class_243 to) {
        var previous=from;
        for(int tick=MadnessLeapRules.HOP;tick<=MadnessLeapRules.HIT;tick++) {
            var next=MadnessLeapRules.position(from,to,tick);
            if(!clearSegment(p,previous,next))return false;previous=next;
        }
        return true;
    }
    public void cancel(class_3222 p){if(actions.remove(p.method_5667())!=null){p.field_6017=0;broadcast(p);sync(p);}}
    public void forget(class_3222 p){cancel(p);sent.remove(p.method_5667());}
    public void clear(){actions.clear();sent.clear();}
    public void sync(class_3222 p) {
        var a=actions.get(p.method_5667());var value=new MadnessLeapStatusPayload(available(p),a==null?0:a.phase,
            a==null?0:(int)(now(p)-a.started),MadnessLeapState.get(p).cooldown(now(p)));
        if(!value.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,MadnessLeapStatusPayload.TYPE)){
            ServerPlayNetworking.send(p,value);sent.put(p.method_5667(),value);
        }
    }
    private void broadcast(class_3222 p){send(p,p);for(var viewer:PlayerLookup.tracking(p))send(p,viewer);}
    public void send(class_3222 p,class_3222 viewer){
        var a=actions.get(p.method_5667());
        if(ServerPlayNetworking.canSend(viewer,MadnessLeapVisualPayload.TYPE))ServerPlayNetworking.send(viewer,new MadnessLeapVisualPayload(
            p.method_5667(),a==null?0:a.phase,a==null?0:(int)(now(p)-a.started),a==null?0:a.yaw));
    }
}
