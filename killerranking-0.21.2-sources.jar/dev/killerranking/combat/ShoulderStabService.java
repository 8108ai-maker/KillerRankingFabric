package dev.killerranking.combat;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_5321;
import net.minecraft.core.particles.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.*;
import net.minecraft.world.phys.*;
import org.joml.Vector3f;
import java.util.*;

public final class ShoulderStabService {
    private static final UUID NONE=new UUID(0,0);
    private static final class Action {
        final class_3222 owner;final class_1309 target;final class_1799 weapon;final long started;
        final int phase;final class_243 origin;final class_5321<class_1937> dimension;final boolean left;
        class_243 airStart=class_243.field_1353,airCatch=class_243.field_1353;
        class_243 destination;float yaw;boolean hit;
        Action(class_3222 p,class_1309 e,int phase,class_243 destination){
            owner=p;target=e;this.phase=phase;this.destination=destination;weapon=p.method_6047();
            started=now(p);origin=p.method_19538();dimension=p.method_37908().method_27983();left=p.method_6068()==class_1306.field_6182;
            var d=e==null?p.method_5720():e.method_19538().method_1020(origin);yaw=(float)Math.toDegrees(Math.atan2(-d.field_1352,d.field_1350));
        }
    }
    private final Map<UUID,Action> actions=new HashMap<>();
    private final Map<UUID,ShoulderStabStatusPayload> sent=new HashMap<>();
    private static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    public static boolean available(class_3222 p){return SalmosaSkillService.available(p);}
    private static boolean eligible(class_3222 p){return available(p)&&TraitActivation.enabled(p)&&p.method_5805()&&!p.method_31481()&&!p.method_7325()
        &&p.method_6047().method_31574(KillerRankingMod.SALMOSA_MID_DAGGER)&&!p.method_5765()&&!p.method_6115()&&!KillerRankingMod.ROOK.locked(p);}
    public boolean active(class_3222 p){return actions.containsKey(p.method_5667());}
    public boolean casting(class_3222 p){var a=actions.get(p.method_5667());return a!=null&&a.phase>=ShoulderStabRules.CAST;}
    public int phase(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:a.phase;}
    public int age(class_3222 p){var a=actions.get(p.method_5667());return a==null?0:(int)(now(p)-a.started);}
    public void request(class_3222 p,ShoulderStabRequestPayload request){switch(request.operation()){
        case ShoulderStabRequestPayload.START->start(p);
        case ShoulderStabRequestPayload.RELEASE->release(p,request.target());
        case ShoulderStabRequestPayload.CANCEL->cancel(p);
        case ShoulderStabRequestPayload.COUNTER->counter(p);
        default->{ }
    }}
    public void start(class_3222 p){
        if(!eligible(p)||SkillCombatLock.blocksAttack(p)||ShoulderStabState.get(p).cooldown(now(p))>0)return;
        actions.put(p.method_5667(),new Action(p,null,ShoulderStabRules.AIM,p.method_19538()));broadcast(p);sync(p);
    }
    public void release(class_3222 p,int targetId){
        var aim=actions.get(p.method_5667());if(aim==null||aim.phase!=ShoulderStabRules.AIM)return;
        var target=ShoulderStabTargeting.selected(p);
        if(!valid(aim)||target==null||target.method_5628()!=targetId||ShoulderStabState.get(p).cooldown(now(p))>0){cancel(p);return;}
        var destination=landing(p,target);
        if(destination==null||!clearSegment(p,p.method_19538(),destination)){cancel(p);p.method_7353(class_2561.method_43470("§7어깨 찌르기: 접근 경로에 장애물이 있습니다."),true);return;}
        actions.put(p.method_5667(),new Action(p,target,ShoulderStabRules.CAST,destination));
        ShoulderStabState.set(p,ShoulderStabState.get(p).cast(now(p)));broadcast(p);sync(p);
    }
    public void counter(class_3222 p){
        if(!eligible(p)||active(p)||ShoulderStabState.get(p).cooldown(now(p))>0)return;
        var opportunity=KillerRankingMod.KNIFE_PURSUIT.counter(p);if(opportunity==null)return;
        var destination=landing(p,opportunity.target());if(destination==null)return;
        class_243 last=p.method_19538();
        for(int tick=1;tick<=ShoulderStabRules.COUNTER_IMPACT;tick++){
            var next=ShoulderStabRules.counterPosition(p.method_19538(),destination,opportunity.catchKnife(),tick);
            if(!clearSegment(p,last,next)){p.method_7353(class_2561.method_43470("§7공중 내려찍기: 도약 경로가 막혔습니다."),true);return;}last=next;
        }
        var action=new Action(p,opportunity.target(),ShoulderStabRules.COUNTER,destination);
        action.airStart=opportunity.knife();action.airCatch=opportunity.catchKnife();
        KillerRankingMod.KNIFE_PURSUIT.cancel(p);actions.put(p.method_5667(),action);
        ShoulderStabState.set(p,ShoulderStabState.get(p).cast(now(p)));
        sound(action,KillerRankingMod.KNIFE_PURSUIT_BLINK,.8f,1.35f);broadcast(p);sync(p);
    }
    private static boolean valid(Action a){return eligible(a.owner)&&a.weapon==a.owner.method_6047()&&a.dimension.equals(a.owner.method_37908().method_27983())
        &&(a.phase==ShoulderStabRules.AIM?now(a.owner)-a.started<ShoulderStabRules.MAX_HOLD:
            a.target.method_37908()==a.owner.method_37908()&&ShoulderStabTargeting.enemy(a.owner,a.target)&&a.owner.method_5858(a.target)<16*16);}
    public void refresh(class_3222 p){var a=actions.get(p.method_5667());if(a!=null&&!valid(a))cancel(p);}
    public void tick(MinecraftServer server){
        for(var a:new ArrayList<>(actions.values())){
            var p=a.owner;if(!valid(a)){cancel(p);continue;}int age=age(p);
            if(a.phase>=ShoulderStabRules.CAST){
                boolean counter=a.phase==ShoulderStabRules.COUNTER;
                if(age>=(counter?ShoulderStabRules.COUNTER_DURATION:ShoulderStabRules.DURATION)){cancel(p);continue;}
                if(counter){
                    var next=ShoulderStabRules.counterPosition(a.origin,a.destination,a.airCatch,age);
                    if(!clearSegment(p,p.method_19538(),next)){cancel(p);continue;}
                    move(p,next);
                    if(age==ShoulderStabRules.COUNTER_CATCH){sound(a,dev.killerranking.KillerRankingSounds.SHOULDER_STAB_CATCH,.9f,1f);broadcast(p);}
                    if(age==ShoulderStabRules.COUNTER_DROP)sound(a,dev.killerranking.KillerRankingSounds.AIR_COUNTER_DROP,1f,1f);
                }else if(age==ShoulderStabRules.BLINK){
                    var destination=landing(p,a.target);
                    if(destination==null||!clearSegment(p,a.origin,destination)||!p.method_6057(a.target)){cancel(p);continue;}
                    a.destination=destination;sound(a,KillerRankingMod.KNIFE_PURSUIT_BLINK,.9f,1.15f);smoke(p,a.origin);
                    var facing=a.target.method_19538().method_1020(destination);a.yaw=(float)Math.toDegrees(Math.atan2(-facing.field_1352,facing.field_1350));
                    move(p,destination);smoke(p,destination);sound(a,KillerRankingMod.KNIFE_PURSUIT_BLINK,.55f,1.35f);broadcast(p);
                }else move(p,ShoulderStabRules.position(a.origin,a.destination,age));
                if(age==(counter?ShoulderStabRules.COUNTER_IMPACT:ShoulderStabRules.IMPACT)&&!a.hit){
                    a.hit=true;
                    if(p.method_5858(a.target)>6.25||!p.method_6057(a.target)){cancel(p);continue;}
                    if(RushDamage.hit(p,a.target,ShoulderStabRules.DAMAGE,false)){
                        if(actions.get(p.method_5667())!=a)continue;
                        a.weapon.method_7970(1,p,class_1304.field_6173);var at=wound(a);
                        p.method_51469().method_14199(new class_2390(new Vector3f(.85f,.025f,.055f),1.1f),at.field_1352,at.field_1351,at.field_1350,14,.13,.15,.13,.03);
                        sound(a,dev.killerranking.KillerRankingSounds.SHOULDER_STAB_STAB,1f,1f);
                    }
                    broadcast(p);
                }
            }
            if(server.method_3780()%2==0&&actions.get(p.method_5667())==a)broadcast(p);
        }
        if(server.method_3780()%2==0)for(var p:server.method_3760().method_14571())sync(p);
    }
    private static class_243 wound(Action a){return a.target==null?a.origin:ShoulderStabRules.shoulder(a.target.method_19538(),a.target.method_17681(),a.target.method_17682(),a.yaw,a.left);}
    private static class_243 landing(class_3222 p,class_1309 target){
        var forward=target.method_19538().method_1020(p.method_19538()).method_18805(1,0,1).method_1029();if(forward.method_1027()<.1)forward=class_243.method_1030(0,p.method_36454());
        var side=new class_243(forward.field_1350,0,-forward.field_1352);double gap=(p.method_17681()+target.method_17681())*.5+.45;
        var point=target.method_19538().method_1020(forward.method_1021(gap)).method_1019(side.method_1021(p.method_6068()==class_1306.field_6182?.18:-.18));
        if(!p.method_51469().method_22340(class_2338.method_49638(point)))return null;
        var hit=p.method_51469().method_17742(new class_3959(point.method_1031(0,1.5,0),point.method_1031(0,-3,0),class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
        if(hit.method_17783()!=class_239.class_240.field_1332||hit.method_17780()!=class_2350.field_11036)return null;
        var at=new class_243(point.field_1352,hit.method_17784().field_1351,point.field_1350);
        return p.method_51469().method_8316(class_2338.method_49638(at.method_1031(0,.01,0))).method_15769()&&clearBox(p,at)?at:null;
    }
    private static boolean clearBox(class_3222 p,class_243 at){return !p.method_51469().method_20812(p,p.method_5829().method_997(at.method_1020(p.method_19538())).method_1011(.001)).iterator().hasNext();}
    private static boolean clearSegment(class_3222 p,class_243 from,class_243 to){int count=Math.max(1,(int)Math.ceil(from.method_1022(to)/.15));for(int i=1;i<=count;i++)if(!clearBox(p,from.method_35590(to,(double)i/count)))return false;return true;}
    private static void move(class_3222 p,class_243 at){p.method_18799(class_243.field_1353);p.field_6017=0;if(p.method_19538().method_1025(at)>.00001)p.method_48105(p.method_51469(),at.field_1352,at.field_1351,at.field_1350,Set.of(),p.method_36454(),p.method_36455());}
    private static void smoke(class_3222 p,class_243 at){p.method_51469().method_14199(class_2398.field_11203,at.field_1352,at.field_1351+.95,at.field_1350,14,.18,.5,.18,.04);}
    private static void sound(Action a,class_3414 event,float volume,float pitch){a.owner.method_51469().method_8396(null,a.owner.method_24515(),event,class_3419.field_15248,volume,pitch);}
    public void cancel(class_3222 p){var a=actions.remove(p.method_5667());if(a!=null){p.field_6017=0;send(a,true);sync(p);}}
    public void forget(class_1297 e){for(var a:new ArrayList<>(actions.values()))if(a.owner==e||a.target==e)cancel(a.owner);sent.remove(e.method_5667());}
    public void clear(){for(var a:new ArrayList<>(actions.values()))cancel(a.owner);actions.clear();sent.clear();}
    public void sync(class_3222 p){var a=actions.get(p.method_5667());var status=new ShoulderStabStatusPayload(available(p),a==null?0:a.phase,a==null?0:age(p),ShoulderStabState.get(p).cooldown(now(p)));
        if(!status.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,ShoulderStabStatusPayload.TYPE)){ServerPlayNetworking.send(p,status);sent.put(p.method_5667(),status);}}
    private void broadcast(class_3222 p){var a=actions.get(p.method_5667());if(a!=null)send(a,false);}
    private void send(Action a,boolean ending){var viewers=new HashSet<>(PlayerLookup.tracking(a.owner));viewers.add(a.owner);if(a.target!=null){viewers.addAll(PlayerLookup.tracking(a.target));if(a.target instanceof class_3222 p)viewers.add(p);}for(var viewer:viewers)send(a,viewer,ending);}
    public void send(class_3222 p,class_3222 viewer){var a=actions.get(p.method_5667());if(a!=null)send(a,viewer,false);}
    private void send(Action a,class_3222 viewer,boolean ending){if(ServerPlayNetworking.canSend(viewer,ShoulderStabVisualPayload.TYPE))ServerPlayNetworking.send(viewer,new ShoulderStabVisualPayload(a.owner.method_5667(),a.target==null?NONE:a.target.method_5667(),ending?0:a.phase,(int)Math.clamp(now(a.owner)-a.started,0,ShoulderStabRules.MAX_HOLD),a.yaw,a.origin,wound(a),a.destination,a.airStart,a.airCatch));}
}
