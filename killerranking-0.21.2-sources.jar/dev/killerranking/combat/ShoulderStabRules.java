package dev.killerranking.combat;
import net.minecraft.class_243;

/** A short windup, one instantaneous approach and one shoulder contact. */
public final class ShoulderStabRules {
    public static final int COUNTER=3, COUNTER_CATCH=6, COUNTER_DROP=10, COUNTER_IMPACT=12, COUNTER_DURATION=26;
    public static class_243 counterPosition(class_243 from,class_243 landing,class_243 catchKnife,double age){
        double across=ease(age/4),rise=ease(age/COUNTER_CATCH),drop=ease((age-COUNTER_DROP)/(COUNTER_IMPACT-COUNTER_DROP));
        double peak=Math.max(landing.field_1351+.6,catchKnife.field_1351-1.85);
        return new class_243(from.field_1352+(landing.field_1352-from.field_1352)*across,(from.field_1351+(peak-from.field_1351)*rise)*(1-drop)+landing.field_1351*drop,from.field_1350+(landing.field_1350-from.field_1350)*across);
    }
    public static class_243 counterKnife(class_243 from,class_243 catchKnife,double age){return from.method_35590(catchKnife,ease(age/COUNTER_CATCH));}
    private static double ease(double t){t=Math.clamp(t,0,1);return t*t*(3-2*t);}
    public static final int AIM=1,CAST=2,MAX_HOLD=200,BLINK=4,IMPACT=8,WITHDRAW=14,DURATION=24,COOLDOWN=400;
    public static final double REACH=12;
    public static final float DAMAGE=20;
    public static boolean inRange(double squared){return Double.isFinite(squared)&&squared>=0&&squared<=REACH*REACH;}
    public static class_243 position(class_243 origin,class_243 destination,double age){return age<BLINK?origin:destination;}
    public static class_243 shoulder(class_243 position,double width,double height,float yaw,boolean left){
        var forward=class_243.method_1030(0,yaw);var side=new class_243(forward.field_1350,0,-forward.field_1352);
        return position.method_1019(side.method_1021((left?1:-1)*width*.30)).method_1020(forward.method_1021(width*.32)).method_1031(0,height*.82,0);
    }
    public static class_243 incoming(float yaw){return class_243.method_1030(0,yaw).method_1021(.28).method_1031(0,-.96,0).method_1029();}
    private ShoulderStabRules(){ }
}
