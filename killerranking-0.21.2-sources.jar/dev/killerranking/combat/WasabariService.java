package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.*;
import dev.killerranking.network.*;
import java.util.*;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;

public final class WasabariService {
    private static final class Cast {
        final class_3222 owner;final class_1309 victim;final class_243 direction;final long started;final float yaw;
        class_243 ownerAt,victimAt;boolean tripped,noAi,effects,released;
        Cast(class_3222 p,class_1309 e){owner=p;victim=e;ownerAt=p.method_19538();direction=e.method_19538().method_1020(ownerAt).method_18805(1,0,1).method_1029();started=now(p);yaw=(float)Math.toDegrees(Math.atan2(-direction.field_1352,direction.field_1350));}
    }
    private final Map<UUID,Cast> casts=new HashMap<>(),victims=new HashMap<>();
    private final Map<UUID,UUID> bleeders=new HashMap<>();
    private final Map<UUID,WasabariStatusPayload> sent=new HashMap<>();
    private static long now(class_3222 p){return p.field_13995.method_30002().method_8510();}
    public static boolean available(class_3222 p){return SalmosaSkillService.available(p);}
    private static boolean eligible(class_3222 p){return available(p)&&TraitActivation.enabled(p)&&p.method_5805()&&!p.method_7325()&&!p.method_31481()&&!p.method_5765()&&!p.method_6115();}
    public boolean active(class_3222 p){return casts.containsKey(p.method_5667());}
    public boolean captured(class_1297 e){return !e.method_37908().field_9236&&victims.containsKey(e.method_5667());}
    public boolean locked(class_1297 e){return !e.method_37908().field_9236&&(casts.containsKey(e.method_5667())||victims.containsKey(e.method_5667()));}
    public int remaining(class_3222 p){var c=casts.get(p.method_5667());return c==null?0:(int)Math.clamp(WasabariRules.DURATION-(now(p)-c.started),0,WasabariRules.DURATION);}
    public class_3222 bleeder(class_1309 victim){var owner=bleeders.get(victim.method_5667());return owner==null||victim.method_37908().method_8503()==null?null:victim.method_37908().method_8503().method_3760().method_14602(owner);}
    public void hemorrhage(class_3222 owner,class_1309 victim,int ticks){bleeders.put(victim.method_5667(),owner.method_5667());victim.method_6092(new class_1293(KillerRankingMod.HEMORRHAGE,ticks,0,false,true));}
    private static boolean enemy(class_3222 p,class_1309 e){return e!=p&&e.method_5805()&&!e.method_31481()&&!e.method_7325()&&e.method_5732()&&!e.method_5765()&&!e.method_5782()&&!p.method_5722(e)&&p.method_18395(e)&&!(e instanceof class_3222 v&&v.method_7337());}
    public class_1309 selected(class_3222 p){
        var eye=p.method_33571();var end=eye.method_1019(p.method_5720().method_1021(WasabariRules.REACH));
        return p.method_51469().method_8390(class_1309.class,p.method_5829().method_1014(WasabariRules.REACH),e->enemy(p,e)&&!KillerRankingMod.ROOK.locked(e)
            &&p.method_5858(e)<=WasabariRules.REACH*WasabariRules.REACH&&p.method_6057(e)&&e.method_5829().method_1014(.12).method_992(eye,end).isPresent())
            .stream().min(Comparator.comparingDouble(p::method_5858)).orElse(null);
    }
    public void start(class_3222 p){
        if(!eligible(p)||SkillCombatLock.blocksAttack(p)||WasabariState.get(p).cooldown(now(p))>0)return;
        var target=selected(p);if(target==null){p.method_7353(class_2561.method_43470("§7와사바리: 2m 안의 상대를 바라보세요."),true);return;}
        var c=new Cast(p,target);if(c.direction.method_1027()<.9)return;
        casts.put(p.method_5667(),c);WasabariState.set(p,WasabariState.get(p).cast(now(p)));freeze(c);broadcast(c,false);sync(p);
    }
    private static boolean clearBox(class_1309 e,class_243 at){return !e.method_37908().method_20812(e,e.method_5829().method_997(at.method_1020(e.method_19538())).method_1011(.001)).iterator().hasNext();}
    private static boolean clearSegment(class_1309 e,class_243 from,class_243 to){int n=Math.max(1,(int)Math.ceil(from.method_1022(to)/.15));for(int i=1;i<=n;i++)if(!clearBox(e,from.method_35590(to,(double)i/n)))return false;return true;}
    private static void position(class_1309 e,class_243 at){e.method_18799(class_243.field_1353);e.field_6017=0;if(e.method_19538().method_1025(at)>.0001){
        if(e instanceof class_3222 p)p.method_48105(p.method_51469(),at.field_1352,at.field_1351,at.field_1350,Set.of(),p.method_36454(),p.method_36455());else e.method_5859(at.field_1352,at.field_1351,at.field_1350);
    }}
    private static void freeze(Cast c){position(c.owner,c.ownerAt);if(c.tripped&&!c.released)position(c.victim,c.victimAt);}
    private static boolean valid(Cast c){return eligible(c.owner)&&c.owner.method_37908()==c.victim.method_37908()&&enemy(c.owner,c.victim)
        &&c.owner.method_19538().method_1025(c.ownerAt)<2.25&&clearBox(c.owner,c.ownerAt)
        &&(!c.tripped||c.released||c.victim.method_19538().method_1025(c.victimAt)<4&&clearBox(c.victim,c.victimAt));}
    public void refresh(class_3222 p){var c=casts.get(p.method_5667());if(c!=null&&!valid(c))cancel(p);}
    private void trip(Cast c){
        var e=c.victim;var offset=e.method_19538().method_1020(c.ownerAt).method_18805(1,0,1);
        if(!enemy(c.owner,e)||KillerRankingMod.ROOK.locked(e)||c.owner.method_5858(e)>4||!c.owner.method_6057(e)||offset.method_1029().method_1026(c.direction)<.5){cancel(c.owner);return;}
        if(e instanceof class_3222 p&&(KillerRankingMod.PARRY.isProtected(p)||KillerRankingMod.PARRY.tryParry(p,c.owner))){cancel(c.owner);return;}
        if(e.method_6039()&&e.method_5720().method_18805(1,0,1).method_1029().method_1026(c.owner.method_19538().method_1020(e.method_19538()).method_18805(1,0,1).method_1029())>0){cancel(c.owner);return;}
        var anchor=e.method_19538();double gap=dev.killerranking.visual.WasabariLayout.gap(c.owner.method_17681(),e.method_17681(),e.method_17682(),RookMountPose.inverted(e));var ownerAt=anchor.method_1020(c.direction.method_1021(gap));
        if(!clearBox(e,anchor)||!clearBox(c.owner,ownerAt)||!clearSegment(c.owner,c.ownerAt,ownerAt)){cancel(c.owner);return;}
        c.tripped=true;c.victimAt=anchor;c.ownerAt=ownerAt;victims.put(e.method_5667(),c);
        if(e instanceof class_1308 mob){c.noAi=mob.method_5987();mob.method_5942().method_6340();mob.method_5977(true);}
        e.method_6021();c.owner.method_6021();freeze(c);
        sound(c,dev.killerranking.KillerRankingSounds.WASABARI_TRIP,1f,1f);c.owner.method_51469().method_14199(class_2398.field_11203,e.method_23317(),e.method_23318()+.1,e.method_23321(),9,.25,.04,.25,.035);
        broadcast(c,false);if(e instanceof class_3222 p)KillerRankingMod.ROOK.sync(p);
    }
    private void stab(Cast c){
        if(!c.tripped)return;
        if(RushDamage.hit(c.owner,c.victim,WasabariRules.STAB_DAMAGE,false)){
            if(!c.effects){c.effects=true;bleeders.put(c.victim.method_5667(),c.owner.method_5667());
                c.victim.method_6092(new class_1293(KillerRankingMod.HEMORRHAGE,WasabariRules.EFFECT_TICKS,0,false,true));
                c.victim.method_6092(new class_1293(class_1294.field_5909,WasabariRules.EFFECT_TICKS,WasabariRules.SLOWNESS_AMPLIFIER,false,true));
            }
            sound(c,dev.killerranking.KillerRankingSounds.WASABARI_STAB,.9f,1f);
            var at=c.victimAt.method_1020(c.direction.method_1021(Math.min(1,c.victim.method_17682()*.27)))
                .method_1031(0,RookMountPose.inverted(c.victim)?c.victim.method_17682()*.8:Math.min(1,c.victim.method_17682()*.36),0);
            c.owner.method_51469().method_14199(new net.minecraft.class_2390(new org.joml.Vector3f(.8f,.025f,.06f),.8f),at.field_1352,at.field_1351,at.field_1350,6,.13,.06,.13,.015);
        }
    }
    private static void sound(Cast c,net.minecraft.class_3414 event,float volume,float pitch){c.owner.method_51469().method_8396(null,c.owner.method_24515(),event,class_3419.field_15248,volume,pitch);}
    public void tick(MinecraftServer server){
        for(var c:new ArrayList<>(casts.values())){
            if(!valid(c)){cancel(c.owner);continue;}int age=(int)(now(c.owner)-c.started);
            if(age>=WasabariRules.DURATION){cancel(c.owner);continue;}
            freeze(c);if(age==WasabariRules.WA)sound(c,dev.killerranking.KillerRankingSounds.SWING_DAGGER,.6f,.9f);
            if(age==WasabariRules.BARI){sound(c,dev.killerranking.KillerRankingSounds.SWING_FIST,.8f,.8f);trip(c);}
            if(!casts.containsKey(c.owner.method_5667()))continue;
            if(c.tripped&&age>=WasabariRules.RELEASE)releaseVictim(c);
            if(WasabariRules.stab(age))stab(c);if(age%5==0)broadcast(c,false);
        }
        if(server.method_3780()%2==0)for(var p:server.method_3760().method_14571())sync(p);
        if(server.method_3780()%20==0)bleeders.entrySet().removeIf(entry->{
            for(var level:server.method_3738()){var e=level.method_14190(entry.getKey());if(e instanceof class_1309 victim&&victim.method_6059(KillerRankingMod.HEMORRHAGE))return false;}return true;
        });
    }
    private void releaseVictim(Cast c){if(!c.tripped||c.released)return;c.released=true;victims.remove(c.victim.method_5667(),c);if(c.victim instanceof class_1308 mob)mob.method_5977(c.noAi);c.victim.field_6017=0;if(c.victim instanceof class_3222 v)KillerRankingMod.ROOK.sync(v);}
    public void cancel(class_3222 p){var c=casts.remove(p.method_5667());if(c==null)return;
        releaseVictim(c);
        broadcast(c,true);sync(p);if(c.victim instanceof class_3222 v)KillerRankingMod.ROOK.sync(v);
    }
    public void forget(class_1297 e){for(var c:new ArrayList<>(casts.values()))if(c.owner==e||c.victim==e)cancel(c.owner);sent.remove(e.method_5667());bleeders.remove(e.method_5667());bleeders.values().removeIf(e.method_5667()::equals);}
    public void clear(){for(var c:new ArrayList<>(casts.values()))cancel(c.owner);casts.clear();victims.clear();sent.clear();bleeders.clear();}
    private void broadcast(Cast c,boolean ending){var viewers=new HashSet<>(PlayerLookup.tracking(c.owner));viewers.addAll(PlayerLookup.tracking(c.victim));viewers.add(c.owner);if(c.victim instanceof class_3222 v)viewers.add(v);for(var v:viewers)send(c,v,ending);}
    private void send(Cast c,class_3222 v,boolean ending){if(ServerPlayNetworking.canSend(v,WasabariVisualPayload.TYPE))ServerPlayNetworking.send(v,new WasabariVisualPayload(c.owner.method_5667(),c.victim.method_5667(),(int)Math.clamp(now(c.owner)-c.started,0,WasabariRules.DURATION),ending?0:remaining(c.owner),c.yaw,c.tripped&&!c.released));}
    public void send(class_3222 p,class_3222 v){var c=casts.get(p.method_5667());if(c!=null)send(c,v,false);}
    public void sync(class_3222 p){var value=new WasabariStatusPayload(available(p),remaining(p),WasabariState.get(p).cooldown(now(p)));if(!value.equals(sent.get(p.method_5667()))&&ServerPlayNetworking.canSend(p,WasabariStatusPayload.TYPE)){ServerPlayNetworking.send(p,value);sent.put(p.method_5667(),value);}}
}
