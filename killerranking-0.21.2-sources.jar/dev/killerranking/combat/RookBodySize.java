package dev.killerranking.combat;

import dev.killerranking.data.RookState;
import net.minecraft.class_1322;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/** Skill ownership changes native model, camera and collision size together. */
public final class RookBodySize {
    public static final double HEIGHT = 2.17;
    public static final double SCALE = HEIGHT / 1.8;
    public static final class_2960 ID = class_2960.method_60655("killerranking", "rook_body_scale");

    private RookBodySize() { }

    public static void refresh(class_3222 player) {
        var attribute = player.method_5996(class_5134.field_47760);
        if (attribute == null) return;
        var previous = attribute.method_6199(ID);
        if (!RookService.branch(player) || !RookState.get(player).unlocked()) {
            if (previous != null) attribute.method_6200(ID);
            return;
        }
        double amount = SCALE - 1;
        if (previous == null || Double.compare(previous.comp_2449(), amount) != 0
                || previous.comp_2450() != class_1322.class_1323.field_6331) {
            attribute.method_55696(new class_1322(ID, amount,
                class_1322.class_1323.field_6331));
        }
    }
}
