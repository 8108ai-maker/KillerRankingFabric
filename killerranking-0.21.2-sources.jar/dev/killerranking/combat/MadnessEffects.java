package dev.killerranking.combat;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.data.PlayerProfiles;
import dev.killerranking.data.TraitActivation;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public final class MadnessEffects {
    public static final class_2960 SPEED = KillerRankingMod.id("madness_attack_speed");
    public static boolean active(class_3222 p) {
        return p.method_5805() && !p.method_7325() && TraitActivation.enabled(p)
            && PlayerProfiles.get(p).trait() == Trait.MIXED_MADNESS
            && CombatRules.madnessActive(CombatRules.healthRatio(p.method_6032(), p.method_6063()));
    }
    public static int speed(class_3222 p) {
        return active(p) ? TraitLevels.bonusPercent(KillerRankingMod.CONFIG.mixedMadnessAttackSpeedPercent, PlayerProfiles.get(p).traitLevel()) : 0;
    }
    public static double damageBonus(class_3222 p) {
        return p.method_5805()&&!p.method_7325()&&TraitActivation.enabled(p)&&PlayerProfiles.get(p).trait()==Trait.MIXED_MADNESS
            ? CombatRules.madnessDamagePercent(CombatRules.healthRatio(p.method_6032(),p.method_6063()),
                KillerRankingMod.CONFIG.mixedMadnessBasePercent,PlayerProfiles.get(p).traitLevel()) : 0;
    }
    public static void refresh(class_3222 p) {
        PoisonEffects.applyPercent(p.method_5996(class_5134.field_23723), SPEED, speed(p));
    }
    private MadnessEffects() { }
}
