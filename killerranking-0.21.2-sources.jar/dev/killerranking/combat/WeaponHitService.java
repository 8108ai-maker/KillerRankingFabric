package dev.killerranking.combat;

import dev.killerranking.KillerRankingSounds;
import dev.killerranking.network.WeaponHitPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_8103;

/**
 * Impact sound and pixel VFX for ordinary melee contacts with a mod weapon.
 * Skills own their own contact feedback and are excluded through their damage flags
 * and the skill combat lock, so nothing here doubles a skill's sound.
 */
public final class WeaponHitService {
    private static final double VIEW_RANGE_SQ = 64 * 64;

    public static void afterDamage(class_1309 victim, class_1282 source, float damageTaken, boolean blocked) {
        if (blocked || damageTaken <= 0) return;
        if (!(source.method_5529() instanceof class_3222 attacker) || source.method_5526() != attacker) return;
        if (source.method_48789(class_8103.field_42247) || attacker == victim) return;
        if (RushDamage.current(victim) || CheckmateDamage.current(victim) || BleedingDamage.current(victim)) return;
        if (SkillCombatLock.blocksAttack(attacker)) return;
        var family = WeaponFamily.of(attacker.method_6047());
        if (family == null) return;

        boolean crit = attacker.field_6017 > 0 && !attacker.method_24828() && !attacker.method_6101()
            && !attacker.method_5799() && !attacker.method_5765() && !attacker.method_5624();
        boolean lethal = victim.method_29504() || victim.method_6032() <= 0;
        class_243 contact = contactPoint(attacker, victim);

        var level = attacker.method_51469();
        KillerRankingSounds.play(level, contact, family.hit, family.volume, KillerRankingSounds.vary(attacker, family.pitch, 0.06f));
        if (crit) KillerRankingSounds.play(level, contact, KillerRankingSounds.HIT_CRIT, 0.7f, KillerRankingSounds.vary(attacker, 1.0f, 0.05f));

        var payload = new WeaponHitPayload(attacker.method_5667(), family.ordinal(), contact.field_1352, contact.field_1351, contact.field_1350, attacker.method_36454(), damageTaken, crit, lethal);
        for (class_3222 viewer : level.method_18456()) {
            if (viewer.method_5707(contact) <= VIEW_RANGE_SQ && ServerPlayNetworking.canSend(viewer, WeaponHitPayload.TYPE)) ServerPlayNetworking.send(viewer, payload);
        }
    }

    /** A point on the victim's silhouette facing the attacker, at mid-torso height. */
    static class_243 contactPoint(class_1309 attacker, class_1309 victim) {
        class_243 toAttacker = attacker.method_19538().method_1020(victim.method_19538()).method_18805(1, 0, 1);
        if (toAttacker.method_1027() < 1e-4) toAttacker = attacker.method_5720().method_18805(-1, 0, -1);
        toAttacker = toAttacker.method_1029().method_1021(victim.method_17681() * 0.45);
        double height = victim.method_17682() * (0.55 + attacker.method_59922().method_43057() * 0.15);
        return victim.method_19538().method_1019(toAttacker).method_1031(0, height, 0);
    }

    private WeaponHitService() { }
}
