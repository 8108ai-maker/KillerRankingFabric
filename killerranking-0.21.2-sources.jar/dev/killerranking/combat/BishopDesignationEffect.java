package dev.killerranking.combat;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/** The effect is visible on the victim; caster ownership lives in BishopDesignations. */
public final class BishopDesignationEffect extends class_1291 {
    public BishopDesignationEffect() { super(class_4081.field_18272, 0xD55C96); }
}
