package dev.killerranking.combat;

import net.minecraft.class_1309;
import net.minecraft.class_1428;
import net.minecraft.class_1429;
import net.minecraft.class_1453;
import net.minecraft.class_1548;
import net.minecraft.class_1584;
import net.minecraft.class_1628;
import net.minecraft.class_4466;
import net.minecraft.class_5136;

/** Upright victims lie on their back; creatures with horizontal bodies flip belly-up. */
public final class RookMountPose {
    public static boolean inverted(class_1309 victim) {
        return victim instanceof class_1429 && !(victim instanceof class_1428)
            && !(victim instanceof class_1453) && !(victim instanceof class_4466)
            || victim instanceof class_1584 || victim instanceof class_5136
            || victim instanceof class_1548 || victim instanceof class_1628;
    }
    public static double seatHeight(class_1309 victim) {
        return inverted(victim)?Math.max(.12,victim.method_17682()*.55):.12;
    }
    public static double impactHeight(class_1309 victim) {
        return inverted(victim)?victim.method_17682()*.55:.28;
    }
    private RookMountPose() { }
}
