package dev.killerranking.combat;
import dev.killerranking.entity.BishopFollower;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_3222;
import net.minecraft.world.entity.*;

public final class BishopTargets {
    public static boolean allowed(class_3222 owner,class_1309 target){
        if(owner==null||target==null||target==owner||!target.method_5805()||target.method_31481()||target.method_7325()||!target.method_5732()
            ||owner.method_37908()!=target.method_37908()||owner.method_5722(target)||!owner.method_18395(target))return false;
        if(target instanceof class_3222 p&&(!owner.field_13995.method_3852()||p.method_7337()||!owner.method_7256(p)))return false;
        if(target instanceof class_1321 pet&&pet.method_6171(owner))return false;
        if(target instanceof BishopFollower follower){
            var other=follower.owner();
            if(owner.method_5667().equals(follower.ownerId())||other==null||!allowed(owner,other))return false;
        }
        return true;
    }
    private BishopTargets() { }
}
