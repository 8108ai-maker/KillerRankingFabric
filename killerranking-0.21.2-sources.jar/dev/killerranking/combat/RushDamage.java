package dev.killerranking.combat;

import net.minecraft.class_1309;
import net.minecraft.class_3222;

/** Only the current rush hit skips vanilla hurt cooldown. Shields, parries and immunity still apply. */
public final class RushDamage {
    private record Strike(class_1309 target,boolean finisher) { }
    private static final ThreadLocal<Strike> CURRENT=new ThreadLocal<>();
    public static boolean current(class_1309 entity) { var s=CURRENT.get();return s!=null && s.target()==entity; }
    public static boolean suppressKnockback(class_1309 entity) { var s=CURRENT.get();return s!=null && s.target()==entity && !s.finisher(); }
    public static boolean hit(class_3222 attacker,class_1309 target,boolean finisher) {
        return hit(attacker,target,RushRules.DAMAGE,finisher);
    }
    /** Scoped rapid hits also serve Rook's sequence, retaining unrelated vanilla immunity windows. */
    public static boolean hit(class_3222 attacker,class_1309 target,float amount,boolean finisher) {
        return hit(attacker,target,attacker.method_48923().method_48802(attacker),amount,finisher);
    }
    public static boolean hit(class_3222 attacker,class_1309 target,net.minecraft.class_1282 source,float amount,boolean finisher) {
        var previous=CURRENT.get();int oldTime=target.field_6008;
        float oldDamage=((RushDamageAccess)target).killerranking$lastDamage();
        CURRENT.set(new Strike(target,finisher));
        try { return target.method_5643(source,amount); }
        finally {
            // Preserve an existing vanilla window for unrelated attacks; do not clear it globally.
            if(oldTime>0) { target.field_6008=oldTime;((RushDamageAccess)target).killerranking$lastDamage(oldDamage); }
            if(previous==null) CURRENT.remove();else CURRENT.set(previous);
        }
    }
    public interface RushDamageAccess { float killerranking$lastDamage();void killerranking$lastDamage(float value); }
    private RushDamage() { }
}
