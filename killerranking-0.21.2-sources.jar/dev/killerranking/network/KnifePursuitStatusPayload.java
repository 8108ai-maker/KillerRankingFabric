package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.KnifePursuitRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record KnifePursuitStatusPayload(boolean available,int phase,int age,int cooldown) implements class_8710 {
    public KnifePursuitStatusPayload {phase=Math.clamp(phase,0,3);age=Math.clamp(age,0,KnifePursuitRules.MAX_HOLD);cooldown=Math.clamp(cooldown,0,KnifePursuitRules.COOLDOWN);}
    public static final class_9154<KnifePursuitStatusPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"knife_pursuit_status"));
    public static final class_9139<class_9129,KnifePursuitStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_52964(v.available());b.method_10804(v.phase());b.method_10804(v.age());b.method_10804(v.cooldown());},
        b->new KnifePursuitStatusPayload(b.readBoolean(),b.method_10816(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
