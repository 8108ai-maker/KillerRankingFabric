package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.HeavyPunchRules;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record HeavyPunchVisualPayload(UUID player,int target,int remaining,int age,float yaw) implements class_8710 {
    public HeavyPunchVisualPayload {remaining=Math.clamp(remaining,0,HeavyPunchRules.DURATION);age=Math.clamp(age,0,HeavyPunchRules.DURATION);yaw=Float.isFinite(yaw)?yaw:0;}
    public static final class_9154<HeavyPunchVisualPayload> TYPE=new class_9154<>(KillerRankingMod.id("heavy_punch_visual"));
    public static final class_9139<class_9129,HeavyPunchVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_10804(v.target());b.method_10804(v.remaining());b.method_10804(v.age());b.method_52941(v.yaw());},
        b->new HeavyPunchVisualPayload(b.method_10790(),b.method_10816(),b.method_10816(),b.method_10816(),b.readFloat()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
