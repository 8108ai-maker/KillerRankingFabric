package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.CheckmateRules;
import java.util.UUID;
import net.minecraft.class_243;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.List;
import java.util.ArrayList;

public record CheckmateVisualPayload(UUID player,int remaining,int age,class_243 origin,List<class_243> tiles,int selected,boolean aiming) implements class_8710 {
    public CheckmateVisualPayload {
        int duration=aiming?CheckmateRules.AIM_DURATION:CheckmateRules.DURATION;
        remaining=Math.clamp(remaining,0,duration);age=Math.clamp(age,0,duration);
        tiles=List.copyOf(tiles);
        if(tiles.size()>8||!finite(origin)||tiles.stream().anyMatch(v->!finite(v))) throw new IllegalArgumentException("Invalid checkmate board");
        if(remaining>0&&(tiles.isEmpty()||selected<(aiming?-1:0)||selected>=tiles.size())) throw new IllegalArgumentException("Invalid destination");
    }
    // Separate channel prevents old clients from decoding the extended board data as the old packet.
    public static final class_9154<CheckmateVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"checkmate_visual_v3"));
    public static final class_9139<class_9129,CheckmateVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{ b.method_10797(v.player());b.method_10804(v.remaining());b.method_10804(v.age());writeVector(b,v.origin());
            b.method_10804(v.tiles().size());for(var tile:v.tiles()) writeVector(b,tile);b.method_10804(v.selected());b.method_52964(v.aiming()); },
        b->{ var id=b.method_10790();int remaining=b.method_10816(),age=b.method_10816();var origin=readVector(b);
            int count=b.method_10816();if(count<0||count>8) throw new io.netty.handler.codec.DecoderException("Invalid board size");
            var tiles=new ArrayList<class_243>();for(int i=0;i<count;i++) tiles.add(readVector(b));
            return new CheckmateVisualPayload(id,remaining,age,origin,tiles,b.method_10816(),b.readBoolean()); });
    private static boolean finite(class_243 v) { return Double.isFinite(v.field_1352)&&Double.isFinite(v.field_1351)&&Double.isFinite(v.field_1350); }
    private static void writeVector(class_9129 b,class_243 v) { b.method_52940(v.field_1352);b.method_52940(v.field_1351);b.method_52940(v.field_1350); }
    private static class_243 readVector(class_9129 b) { return new class_243(b.readDouble(),b.readDouble(),b.readDouble()); }
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
