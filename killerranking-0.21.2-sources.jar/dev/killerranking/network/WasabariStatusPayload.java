package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.WasabariRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
public record WasabariStatusPayload(boolean available,int remaining,int cooldown) implements class_8710 {
    public WasabariStatusPayload {remaining=Math.clamp(remaining,0,WasabariRules.DURATION);cooldown=Math.clamp(cooldown,0,WasabariRules.COOLDOWN);}
    public static final class_9154<WasabariStatusPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"wasabari_status"));
    public static final class_9139<class_9129,WasabariStatusPayload> CODEC=class_9139.method_56437((b,v)->{b.method_52964(v.available());b.method_10804(v.remaining());b.method_10804(v.cooldown());},b->new WasabariStatusPayload(b.readBoolean(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
