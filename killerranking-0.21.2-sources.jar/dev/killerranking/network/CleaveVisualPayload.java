package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.CleaveRules;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record CleaveVisualPayload(UUID player,int phase,int age,boolean full,float yaw) implements class_8710 {
    public CleaveVisualPayload {phase=Math.clamp(phase,0,2);age=Math.clamp(age,0,CleaveRules.MAX_HOLD);}
    public static final class_9154<CleaveVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"cleave_visual"));
    public static final class_9139<class_9129,CleaveVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_10804(v.phase());b.method_10804(v.age());b.method_52964(v.full());b.method_52941(v.yaw());},
        b->new CleaveVisualPayload(b.method_10790(),b.method_10816(),b.method_10816(),b.readBoolean(),b.readFloat()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
