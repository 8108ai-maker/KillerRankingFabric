package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** No client-supplied charge time, damage, victim or position. */
public record CleaveRequestPayload(int operation) implements class_8710 {
    public static final int START=0,RELEASE=1,CANCEL=2,UNLOCK=3;
    public static final class_9154<CleaveRequestPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"cleave_request"));
    public static final class_9139<class_9129,CleaveRequestPayload> CODEC=class_9139.method_56437(
        (b,v)->b.method_10804(v.operation()),b->new CleaveRequestPayload(b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
