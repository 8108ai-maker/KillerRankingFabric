package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** No client target or damage is trusted. */
public record HeavyPunchRequestPayload() implements class_8710 {
    public static final class_9154<HeavyPunchRequestPayload> TYPE=new class_9154<>(KillerRankingMod.id("heavy_punch_request"));
    public static final class_9139<class_9129,HeavyPunchRequestPayload> CODEC=class_9139.method_56431(new HeavyPunchRequestPayload());
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
