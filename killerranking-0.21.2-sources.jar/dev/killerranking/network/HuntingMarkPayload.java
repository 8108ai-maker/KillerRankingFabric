package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Sent exclusively to the player who applied the mark. */
public record HuntingMarkPayload(boolean active, String name, double x, double y, double z, int ticks, int bleedingDamage) implements class_8710 {
    public static final HuntingMarkPayload CLEAR = new HuntingMarkPayload(false, "", 0, 0, 0, 0, 0);
    public static final class_9154<HuntingMarkPayload> TYPE = new class_9154<>(KillerRankingMod.id("hunting_mark"));
    public static final class_9139<class_9129, HuntingMarkPayload> CODEC = class_9139.method_56437(
        (b, v) -> { b.method_52964(v.active()); b.method_10788(v.name(), 128); b.method_52940(v.x()); b.method_52940(v.y()); b.method_52940(v.z()); b.method_10804(v.ticks()); b.method_10804(v.bleedingDamage()); },
        b -> new HuntingMarkPayload(b.readBoolean(), b.method_10800(128), b.readDouble(), b.readDouble(), b.readDouble(), b.method_10816(), b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
