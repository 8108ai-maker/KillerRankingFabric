package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.ShoulderStabRules;
import java.util.UUID;
import net.minecraft.class_243;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ShoulderStabVisualPayload(UUID player,UUID target,int phase,int age,float yaw,class_243 origin,class_243 wound,class_243 destination,class_243 airStart,class_243 airCatch) implements class_8710 {
    public ShoulderStabVisualPayload(UUID player,UUID target,int phase,int age,float yaw,class_243 origin,class_243 wound,class_243 destination){this(player,target,phase,age,yaw,origin,wound,destination,class_243.field_1353,class_243.field_1353);}
    public ShoulderStabVisualPayload {phase=Math.clamp(phase,0,3);age=Math.clamp(age,0,ShoulderStabRules.MAX_HOLD);if(!Float.isFinite(yaw))yaw=0;}
    public static final class_9154<ShoulderStabVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"shoulder_stab_visual"));
    public static final class_9139<class_9129,ShoulderStabVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_10797(v.target());b.method_10804(v.phase());b.method_10804(v.age());b.method_52941(v.yaw());write(b,v.origin());write(b,v.wound());write(b,v.destination());write(b,v.airStart());write(b,v.airCatch());},
        b->new ShoulderStabVisualPayload(b.method_10790(),b.method_10790(),b.method_10816(),b.method_10816(),b.readFloat(),read(b),read(b),read(b),read(b),read(b)));
    private static void write(class_9129 b,class_243 v){b.method_52940(v.field_1352);b.method_52940(v.field_1351);b.method_52940(v.field_1350);}
    private static class_243 read(class_9129 b){return new class_243(b.readDouble(),b.readDouble(),b.readDouble());}
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
