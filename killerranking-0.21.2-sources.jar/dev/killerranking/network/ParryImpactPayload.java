package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Sent only after the server has accepted a parried hit, separately from the guard pose. */
public record ParryImpactPayload(UUID player,double x,double y,double z) implements class_8710 {
    public static final class_9154<ParryImpactPayload> TYPE=new class_9154<>(KillerRankingMod.id("parry_impact"));
    public static final class_9139<class_9129,ParryImpactPayload> CODEC=class_9139.method_56437(
        (b,p)->{b.method_10797(p.player());b.method_52940(p.x());b.method_52940(p.y());b.method_52940(p.z());},
        b->new ParryImpactPayload(b.method_10790(),b.readDouble(),b.readDouble(),b.readDouble()));
    public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
