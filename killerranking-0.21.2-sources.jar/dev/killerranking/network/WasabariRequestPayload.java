package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
/** Selection, damage and timing are entirely server-authoritative. */
public record WasabariRequestPayload() implements class_8710 {
    public static final class_9154<WasabariRequestPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"wasabari_request"));
    public static final class_9139<class_9129,WasabariRequestPayload> CODEC=class_9139.method_56431(new WasabariRequestPayload());
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
