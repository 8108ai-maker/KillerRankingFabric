package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
public record AutoParryRequestPayload(boolean held) implements class_8710 {
    public static final class_9154<AutoParryRequestPayload> TYPE=new class_9154<>(KillerRankingMod.id("auto_parry_request"));
    public static final class_9139<class_9129,AutoParryRequestPayload> CODEC=class_9139.method_56437(
        (b,v)->b.method_52964(v.held()),b->new AutoParryRequestPayload(b.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
