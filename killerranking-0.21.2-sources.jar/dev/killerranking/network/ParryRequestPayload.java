package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ParryRequestPayload() implements class_8710 {
	public static final class_9154<ParryRequestPayload> TYPE = new class_9154<>(KillerRankingMod.id("parry_request"));
	public static final class_9139<class_9129, ParryRequestPayload> CODEC = class_9139.method_56431(new ParryRequestPayload());
	@Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
