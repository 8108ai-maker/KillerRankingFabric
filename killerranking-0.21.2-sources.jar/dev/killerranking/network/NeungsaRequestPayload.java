package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** The client sends intent only; ownership, aim, blocks and damage are decided on the server. */
public record NeungsaRequestPayload(int operation) implements class_8710 {
    public static final int START=0,UNLOCK=1,IAIDO=2,IAIDO_RELEASE=3,IAIDO_CANCEL=4,ECHO=5;
    public static final class_9154<NeungsaRequestPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"neungsa_request"));
    public static final class_9139<class_9129,NeungsaRequestPayload> CODEC=class_9139.method_56437(
        (b,v)->b.method_10804(v.operation()),b->new NeungsaRequestPayload(b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
