package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record BranchRequestPayload(String branch) implements class_8710 {
    public static final class_9154<BranchRequestPayload> TYPE = new class_9154<>(KillerRankingMod.id("branch_request"));
    public static final class_9139<class_9129, BranchRequestPayload> CODEC = new class_9139<>() {
        public BranchRequestPayload decode(class_9129 b) { return new BranchRequestPayload(b.method_10800(32)); }
        public void encode(class_9129 b, BranchRequestPayload p) { b.method_10788(p.branch, 32); }
    };
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
