package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server-owned state. No client message can set gauges or cooldowns. */
public record CombatStatusPayload(String traitId, float gauge, boolean active, int effectTicks,
		int powerPercent, int parryTicks, int parryTotal, int parryWindow,
		int traitLevel, int effectTotalTicks, int highHealthPercent, int halfHealthPercent, int lowHealthPercent,
        int survivalTicks, int survivalCooldown) implements class_8710 {
	public static final class_9154<CombatStatusPayload> TYPE = new class_9154<>(KillerRankingMod.id("combat_status_v2"));
	public static final class_9139<class_9129, CombatStatusPayload> CODEC = class_9139.method_56437(
		(buffer, value) -> {
			buffer.method_10814(value.traitId());
			buffer.method_52941(value.gauge());
			buffer.method_52964(value.active());
			buffer.method_10804(value.effectTicks());
			buffer.method_10804(value.powerPercent());
			buffer.method_10804(value.parryTicks());
			buffer.method_10804(value.parryTotal());
			buffer.method_10804(value.parryWindow());
			buffer.method_10804(value.traitLevel());
			buffer.method_10804(value.effectTotalTicks());
			buffer.method_10804(value.highHealthPercent());
			buffer.method_10804(value.halfHealthPercent());
			buffer.method_10804(value.lowHealthPercent());
            buffer.method_10804(value.survivalTicks());
            buffer.method_10804(value.survivalCooldown());
		}, buffer -> new CombatStatusPayload(buffer.method_19772(), buffer.readFloat(), buffer.readBoolean(),
			buffer.method_10816(), buffer.method_10816(), buffer.method_10816(), buffer.method_10816(), buffer.method_10816(),
			buffer.method_10816(), buffer.method_10816(), buffer.method_10816(), buffer.method_10816(), buffer.method_10816(),
            buffer.method_10816(), buffer.method_10816()));
	@Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
