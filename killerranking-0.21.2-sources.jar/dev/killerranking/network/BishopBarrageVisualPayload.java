package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.BishopBarrageRules;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record BishopBarrageVisualPayload(UUID player,int remaining,double x,double y,double z,float yaw) implements class_8710 {
    public BishopBarrageVisualPayload {remaining=Math.clamp(remaining,0,BishopBarrageRules.DURATION);}
    public static final class_9154<BishopBarrageVisualPayload> TYPE=new class_9154<>(KillerRankingMod.id("bishop_barrage_visual"));
    public static final class_9139<class_9129,BishopBarrageVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_10804(v.remaining());b.method_52940(v.x());b.method_52940(v.y());b.method_52940(v.z());b.method_52941(v.yaw());},
        b->new BishopBarrageVisualPayload(b.method_10790(),b.method_10816(),b.readDouble(),b.readDouble(),b.readDouble(),b.readFloat()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
