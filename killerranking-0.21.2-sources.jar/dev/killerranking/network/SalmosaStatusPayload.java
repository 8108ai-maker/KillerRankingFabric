package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SalmosaStatusPayload(boolean branch,boolean unlocked) implements class_8710 {
    public static final class_9154<SalmosaStatusPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"salmosa_status"));
    public static final class_9139<class_9129,SalmosaStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_52964(v.branch());b.method_52964(v.unlocked());},b->new SalmosaStatusPayload(b.readBoolean(),b.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
