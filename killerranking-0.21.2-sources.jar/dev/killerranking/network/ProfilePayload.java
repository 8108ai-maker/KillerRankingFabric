package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.data.PlayerProfile;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ProfilePayload(long pointUnits, String traitName, int zombieKills, boolean zombieMissionComplete) implements class_8710 {
	public static final class_9154<ProfilePayload> TYPE = new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID, "profile_v2"));
	public static final class_9139<class_9129, ProfilePayload> CODEC = class_9139.method_56905(
		class_9135.field_48551, ProfilePayload::pointUnits,
		class_9135.field_48554, ProfilePayload::traitName,
		class_9135.field_48550, ProfilePayload::zombieKills,
		class_9135.field_48547, ProfilePayload::zombieMissionComplete,
		ProfilePayload::new);

	public static ProfilePayload from(PlayerProfile profile) {
		return new ProfilePayload(profile.pointUnits(), profile.trait().koreanName(), profile.zombieKills(), profile.zombieMissionComplete());
	}

	@Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
