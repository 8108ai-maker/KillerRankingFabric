package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
/** Server-confirmed strike: the client never supplies attackers, success or the echo sequence. */
public record AutoParryEffectPayload(UUID player,boolean reversed,boolean echo,int sequence,double x,double y,double z,float yaw,float pitch) implements class_8710 {
    public AutoParryEffectPayload {sequence=Math.clamp(sequence,0,4095);}
    public static final class_9154<AutoParryEffectPayload> TYPE=new class_9154<>(KillerRankingMod.id("auto_parry_effect"));
    public static final class_9139<class_9129,AutoParryEffectPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_52964(v.reversed());b.method_52964(v.echo());b.method_10804(v.sequence());b.method_52940(v.x());b.method_52940(v.y());b.method_52940(v.z());b.method_52941(v.yaw());b.method_52941(v.pitch());},
        b->new AutoParryEffectPayload(b.method_10790(),b.readBoolean(),b.readBoolean(),b.method_10816(),b.readDouble(),b.readDouble(),b.readDouble(),b.readFloat(),b.readFloat()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
