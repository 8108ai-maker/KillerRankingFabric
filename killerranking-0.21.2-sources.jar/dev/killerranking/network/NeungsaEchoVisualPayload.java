package dev.killerranking.network;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.NeungsaEchoRules;

public record NeungsaEchoVisualPayload(UUID player,int age,int remaining,double x,double y,double z,float dx,float dy,float dz) implements class_8710 {
    public NeungsaEchoVisualPayload {age=Math.clamp(age,0,NeungsaEchoRules.DURATION);remaining=Math.clamp(remaining,0,NeungsaEchoRules.DURATION);}
    public static final class_9154<NeungsaEchoVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"neungsa_echo_visual"));
    public static final class_9139<class_9129,NeungsaEchoVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_10804(v.age());b.method_10804(v.remaining());b.method_52940(v.x());b.method_52940(v.y());b.method_52940(v.z());b.method_52941(v.dx());b.method_52941(v.dy());b.method_52941(v.dz());},
        b->new NeungsaEchoVisualPayload(b.method_10790(),b.method_10816(),b.method_10816(),b.readDouble(),b.readDouble(),b.readDouble(),b.readFloat(),b.readFloat(),b.readFloat()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
