package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.BishopRules;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record BishopStatusPayload(UUID player,boolean branch,boolean unlocked,boolean otherOwned,boolean enabled,
    int count,int remaining,int cooldown,int castTicks,int barrageTicks,int barrageCooldown,String targetName) implements class_8710 {
    public BishopStatusPayload {count=Math.clamp(count,0,BishopRules.MAX_UNITS);remaining=Math.clamp(remaining,0,BishopRules.DURATION);cooldown=Math.clamp(cooldown,0,BishopRules.COOLDOWN);castTicks=Math.clamp(castTicks,0,BishopRules.CAST);barrageTicks=Math.clamp(barrageTicks,0,dev.killerranking.combat.BishopBarrageRules.DURATION);barrageCooldown=Math.clamp(barrageCooldown,0,BishopRules.COOLDOWN);targetName=targetName.substring(0,Math.min(80,targetName.length()));}
    public static final class_9154<BishopStatusPayload> TYPE=new class_9154<>(KillerRankingMod.id("bishop_status"));
    public static final class_9139<class_9129,BishopStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_52964(v.branch());b.method_52964(v.unlocked());b.method_52964(v.otherOwned());b.method_52964(v.enabled());b.method_10804(v.count());b.method_10804(v.remaining());b.method_10804(v.cooldown());b.method_10804(v.castTicks());b.method_10804(v.barrageTicks());b.method_10804(v.barrageCooldown());b.method_10788(v.targetName(),80);},
        b->new BishopStatusPayload(b.method_10790(),b.readBoolean(),b.readBoolean(),b.readBoolean(),b.readBoolean(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10800(80)));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
