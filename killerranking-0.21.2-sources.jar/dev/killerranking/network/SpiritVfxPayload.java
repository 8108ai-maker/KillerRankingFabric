package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.SpiritBranch;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Short-lived client lease, refreshed while the passive branch remains equipped. */
public record SpiritVfxPayload(UUID player, int ticks, SpiritBranch branch) implements class_8710 {
    public SpiritVfxPayload {
        ticks = Math.clamp(ticks, 0, 60);
        if (branch == null || branch == SpiritBranch.NONE || ticks == 0) { branch = SpiritBranch.NONE; ticks = 0; }
    }
    public static final class_9154<SpiritVfxPayload> TYPE = new class_9154<>(KillerRankingMod.id("spirit_vfx"));
    public static final class_9139<class_9129, SpiritVfxPayload> CODEC = class_9139.method_56437(
        (buffer, value) -> { buffer.method_10797(value.player()); buffer.method_10804(value.ticks()); buffer.method_10788(value.branch().id(), 32); },
        buffer -> new SpiritVfxPayload(buffer.method_10790(), buffer.method_10816(), SpiritBranch.fromId(buffer.method_10800(32))));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
