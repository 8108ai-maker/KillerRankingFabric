package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Only visible sword types are synchronized; the rest of the inventory remains private. */
public record KatanaHolstersPayload(UUID player, class_2960 waist, class_2960 back) implements class_8710 {
    public static final class_9154<KatanaHolstersPayload> TYPE = new class_9154<>(KillerRankingMod.id("katana_holsters"));
    public static final class_9139<class_9129,KatanaHolstersPayload> CODEC = class_9139.method_56437(
        (b,v) -> { b.method_10797(v.player); b.method_10812(v.waist); b.method_10812(v.back); },
        b -> new KatanaHolstersPayload(b.method_10790(),b.method_10810(),b.method_10810()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
