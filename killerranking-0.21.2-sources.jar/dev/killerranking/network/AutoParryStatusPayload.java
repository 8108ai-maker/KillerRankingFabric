package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
public record AutoParryStatusPayload(UUID player,boolean active) implements class_8710 {
    public static final class_9154<AutoParryStatusPayload> TYPE=new class_9154<>(KillerRankingMod.id("auto_parry_status"));
    public static final class_9139<class_9129,AutoParryStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_52964(v.active());},b->new AutoParryStatusPayload(b.method_10790(),b.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
