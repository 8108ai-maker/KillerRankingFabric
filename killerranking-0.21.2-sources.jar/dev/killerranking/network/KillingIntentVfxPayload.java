package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Visual state only. Damage and activation remain owned by the server. */
public record KillingIntentVfxPayload(UUID player, int ticks) implements class_8710 {
    public KillingIntentVfxPayload { ticks = Math.clamp(ticks, 0, 60); }
    public static final class_9154<KillingIntentVfxPayload> TYPE = new class_9154<>(KillerRankingMod.id("killing_intent_vfx"));
    public static final class_9139<class_9129, KillingIntentVfxPayload> CODEC = class_9139.method_56437(
        (buffer, value) -> { buffer.method_10797(value.player()); buffer.method_10804(value.ticks()); },
        buffer -> new KillingIntentVfxPayload(buffer.method_10790(), buffer.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
