package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.MadnessLeapRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record MadnessLeapStatusPayload(boolean available,int phase,int age,int cooldown) implements class_8710 {
    public MadnessLeapStatusPayload {phase=Math.clamp(phase,0,2);age=Math.clamp(age,0,MadnessLeapRules.MAX_HOLD);cooldown=Math.clamp(cooldown,0,MadnessLeapRules.COOLDOWN);}
    public static final class_9154<MadnessLeapStatusPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"madness_leap_status"));
    public static final class_9139<class_9129,MadnessLeapStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_52964(v.available());b.method_10804(v.phase());b.method_10804(v.age());b.method_10804(v.cooldown());},
        b->new MadnessLeapStatusPayload(b.readBoolean(),b.method_10816(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
