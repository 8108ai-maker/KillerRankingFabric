package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record DashboardPayload(String json) implements class_8710 {
    public static final class_9154<DashboardPayload> TYPE = new class_9154<>(KillerRankingMod.id("dashboard_v2"));
    public static final class_9139<class_9129, DashboardPayload> CODEC = new class_9139<>() {
        public DashboardPayload decode(class_9129 b) { return new DashboardPayload(b.method_10800(32767)); }
        public void encode(class_9129 b, DashboardPayload p) { b.method_10788(p.json, 32767); }
    };
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
