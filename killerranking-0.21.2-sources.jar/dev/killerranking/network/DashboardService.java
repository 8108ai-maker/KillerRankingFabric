package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.combat.*;
import dev.killerranking.data.*;
import dev.killerranking.mission.*;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;

public final class DashboardService {
    public static void tick(MinecraftServer server) {
        if (server.method_3780() % 10 == 0) for (var p : server.method_3760().method_14571()) sync(p);
    }
    public static void sync(class_3222 player) {
        KillerRankingMod.BISHOP.effects(player); InheritedWeaponEffects.refresh(player);
        PoisonEffects.refresh(player);
        MadnessEffects.refresh(player);
        KnightWeaponEffects.refresh(player);
        var profile = PlayerProfiles.get(player);
        var state = SpiritState.get(player);
        var branch = profile.trait() == Trait.FIGHTING_SPIRIT ? state.branch() : SpiritBranch.NONE;
        int level = profile.traitLevel();
        var effectBranch = TraitActivation.enabled(player) && player.method_5805() && !player.method_7325() ? branch : SpiritBranch.NONE;
        double madness = MadnessEffects.damageBonus(player);
        var board = player.getAttachedOrCreate(RotatingMissions.TYPE);
        var missions = board.entries().stream().filter(e -> MissionCatalog.find(e.id()) != null).map(e -> {
            var d = MissionCatalog.find(e.id());
            return new DashboardData.Mission(d.title(), e.progress(), d.goal(), e.displayedReward(d), e.paid(), d.divisor(), d.unit());
        }).toList();
        var killing = player.method_5996(class_5134.field_23721).method_6199(KillingIntentEffect.ID);
        int attackBonus = effectBranch.attack(level) + (killing == null ? 0 : (int) Math.round(killing.comp_2449() * 100));
        boolean inheritedMadness = InheritedWeaponEffects.madnessBonus(player);
        boolean poison = TraitActivation.enabled(player) && profile.trait() == Trait.POISON_AURA && player.method_5805() && !player.method_7325();
        int speedBonus = effectBranch.attackSpeed(level) + (inheritedMadness ? InheritedWeaponEffects.SPEED_BONUS : 0)
            + MadnessEffects.speed(player) + (poison ? PoisonEffects.speed(level) : 0);
        double morale = MoraleState.get(player);
        boolean knight = KnightWeaponEffects.striking(player);
        if (inheritedMadness) attackBonus += 30;
        var data = new DashboardData(profile.trait().id(), level, branch.id(), state.checkmate(), profile.pointUnits(),
            player.method_6032(), player.method_6063(), player.method_45325(class_5134.field_23721) * (1 + madness / 100.0)
                * (inheritedMadness ? InheritedWeaponEffects.DAMAGE_MULTIPLIER : 1) * morale * (knight ? 2 : 1),
            player.method_45325(class_5134.field_23723), player.method_45325(class_5134.field_23719),
            player.method_45325(class_5134.field_23724), player.method_45325(class_5134.field_23725), SpiritEffects.defense(player),
            attackBonus, speedBonus, effectBranch.movement(level, state.checkmate()) + (poison ? PoisonEffects.speed(level) : 0), madness,
            board.remaining(player.field_13995.method_30002().method_8532()), missions, profile.traitXp(), TraitExperienceService.required(level), player.method_45325(class_5134.field_23718), morale, knight,
            TraitLevels.bonusPercent(KillerRankingMod.CONFIG.mixedMadnessAttackSpeedPercent, level));
        ServerPlayNetworking.send(player, new DashboardPayload(DashboardData.JSON.toJson(data)));
    }
    private DashboardService() { }
}
