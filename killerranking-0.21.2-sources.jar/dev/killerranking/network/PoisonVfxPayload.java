package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record PoisonVfxPayload(UUID player, int ticks, boolean salmosa) implements class_8710 {
    public PoisonVfxPayload(UUID player, int ticks) { this(player, ticks, false); }
    public PoisonVfxPayload { ticks = Math.clamp(ticks, 0, 180); }
    public static final class_9154<PoisonVfxPayload> TYPE = new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"poison_vfx"));
    public static final class_9139<class_9129, PoisonVfxPayload> CODEC = class_9139.method_56437(
        (buffer, value) -> { buffer.method_10797(value.player()); buffer.method_10804(value.ticks()); buffer.method_52964(value.salmosa()); },
        buffer -> new PoisonVfxPayload(buffer.method_10790(), buffer.method_10816(), buffer.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
