package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record OpenPhonePayload() implements class_8710 {
	public static final class_9154<OpenPhonePayload> TYPE = new class_9154<>(KillerRankingMod.id("open_phone"));
	public static final class_9139<class_9129, OpenPhonePayload> CODEC = class_9139.method_56431(new OpenPhonePayload());
	@Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
