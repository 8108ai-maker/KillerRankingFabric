package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.RushRules;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record RushVisualPayload(UUID player,int remaining,int age) implements class_8710 {
    public RushVisualPayload { remaining=Math.clamp(remaining,0,RushRules.DURATION);age=Math.clamp(age,0,RushRules.DURATION); }
    public static final class_9154<RushVisualPayload> TYPE=new class_9154<>(KillerRankingMod.id("rush_visual"));
    public static final class_9139<class_9129,RushVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{ b.method_10797(v.player());b.method_10804(v.remaining());b.method_10804(v.age()); },
        b->new RushVisualPayload(b.method_10790(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
