package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.NeungsaSlashRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record NeungsaStatusPayload(boolean branch,boolean unlocked,int remaining,int cooldown,int iaidoRemaining,int iaidoCooldown,int iaidoPhase,int iaidoAge,int echoRemaining,int echoCooldown) implements class_8710 {
    public NeungsaStatusPayload {echoRemaining=Math.clamp(echoRemaining,0,dev.killerranking.combat.NeungsaEchoRules.DURATION);echoCooldown=Math.clamp(echoCooldown,0,dev.killerranking.combat.NeungsaEchoRules.COOLDOWN);remaining=Math.clamp(remaining,0,NeungsaSlashRules.DURATION);cooldown=Math.clamp(cooldown,0,NeungsaSlashRules.COOLDOWN);iaidoRemaining=Math.clamp(iaidoRemaining,0,20);iaidoCooldown=Math.clamp(iaidoCooldown,0,300);iaidoPhase=Math.clamp(iaidoPhase,0,2);iaidoAge=Math.clamp(iaidoAge,0,dev.killerranking.combat.NeungsaIaidoRules.MAX_HOLD);}
    public NeungsaStatusPayload(boolean branch,boolean unlocked,int remaining,int cooldown,int iaidoRemaining,int iaidoCooldown,int iaidoPhase,int iaidoAge){this(branch,unlocked,remaining,cooldown,iaidoRemaining,iaidoCooldown,iaidoPhase,iaidoAge,0,0);}
    public NeungsaStatusPayload(boolean branch,boolean unlocked,int remaining,int cooldown,int iaidoRemaining,int iaidoCooldown){this(branch,unlocked,remaining,cooldown,iaidoRemaining,iaidoCooldown,iaidoRemaining>0?2:0,0);}
    public NeungsaStatusPayload(boolean branch,boolean unlocked,int remaining,int cooldown){this(branch,unlocked,remaining,cooldown,0,0);}
    public static final class_9154<NeungsaStatusPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"neungsa_status"));
    public static final class_9139<class_9129,NeungsaStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_52964(v.branch());b.method_52964(v.unlocked());b.method_10804(v.remaining());b.method_10804(v.cooldown());b.method_10804(v.iaidoRemaining());b.method_10804(v.iaidoCooldown());b.method_10804(v.iaidoPhase());b.method_10804(v.iaidoAge());b.method_10804(v.echoRemaining());b.method_10804(v.echoCooldown());},
        b->new NeungsaStatusPayload(b.readBoolean(),b.readBoolean(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
