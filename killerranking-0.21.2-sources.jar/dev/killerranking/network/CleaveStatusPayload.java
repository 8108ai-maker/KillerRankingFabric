package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.CleaveRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record CleaveStatusPayload(boolean branch,boolean unlocked,boolean otherOwned,int phase,int age,int cooldown) implements class_8710 {
    public CleaveStatusPayload {phase=Math.clamp(phase,0,2);age=Math.clamp(age,0,CleaveRules.MAX_HOLD);cooldown=Math.clamp(cooldown,0,CleaveRules.COOLDOWN);}
    public static final class_9154<CleaveStatusPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"cleave_status"));
    public static final class_9139<class_9129,CleaveStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_52964(v.branch());b.method_52964(v.unlocked());b.method_52964(v.otherOwned());b.method_10804(v.phase());b.method_10804(v.age());b.method_10804(v.cooldown());},
        b->new CleaveStatusPayload(b.readBoolean(),b.readBoolean(),b.readBoolean(),b.method_10816(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
