package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.RushRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record RushStatusPayload(boolean branch,boolean unlocked,int activeTicks,int cooldownTicks) implements class_8710 {
    public RushStatusPayload { activeTicks=Math.clamp(activeTicks,0,RushRules.DURATION);cooldownTicks=Math.clamp(cooldownTicks,0,RushRules.COOLDOWN); }
    public static final class_9154<RushStatusPayload> TYPE=new class_9154<>(KillerRankingMod.id("rush_status"));
    public static final class_9139<class_9129,RushStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{ b.method_52964(v.branch());b.method_52964(v.unlocked());b.method_10804(v.activeTicks());b.method_10804(v.cooldownTicks()); },
        b->new RushStatusPayload(b.readBoolean(),b.readBoolean(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
