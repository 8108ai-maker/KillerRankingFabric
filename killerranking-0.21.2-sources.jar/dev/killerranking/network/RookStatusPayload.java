package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record RookStatusPayload(boolean branch,boolean unlocked,boolean otherOwned,int phase,int target,int remaining,int cooldown,boolean captured) implements class_8710 {
    public RookStatusPayload { phase=Math.clamp(phase,0,5);target=Math.max(-1,target);remaining=Math.clamp(remaining,0,200);cooldown=Math.clamp(cooldown,0,400); }
    public static final class_9154<RookStatusPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"rook_status"));
    public static final class_9139<class_9129,RookStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_52964(v.branch());b.method_52964(v.unlocked());b.method_52964(v.otherOwned());b.method_10804(v.phase());b.method_10804(v.target());b.method_10804(v.remaining());b.method_10804(v.cooldown());b.method_52964(v.captured());},
        b->new RookStatusPayload(b.readBoolean(),b.readBoolean(),b.readBoolean(),b.method_10816(),b.method_10816(),b.method_10816(),b.method_10816(),b.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
