package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** -1 cancels; the server validates every requested index against its own preview. */
public record CheckmateConfirmPayload(int selected) implements class_8710 {
    public static final class_9154<CheckmateConfirmPayload> TYPE=new class_9154<>(class_2960.method_60655(KillerRankingMod.MOD_ID,"checkmate_confirm"));
    public static final class_9139<class_9129,CheckmateConfirmPayload> CODEC=class_9139.method_56437(
        (b,v)->b.method_10804(v.selected()),b->new CheckmateConfirmPayload(b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
