package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Requests an action for the sending player; the server validates ownership and cost. */
public record CheckmateUnlockPayload() implements class_8710 {
    public static final class_9154<CheckmateUnlockPayload> TYPE = new class_9154<>(KillerRankingMod.id("checkmate_unlock"));
    public static final class_9139<class_9129, CheckmateUnlockPayload> CODEC = class_9139.method_56431(new CheckmateUnlockPayload());
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
