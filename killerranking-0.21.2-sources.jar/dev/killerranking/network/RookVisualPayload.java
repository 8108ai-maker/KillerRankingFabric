package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record RookVisualPayload(UUID owner,UUID victim,int phase,int age,int remaining) implements class_8710 {
    public RookVisualPayload { phase=Math.clamp(phase,0,5);age=Math.clamp(age,0,200);remaining=Math.clamp(remaining,0,200); }
    public static final class_9154<RookVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"rook_visual"));
    public static final class_9139<class_9129,RookVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.owner());b.method_52964(v.victim()!=null);if(v.victim()!=null)b.method_10797(v.victim());b.method_10804(v.phase());b.method_10804(v.age());b.method_10804(v.remaining());},
        b->{var owner=b.method_10790();var victim=b.readBoolean()?b.method_10790():null;return new RookVisualPayload(owner,victim,b.method_10816(),b.method_10816(),b.method_10816());});
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
