package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Request only; the server decides the trait, owner and 1,000P cost. */
public record SalmosaUnlockPayload() implements class_8710 {
    public static final class_9154<SalmosaUnlockPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"salmosa_unlock"));
    public static final class_9139<class_9129,SalmosaUnlockPayload> CODEC=class_9139.method_56431(new SalmosaUnlockPayload());
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
