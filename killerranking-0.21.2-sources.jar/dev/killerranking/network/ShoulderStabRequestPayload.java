package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Target IDs are only hints; range, sight, weapon and approach geometry are rechecked by the server. */
public record ShoulderStabRequestPayload(int operation,int target) implements class_8710 {
    public static final int START=0,RELEASE=1,CANCEL=2,COUNTER=3;
    public static final class_9154<ShoulderStabRequestPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"shoulder_stab_request"));
    public static final class_9139<class_9129,ShoulderStabRequestPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10804(v.operation());b.method_10804(v.target());},b->new ShoulderStabRequestPayload(b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
