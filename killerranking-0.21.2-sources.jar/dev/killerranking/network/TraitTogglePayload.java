package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Requests a toggle for the sending player only. The server owns the resulting state. */
public record TraitTogglePayload() implements class_8710 {
    public static final class_9154<TraitTogglePayload> TYPE = new class_9154<>(KillerRankingMod.id("trait_toggle"));
    public static final class_9139<class_9129, TraitTogglePayload> CODEC = class_9139.method_56431(new TraitTogglePayload());
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
