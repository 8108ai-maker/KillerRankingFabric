package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.Trait;
import dev.killerranking.combat.SpiritBranch;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record TraitVisualPayload(UUID player, Trait trait, SpiritBranch branch, boolean enabled, int introTicks, int leaseTicks, boolean salmosa) implements class_8710 {
    public TraitVisualPayload(UUID player, Trait trait, SpiritBranch branch, boolean enabled, int introTicks, int leaseTicks) {
        this(player, trait, branch, enabled, introTicks, leaseTicks, false);
    }
    public TraitVisualPayload {
        introTicks = Math.clamp(introTicks, 0, 100);
        leaseTicks = Math.clamp(leaseTicks, 0, 60);
        if (!enabled || trait == Trait.UNASSIGNED || leaseTicks == 0) { introTicks = 0; leaseTicks = 0; }
        if (trait != Trait.FIGHTING_SPIRIT) branch = SpiritBranch.NONE;
        if (trait != Trait.POISON_AURA) salmosa = false;
    }
    public static final class_9154<TraitVisualPayload> TYPE = new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"trait_visual"));
    public static final class_9139<class_9129, TraitVisualPayload> CODEC = class_9139.method_56437(
        (b, v) -> { b.method_10797(v.player()); b.method_10788(v.trait().id(), 32); b.method_10788(v.branch().id(), 32); b.method_52964(v.enabled()); b.method_10804(v.introTicks()); b.method_10804(v.leaseTicks()); b.method_52964(v.salmosa()); },
        b -> new TraitVisualPayload(b.method_10790(), Trait.fromId(b.method_10800(32)), SpiritBranch.fromId(b.method_10800(32)), b.readBoolean(), b.method_10816(), b.method_10816(), b.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
