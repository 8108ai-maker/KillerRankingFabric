package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ParryEffectPayload(UUID playerId, boolean reversed) implements class_8710 {
	public ParryEffectPayload(UUID playerId) { this(playerId, false); }
	public static final class_9154<ParryEffectPayload> TYPE = new class_9154<>(KillerRankingMod.id("parry_effect"));
	public static final class_9139<class_9129, ParryEffectPayload> CODEC = class_9139.method_56437(
			(buffer, payload) -> { buffer.method_10797(payload.playerId()); buffer.method_52964(payload.reversed()); },
			buffer -> new ParryEffectPayload(buffer.method_10790(), buffer.readBoolean()));

	@Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
