package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.CheckmateRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record CheckmateStatusPayload(boolean branch,boolean unlocked,boolean rushOwned,int activeTicks,int cooldownTicks) implements class_8710 {
    public CheckmateStatusPayload { activeTicks=Math.clamp(activeTicks,0,CheckmateRules.DURATION);cooldownTicks=Math.clamp(cooldownTicks,0,CheckmateRules.COOLDOWN); }
    public static final class_9154<CheckmateStatusPayload> TYPE=new class_9154<>(KillerRankingMod.id("checkmate_status"));
    public static final class_9139<class_9129,CheckmateStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{ b.method_52964(v.branch());b.method_52964(v.unlocked());b.method_52964(v.rushOwned());b.method_10804(v.activeTicks());b.method_10804(v.cooldownTicks()); },
        b->new CheckmateStatusPayload(b.readBoolean(),b.readBoolean(),b.readBoolean(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
