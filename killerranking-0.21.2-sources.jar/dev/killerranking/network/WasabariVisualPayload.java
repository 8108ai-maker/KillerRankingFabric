package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.WasabariRules;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
public record WasabariVisualPayload(UUID owner,UUID victim,int age,int remaining,float yaw,boolean tripped) implements class_8710 {
    public WasabariVisualPayload {age=Math.clamp(age,0,WasabariRules.DURATION);remaining=Math.clamp(remaining,0,WasabariRules.DURATION);yaw=Float.isFinite(yaw)?yaw:0;}
    public static final class_9154<WasabariVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"wasabari_visual"));
    public static final class_9139<class_9129,WasabariVisualPayload> CODEC=class_9139.method_56437((b,v)->{b.method_10797(v.owner());b.method_10797(v.victim());b.method_10804(v.age());b.method_10804(v.remaining());b.method_52941(v.yaw());b.method_52964(v.tripped());},b->new WasabariVisualPayload(b.method_10790(),b.method_10790(),b.method_10816(),b.method_10816(),b.readFloat(),b.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
