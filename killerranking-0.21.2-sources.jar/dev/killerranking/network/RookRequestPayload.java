package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Only requests: range, aim, funds, ownership and every phase are validated on the server. */
public record RookRequestPayload(int operation,int target) implements class_8710 {
    public static final int START=0,CONFIRM=1,CANCEL=2,THROW=3,PUNCH=4,MOUNT=5,UNLOCK=6;
    public RookRequestPayload { if(operation<0||operation>6||target< -1)throw new IllegalArgumentException("Invalid rook request"); }
    public static final class_9154<RookRequestPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"rook_request"));
    public static final class_9139<class_9129,RookRequestPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10804(v.operation());b.method_10804(v.target());},b->new RookRequestPayload(b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
