package dev.killerranking.network;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import dev.killerranking.KillerRankingMod;
/** Only successfully damaged victims receive their own attached slash flash. */
public record NeungsaCutEffectPayload(int entity,UUID uuid) implements class_8710 {
    public static final class_9154<NeungsaCutEffectPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"neungsa_cut_effect"));
    public static final class_9139<class_9129,NeungsaCutEffectPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10804(v.entity());b.method_10797(v.uuid());},b->new NeungsaCutEffectPayload(b.method_10816(),b.method_10790()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
