package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * One confirmed melee contact with a Killer Ranking weapon. The client draws the
 * weapon family's pixel impact, a shard burst and a floating damage number at the
 * contact point; sound is played by the server.
 *
 * @param family index into {@link dev.killerranking.combat.WeaponFamily}
 * @param yaw    attacker body yaw in degrees, so slash marks lean with the swing
 * @param damage health actually removed after armour and effects
 * @param crit   vanilla-style falling critical
 * @param lethal the contact killed the target
 */
public record WeaponHitPayload(UUID attacker, int family, double x, double y, double z, float yaw, float damage, boolean crit, boolean lethal)
    implements class_8710 {
    public static final class_9154<WeaponHitPayload> TYPE = new class_9154<>(KillerRankingMod.id("weapon_hit"));
    public static final class_9139<class_9129, WeaponHitPayload> CODEC = class_9139.method_56437(
        (b, p) -> { b.method_10797(p.attacker()); b.method_10804(p.family()); b.method_52940(p.x()); b.method_52940(p.y()); b.method_52940(p.z());
            b.method_52941(p.yaw()); b.method_52941(p.damage()); b.method_52964(p.crit()); b.method_52964(p.lethal()); },
        b -> new WeaponHitPayload(b.method_10790(), b.method_10816(), b.readDouble(), b.readDouble(), b.readDouble(), b.readFloat(), b.readFloat(), b.readBoolean(), b.readBoolean()));
    public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
