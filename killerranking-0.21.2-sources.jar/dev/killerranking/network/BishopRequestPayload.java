package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Commands carry no client-selected victim, spawn position, damage or cooldown. */
public record BishopRequestPayload(int operation) implements class_8710 {
    public static final int SUMMON=0,BARRAGE=1,DESIGNATE=2,UNLOCK=3;
    public static final class_9154<BishopRequestPayload> TYPE=new class_9154<>(KillerRankingMod.id("bishop_request"));
    public static final class_9139<class_9129,BishopRequestPayload> CODEC=class_9139.method_56437((b,v)->b.method_10804(v.operation()),b->new BishopRequestPayload(b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
