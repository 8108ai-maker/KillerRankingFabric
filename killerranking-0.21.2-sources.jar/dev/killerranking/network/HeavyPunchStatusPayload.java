package dev.killerranking.network;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.HeavyPunchRules;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record HeavyPunchStatusPayload(boolean available,int remaining,int cooldown) implements class_8710 {
    public HeavyPunchStatusPayload {remaining=Math.clamp(remaining,0,HeavyPunchRules.DURATION);cooldown=Math.clamp(cooldown,0,HeavyPunchRules.COOLDOWN);}
    public static final class_9154<HeavyPunchStatusPayload> TYPE=new class_9154<>(KillerRankingMod.id("heavy_punch_status"));
    public static final class_9139<class_9129,HeavyPunchStatusPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_52964(v.available());b.method_10804(v.remaining());b.method_10804(v.cooldown());},
        b->new HeavyPunchStatusPayload(b.readBoolean(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
