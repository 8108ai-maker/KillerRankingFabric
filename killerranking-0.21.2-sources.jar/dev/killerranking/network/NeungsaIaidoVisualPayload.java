package dev.killerranking.network;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.NeungsaIaidoRules;
public record NeungsaIaidoVisualPayload(UUID player,int age,int remaining,int phase,boolean full,double x,double y,double z,float dx,float dy,float dz) implements class_8710 {
    public NeungsaIaidoVisualPayload {age=Math.clamp(age,0,NeungsaIaidoRules.MAX_HOLD);remaining=Math.clamp(remaining,0,NeungsaIaidoRules.MAX_HOLD);phase=Math.clamp(phase,0,2);}
    public NeungsaIaidoVisualPayload(UUID player,int age,int remaining){this(player,age,remaining,remaining>0?NeungsaIaidoRules.SLASHING:0,false,0,0,0,0,0,1);}
    public static final class_9154<NeungsaIaidoVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"neungsa_iaido_visual"));
    public static final class_9139<class_9129,NeungsaIaidoVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_10804(v.age());b.method_10804(v.remaining());b.method_10804(v.phase());b.method_52964(v.full());b.method_52940(v.x());b.method_52940(v.y());b.method_52940(v.z());b.method_52941(v.dx());b.method_52941(v.dy());b.method_52941(v.dz());},
        b->new NeungsaIaidoVisualPayload(b.method_10790(),b.method_10816(),b.method_10816(),b.method_10816(),b.readBoolean(),b.readDouble(),b.readDouble(),b.readDouble(),b.readFloat(),b.readFloat(),b.readFloat()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
