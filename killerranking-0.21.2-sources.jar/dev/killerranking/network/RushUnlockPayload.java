package dev.killerranking.network;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Requests an action for the sending player; the server validates ownership and cost. */
public record RushUnlockPayload() implements class_8710 {
    public static final class_9154<RushUnlockPayload> TYPE = new class_9154<>(KillerRankingMod.id("rush_unlock"));
    public static final class_9139<class_9129, RushUnlockPayload> CODEC = class_9139.method_56431(new RushUnlockPayload());
    @Override public class_9154<? extends class_8710> method_56479() { return TYPE; }
}
