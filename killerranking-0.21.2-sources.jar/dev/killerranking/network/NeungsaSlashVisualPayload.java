package dev.killerranking.network;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.NeungsaSlashRules;

/** Animate the wielder only. There is deliberately no visible travelling slash entity or beam. */
public record NeungsaSlashVisualPayload(UUID player,int age,int remaining) implements class_8710 {
    public NeungsaSlashVisualPayload {age=Math.clamp(age,0,NeungsaSlashRules.DURATION);remaining=Math.clamp(remaining,0,NeungsaSlashRules.DURATION);}
    public static final class_9154<NeungsaSlashVisualPayload> TYPE=new class_9154<>(net.minecraft.class_2960.method_60655(KillerRankingMod.MOD_ID,"neungsa_slash_visual"));
    public static final class_9139<class_9129,NeungsaSlashVisualPayload> CODEC=class_9139.method_56437(
        (b,v)->{b.method_10797(v.player());b.method_10804(v.age());b.method_10804(v.remaining());},
        b->new NeungsaSlashVisualPayload(b.method_10790(),b.method_10816(),b.method_10816()));
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
