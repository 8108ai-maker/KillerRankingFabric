package dev.killerranking.mission;

import com.google.gson.Gson;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

public final class MissionCatalog {
    public record Definition(String id, String category, String statId, String title, int goal, int reward, int divisor, String unit) {
        public long rewardUnits() { return dev.killerranking.data.KillerPoints.missionReward(reward); }
        public int read(class_3222 p) {
            return p.method_14248().method_15025(stat());
        }
        public net.minecraft.class_3445<?> stat() {
            var id = class_2960.method_60654(statId);
            return switch (category) {
                case "kill" -> class_3468.field_15403.method_14956(class_7923.field_41177.method_17966(id).orElseThrow());
                case "mine" -> class_3468.field_15427.method_14956(class_7923.field_41175.method_17966(id).orElseThrow());
                case "craft" -> class_3468.field_15370.method_14956(class_7923.field_41178.method_17966(id).orElseThrow());
                // The registry's reverse lookup uses object identity. An equal freshly parsed
                // ResourceLocation is not the registered value and crashes Stat construction.
                default -> class_3468.field_15419.method_14956(class_7923.field_41183.method_17966(id).orElseThrow());
            };
        }
    }
    public static final List<Definition> ALL = load();
    public static Definition find(String id) { return ALL.stream().filter(d -> d.id.equals(id)).findFirst().orElse(null); }
    private static List<Definition> load() {
        try (var in = MissionCatalog.class.getResourceAsStream("/data/killerranking/missions.json")) {
            if (in == null) throw new IllegalStateException("Missing mission catalog");
            var result = List.of(new Gson().fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), Definition[].class));
            if (result.size() < 10 || result.stream().map(Definition::id).distinct().count() != result.size()) throw new IllegalStateException("Invalid mission catalog");
            for (var d : result) if (d.goal <= 0 || d.reward <= 0 || d.divisor <= 0) throw new IllegalStateException("Invalid mission " + d.id);
            return result;
        } catch (java.io.IOException e) { throw new IllegalStateException(e); }
    }
    public static List<Definition> choose(long seed) {
        var random = new Random(seed);
        var result = new ArrayList<Definition>();
        for (String category : List.of("kill", "mine", "craft", "activity")) {
            var pool = new ArrayList<>(ALL.stream().filter(d -> d.category.equals(category)).toList());
            Collections.shuffle(pool, random);
            result.addAll(pool.subList(0, category.equals("activity") ? 1 : 3));
        }
        return List.copyOf(result);
    }
    private MissionCatalog() { }
}
