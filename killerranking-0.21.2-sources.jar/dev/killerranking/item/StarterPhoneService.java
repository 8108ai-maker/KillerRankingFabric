package dev.killerranking.item;

import com.mojang.serialization.Codec;
import dev.killerranking.KillerRankingMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/** One starter phone per player, with delivery deferred until an inventory slot is free. */
public final class StarterPhoneService {
    private static final AttachmentType<Boolean> RECEIVED = AttachmentRegistry.create(KillerRankingMod.id("starter_phone_received"),
        b -> b.initializer(() -> false).persistent(Codec.BOOL).copyOnDeath());

    public static void initialize() { }

    public static void onJoin(class_3222 player) {
        if (!deliver(player)) player.method_43496(class_2561.method_43470("§e휴대폰 지급 대기: 인벤토리에 빈칸을 만들면 자동 지급됩니다."));
    }

    public static void tick(MinecraftServer server) {
        if (server.method_3780() % 20 != 0) return;
        for (var player : server.method_3760().method_14571()) deliver(player);
    }

    private static boolean deliver(class_3222 player) {
        if (player.getAttachedOrCreate(RECEIVED)) return true;
        // Existing players who already own a phone do not need another starter item.
        if (containsPhone(player.method_31548()) || containsPhone(player.method_7274())) {
            player.setAttached(RECEIVED, true);
            return true;
        }
        if (!player.method_5805() || player.method_7325()) return true; // Retry when playable.
        if (player.method_31548().method_7376() < 0) return false;
        var phone = new class_1799(KillerRankingMod.PHONE);
        if (!player.method_31548().method_7394(phone) || !phone.method_7960()) return false;
        player.setAttached(RECEIVED, true);
        player.field_7498.method_7623();
        player.method_43496(class_2561.method_43470("§b킬러랭킹 휴대폰이 지급되었습니다! 손에 들고 우클릭해서 사용하세요."));
        return true;
    }

    private static boolean containsPhone(class_1263 inventory) {
        for (int slot = 0; slot < inventory.method_5439(); slot++) {
            if (inventory.method_5438(slot).method_31574(KillerRankingMod.PHONE)) return true;
        }
        return false;
    }

    private StarterPhoneService() { }
}
