package dev.killerranking.item;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.data.PlayerProfiles;
import dev.killerranking.network.OpenPhonePayload;
import dev.killerranking.network.ProfilePayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

public final class KillerPhoneItem extends class_1792 {
	public KillerPhoneItem(class_1793 properties) { super(properties.method_7889(1)); }

	@Override
	public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
		if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
			KillerRankingMod.assignAndSync(serverPlayer);
			ServerPlayNetworking.send(serverPlayer, ProfilePayload.from(PlayerProfiles.get(serverPlayer)));
			ServerPlayNetworking.send(serverPlayer, new OpenPhonePayload());
		}
		return class_1271.method_29237(player.method_5998(hand), level.field_9236);
	}
}
