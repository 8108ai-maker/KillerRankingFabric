package dev.killerranking.item;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_1829;
import net.minecraft.class_1834;

/** A fast boxing hand wrap: six base damage, 2.8 attacks per second. */
public final class BandagedFistItem extends class_1829 {
    public BandagedFistItem() {
        super(class_1834.field_8923, new class_1792.class_1793()
            .method_57348(class_1829.method_57394(class_1834.field_8923, 3, -1.2F))
            .method_7894(class_1814.field_8907));
    }

    @Override public boolean method_7878(class_1799 stack, class_1799 ingredient) {
        return ingredient.method_31574(class_1802.field_19044) || ingredient.method_31574(class_1802.field_8276);
    }
}
