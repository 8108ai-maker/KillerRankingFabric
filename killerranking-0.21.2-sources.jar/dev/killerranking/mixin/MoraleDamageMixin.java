package dev.killerranking.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import dev.killerranking.combat.MoraleRules;
import dev.killerranking.combat.MoraleService;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1309.class)
abstract class MoraleDamageMixin {
    // Observe the final health loss, including lethal hits and absorption. Canceled/blocked hits give no morale.
    @WrapMethod(method = "hurt")
    private boolean killerranking$recordMorale(class_1282 source, float amount, Operation<Boolean> original) {
        class_1309 victim = (class_1309) (Object) this;
        float health = victim.method_6032(), absorption = victim.method_6067();
        boolean shieldBlocked = victim.method_6061(source);
        boolean hit = original.call(source, amount);
        if (hit && !shieldBlocked) MoraleService.afterHit(victim, source,
            MoraleRules.actualDamage(health, absorption, victim.method_6032(), victim.method_6067()));
        return hit;
    }
}
