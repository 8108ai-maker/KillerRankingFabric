package dev.killerranking.mixin;

import dev.killerranking.KillerRankingMod;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
abstract class RookPushMixin {
    @Inject(method="push(DDD)V",at=@At("HEAD"),cancellable=true)
    private void killer$fixedGrab(double x,double y,double z,CallbackInfo ci) {
        if(KillerRankingMod.ROOK.locked((class_1297)(Object)this)||(Object)this instanceof net.minecraft.class_3222 p&&KillerRankingMod.SHOULDER_STAB.casting(p))ci.cancel();
    }
}
