package dev.killerranking.mixin;

import dev.killerranking.combat.SkillCombatLock;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1657.class)
abstract class CheckmateAttackMixin {
    @Inject(method="attack",at=@At("HEAD"),cancellable=true)
    private void killerranking$checkmateAttack(class_1297 target,CallbackInfo ci) {
        if((Object)this instanceof class_3222 p&&SkillCombatLock.blocksAttack(p)) ci.cancel();
    }
}
