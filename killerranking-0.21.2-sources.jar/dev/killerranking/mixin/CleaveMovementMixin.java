package dev.killerranking.mixin;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_1309.class)
abstract class CleaveMovementMixin {
    @Inject(method="travel",at=@At("HEAD"),cancellable=true)
    private void cleave$casting(class_243 movement,CallbackInfo ci){
        if((Object)this instanceof class_3222 p&&(KillerRankingMod.NEUNGSA_SKILL.dashing(p)||KillerRankingMod.SHOULDER_STAB.casting(p)||KillerRankingMod.CLEAVE.slashing(p)||KillerRankingMod.MADNESS_LEAP.casting(p))){p.method_18799(class_243.field_1353);ci.cancel();}
    }
}
