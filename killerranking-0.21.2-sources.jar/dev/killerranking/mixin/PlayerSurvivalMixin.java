package dev.killerranking.mixin;

import dev.killerranking.combat.MadnessSurvivalService;
import net.minecraft.class_1282;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1657.class)
abstract class PlayerSurvivalMixin {
    @ModifyVariable(method = "actuallyHurt", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/world/entity/player/Player;getCombatTracker()Lnet/minecraft/world/damagesource/CombatTracker;"), ordinal = 0)
    private float killerranking$survive(float damage, class_1282 source, float originalDamage) {
        return (Object) this instanceof class_3222 player ? MadnessSurvivalService.limitDamage(player, source, damage) : damage;
    }
}
