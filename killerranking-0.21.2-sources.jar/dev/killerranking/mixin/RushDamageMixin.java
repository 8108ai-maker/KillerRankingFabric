package dev.killerranking.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.killerranking.combat.RushDamage;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
abstract class RushDamageMixin implements RushDamage.RushDamageAccess {
    @Shadow protected float lastHurt;
    @Override public float killerranking$lastDamage() { return lastHurt; }
    @Override public void killerranking$lastDamage(float value) { lastHurt=value; }
    @ModifyExpressionValue(method="hurt",at=@At(value="FIELD",target="Lnet/minecraft/world/entity/LivingEntity;invulnerableTime:I",opcode=org.objectweb.asm.Opcodes.GETFIELD))
    private int killerranking$rushCooldown(int value) { return RushDamage.current((class_1309)(Object)this)?0:value; }
    @Inject(method="knockback",at=@At("HEAD"),cancellable=true)
    private void killerranking$rushHold(double strength,double x,double z,CallbackInfo info) {
        if(RushDamage.suppressKnockback((class_1309)(Object)this)) info.cancel();
    }
}
