package dev.killerranking.mixin;

import dev.killerranking.Trait;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.TraitLevels;
import dev.killerranking.combat.CombatRules;
import dev.killerranking.data.PlayerProfiles;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
abstract class LivingEntityMixin {
    // Preserve each scoped bleed's fixed pulse after armor and enchantment mitigation.
    @Inject(method = "getDamageAfterMagicAbsorb", at = @At("RETURN"), cancellable = true)
    private void killerranking$bleeding(class_1282 source, float amount, CallbackInfoReturnable<Float> result) {
        if (dev.killerranking.combat.BleedingDamage.current((class_1309) (Object) this) && result.getReturnValue() > 0)
            result.setReturnValue(dev.killerranking.combat.BleedingDamage.amount((class_1309)(Object)this));
    }
	@ModifyVariable(method = "hurt", at = @At("HEAD"), argsOnly = true, ordinal = 0)
	private float killerranking$applyFightingSpirit(float amount, class_1282 source) {
        if (dev.killerranking.combat.BleedingDamage.current((class_1309) (Object) this)) return amount;
        if (source.method_5529() instanceof class_3222 attacker) {
            amount *= (float) dev.killerranking.data.MoraleState.get(attacker);
            if (source.method_5526() == attacker && !source.method_48789(net.minecraft.class_8103.field_42247)
                && dev.killerranking.combat.KnightWeaponEffects.striking(attacker)) amount *= 2;
        }
		if ((Object) this instanceof class_3222 defender && source.method_5529() != null && PlayerProfiles.get(defender).trait() == Trait.FIGHTING_SPIRIT) {
			float reduction = dev.killerranking.combat.SpiritEffects.defense(defender) / 100.0F;
			amount *= 1.0F - reduction;
		}
        if (source.method_5529() instanceof class_3222 attacker)
            amount *= 1.0F + (float)(dev.killerranking.combat.MadnessEffects.damageBonus(attacker)/100.0);
        if (source.method_5529() instanceof class_3222 attacker && source.method_5526() == attacker
            && !source.method_48789(net.minecraft.class_8103.field_42247)
            && dev.killerranking.combat.InheritedWeaponEffects.madnessBonus(attacker)) {
            amount *= (float) dev.killerranking.combat.InheritedWeaponEffects.DAMAGE_MULTIPLIER;
        }
		return amount;
	}
}
