package dev.killerranking.mixin;

import dev.killerranking.combat.InheritedWeaponEffects;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1657;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Insert before Better Combat's client off-hand lookup by applying this HEAD injection after its mixin.
@Mixin(value = class_1309.class, priority = 900)
abstract class InheritedWeaponSpeedMixin {
    @Inject(method = "getAttributeValue", at = @At("HEAD"), cancellable = true)
    private void killerranking$pairedSpeed(class_6880<class_1320> attribute, CallbackInfoReturnable<Double> result) {
        if (attribute.equals(class_5134.field_23723) && (Object) this instanceof class_1657 player
            && InheritedWeaponEffects.paired(player)) {
            result.setReturnValue(InheritedWeaponEffects.pairedSpeed(player.method_5996(attribute)));
        }
    }
}
