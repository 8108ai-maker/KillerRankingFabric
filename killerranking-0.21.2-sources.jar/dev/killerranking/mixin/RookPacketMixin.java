package dev.killerranking.mixin;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_2600;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.network.protocol.game.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Check on the server thread before accepting movement, attacks, block use or item actions. */
@Mixin(class_3244.class)
abstract class RookPacketMixin {
    @Shadow public class_3222 player;
    @Inject(method="handleMovePlayer",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabMove(class_2828 packet,CallbackInfo ci) {
        class_2600.method_11073(packet,(class_3244)(Object)this,player.method_51469());
        if(KillerRankingMod.ROOK.locked(player)||KillerRankingMod.SHOULDER_STAB.casting(player)) {
            // Keep looking around responsive, while ignoring movement during the grapple.
            if(packet.method_36172()){
                float yaw=packet.method_12271(player.method_36454()),pitch=packet.method_12270(player.method_36455());
                if(Float.isFinite(yaw)&&Float.isFinite(pitch)){player.method_36456(net.minecraft.class_3532.method_15393(yaw));player.method_36457(Math.clamp(pitch,-90,90));}
            }
            ci.cancel();
        }
    }
    @Inject(method="handleInteract",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabInteract(class_2824 packet,CallbackInfo ci) {
        class_2600.method_11073(packet,(class_3244)(Object)this,player.method_51469());
        if(KillerRankingMod.ROOK.locked(player))ci.cancel();
    }
    @Inject(method="handleUseItem",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabUse(class_2886 packet,CallbackInfo ci) {
        class_2600.method_11073(packet,(class_3244)(Object)this,player.method_51469());
        if(KillerRankingMod.ROOK.locked(player))ci.cancel();
    }
    @Inject(method="handleUseItemOn",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabBlock(class_2885 packet,CallbackInfo ci) {
        class_2600.method_11073(packet,(class_3244)(Object)this,player.method_51469());
        if(KillerRankingMod.ROOK.locked(player))ci.cancel();
    }
    @Inject(method="handlePlayerAction",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabAction(class_2846 packet,CallbackInfo ci) {
        class_2600.method_11073(packet,(class_3244)(Object)this,player.method_51469());
        if(KillerRankingMod.ROOK.locked(player))ci.cancel();
    }
    @Inject(method="handleSetCarriedItem",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabSlot(class_2868 packet,CallbackInfo ci) {
        class_2600.method_11073(packet,(class_3244)(Object)this,player.method_51469());
        if(KillerRankingMod.ROOK.locked(player))ci.cancel();
    }
}
