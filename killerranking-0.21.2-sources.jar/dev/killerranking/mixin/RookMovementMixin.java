package dev.killerranking.mixin;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
abstract class RookMovementMixin {
    @Inject(method="travel",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabTravel(class_243 input,CallbackInfo ci) {
        var entity=(class_1309)(Object)this;
        if(KillerRankingMod.ROOK.locked(entity)){entity.method_18799(class_243.field_1353);ci.cancel();}
    }
    @Inject(method="knockback",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabKnockback(double strength,double x,double z,CallbackInfo ci) {
        if(KillerRankingMod.ROOK.locked((class_1309)(Object)this))ci.cancel();
    }
    @Inject(method="isPushable",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabNoPush(CallbackInfoReturnable<Boolean> cir) {
        if(KillerRankingMod.ROOK.locked((class_1309)(Object)this))cir.setReturnValue(false);
    }
    @Inject(method="push(Lnet/minecraft/world/entity/Entity;)V",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabPair(net.minecraft.class_1297 other,CallbackInfo ci) {
        if(KillerRankingMod.ROOK.locked((class_1309)(Object)this)||KillerRankingMod.ROOK.locked(other))ci.cancel();
    }
}
