package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.network.SpiritVfxPayload;
import dev.killerranking.combat.SpiritBranch;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_4002;
import net.minecraft.class_4066;
import java.util.*;

public final class SpiritVfx {
    private static final Map<UUID, State> ACTIVE = new HashMap<>();
    private static class_4002 sprites;
    private static final class State {
        int ticks, age;
        final SpiritBranch branch;
        State(int ticks, SpiritBranch branch) { this.ticks = ticks; this.branch = branch; }
    }
    public static void register() {
        ParticleFactoryRegistry.getInstance().register(KillerRankingMod.SPIRIT_AURA, set -> {
            sprites = set;
            return (parameters, world, x, y, z, dx, dy, dz) -> null;
        });
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            var client = class_310.method_1551();
            if (client.field_1687 == null || context.matrixStack() == null || context.consumers() == null) return;
            float delta = context.tickCounter().method_60637(false);
            for (var player : visible(client)) {
                if (CleaveVfx.full(player.method_5667())) continue;
                var state = ACTIVE.get(player.method_5667());
                float alpha = Math.min(1, (state.age + delta) / 10f) * Math.min(1, (state.ticks - delta) / 10f);
                SpiritGlyph.render(context, player, delta, Math.max(0, alpha), state.branch);
            }
        });
    }
    public static void accept(SpiritVfxPayload payload) {
        if (payload.ticks() == 0) ACTIVE.remove(payload.player());
        else ACTIVE.compute(payload.player(), (id, state) -> {
            if (state == null || state.branch != payload.branch()) return new State(payload.ticks(), payload.branch());
            state.ticks = payload.ticks();
            return state;
        });
    }
    public static void clear() { ACTIVE.clear(); }
    public static boolean active(UUID id) { return ACTIVE.containsKey(id); }
    public static SpiritBranch branch(UUID id) {
        if (CleaveVfx.full(id)) return SpiritBranch.KING_AND_KILL;
        var state = ACTIVE.get(id);
        return state == null ? SpiritBranch.NONE : state.branch;
    }
    private static List<class_1657> visible(class_310 client) {
        var camera = client.method_1560();
        if (camera == null || client.field_1687 == null) return List.of();
        return ACTIVE.keySet().stream().map(client.field_1687::method_18470).filter(Objects::nonNull)
            .filter(p -> !KillingIntentVfx.hiddenForCamera(p) && p.method_5858(camera) <= 1024)
            .sorted(Comparator.comparingDouble(p -> p.method_5858(camera))).limit(4).toList();
    }
    public static void tick(class_310 client) {
        if (client.method_1493() || client.field_1687 == null) return;
        ACTIVE.values().forEach(s -> { s.ticks--; s.age++; });
        ACTIVE.values().removeIf(s -> s.ticks <= 0);
        if (sprites == null) return;
        var setting = client.field_1690.method_42475().method_41753();
        int count = setting == class_4066.field_18199 ? 2 : setting == class_4066.field_18198 ? 5 : 10;
        for (var player : visible(client)) {
            if (CleaveVfx.full(player.method_5667())) continue;
            var branch = branch(player.method_5667());
            for (int i = 0; i < count; i++) client.field_1713.method_3058(new SpiritAuraParticle(client.field_1687, player, sprites, false, branch));
            if (setting != class_4066.field_18199) {
                int sparks = setting == class_4066.field_18197 ? 2 : 1;
                for (int i = 0; i < sparks; i++) client.field_1713.method_3058(new SpiritAuraParticle(client.field_1687, player, sprites, true, branch));
            }
        }
    }
    private SpiritVfx() { }
    static void emitWhite(class_1657 player,int count) {
        var client=class_310.method_1551();if(client.field_1687==null||sprites==null)return;
        for(int i=0;i<count;i++)client.field_1713.method_3058(new SpiritAuraParticle(client.field_1687,player,sprites,i%6==0,SpiritBranch.KING_AND_KILL));
    }
}
