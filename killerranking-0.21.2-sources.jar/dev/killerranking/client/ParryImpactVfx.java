package dev.killerranking.client;

import com.mojang.blaze3d.vertex.*;
import dev.killerranking.network.ParryImpactPayload;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_638;

/** A white pixel impact, short crossed glint and separated sparks at the contact point. */
public final class ParryImpactVfx {
    private record Impact(UUID owner,class_243 position,long born) { }
    private static final List<Impact> IMPACTS=new ArrayList<>();
    private static class_638 world;
    private static long received,rendered;
    public static void register(){
        WorldRenderEvents.AFTER_ENTITIES.register(ParryImpactVfx::render);
        HudRenderCallback.EVENT.register((g,t)->{
            var c=class_310.method_1551();if(c.field_1724==null||c.field_1687!=world)return;
            float delta=t.method_60637(false),opacity=0;
            for(var i:IMPACTS)if(i.owner.equals(c.field_1724.method_5667())){
                float age=c.field_1687.method_8510()-i.born+delta;
                if(age<2)opacity=Math.max(opacity,.13f*(1-age/2));
            }
            if(opacity>.004)g.method_25294(0,0,g.method_51421(),g.method_51443(),((int)(opacity*255)<<24)|0xEAF9FF);
        });
    }
    public static void accept(ParryImpactPayload p){
        var c=class_310.method_1551();if(c.field_1687==null)return;
        if(world!=c.field_1687){clear();world=c.field_1687;}
        if(!Double.isFinite(p.x())||!Double.isFinite(p.y())||!Double.isFinite(p.z()))return;
        if(IMPACTS.size()>=64)IMPACTS.removeFirst();
        CombatCameraFeedback.parry(p.player());
        IMPACTS.add(new Impact(p.player(),new class_243(p.x(),p.y(),p.z()),world.method_8510()));received++;
    }
    public static void tick(class_310 c){
        if(c.field_1687!=world){clear();world=c.field_1687;return;}
        if(world==null||c.method_1493())return;
        IMPACTS.removeIf(i->world.method_8510()-i.born>=8);
    }
    public static int activeCount(){return IMPACTS.size();}
    public static long receivedCount(){return received;}
    public static long renderedCount(){return rendered;}
    public static void clear(){IMPACTS.clear();world=null;received=rendered=0;}
    private static void render(WorldRenderContext ctx){
        if(ctx.world()!=world||ctx.matrixStack()==null||ctx.consumers()==null)return;
        var camera=ctx.camera().method_19326();var vertices=ctx.consumers().getBuffer(WeaponTrailRenderType.BREATH);
        float delta=ctx.tickCounter().method_60637(false);
        for(var i:IMPACTS){
            if(i.position.method_1025(camera)>4096)continue;
            float age=world.method_8510()-i.born+delta;if(age<0||age>=8)continue;
            var stack=ctx.matrixStack();stack.method_22903();
            stack.method_22904(i.position.field_1352-camera.field_1352,i.position.field_1351-camera.field_1351,i.position.field_1350-camera.field_1350);
            stack.method_22907(ctx.camera().method_23767());
            float core=Math.max(0,1-age/3),length=.16f+.055f*age;
            if(core>0){
                // Flat pixel caps: no hooked crescents, no disconnected blade trail.
                rect(stack,vertices,0,0,length,.025f,0,core,0xF7FDFF);
                rect(stack,vertices,0,0,.025f,length,0,core,0xF7FDFF);
                rect(stack,vertices,0,0,.065f,.065f,.002f,core,0xFFFFFF);
            }
            for(int spark=0;spark<10;spark++){
                double a=spark*Math.PI*.2+(i.born%7)*.17;
                float speed=.035f+(spark%3)*.012f,r=.08f+age*speed;
                float fade=(1-age/8)*(spark%2==0?1:.7f);
                stack.method_22903();stack.method_22907(net.minecraft.class_7833.field_40718.rotation((float)a));
                float streak=.018f+(spark%3)*.008f;
                int color=spark%3==0?0x9CE9FF:0xF2FAFF;
                rect(stack,vertices,r,0,streak,.008f,-.002f,fade,color);
                rect(stack,vertices,r,0,.008f,streak,-.002f,fade,color);
                stack.method_22909();
            }
            stack.method_22909();rendered++;
        }
    }
    private static void rect(class_4587 stack,class_4588 v,float x,float y,float halfX,float halfY,float z,float opacity,int rgb){
        int color=((int)(Math.clamp(opacity,0,1)*255)<<24)|rgb;var p=stack.method_23760();
        float[][] corners={{x-halfX,y-halfY},{x+halfX,y-halfY},{x+halfX,y+halfY},{x-halfX,y+halfY}};
        for(int k=0;k<4;k++)v.method_22918(p.method_23761(),corners[k][0],corners[k][1],z).method_39415(color)
            .method_22913(k==0||k==3?0:1,k<2?0:1).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(p,0,0,1);
    }
    private ParryImpactVfx(){ }
}
