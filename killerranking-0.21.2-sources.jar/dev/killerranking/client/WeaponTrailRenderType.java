package dev.killerranking.client;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;

/** Unlit on both faces, with ordinary alpha blending for the fading pixel frames. */
final class WeaponTrailRenderType extends class_1921 {
    static final class_1921 BREATH=method_24049("killerranking_neungsa_breath",
        class_290.field_1580,class_293.class_5596.field_27382,4096,false,true,
        class_4688.method_23598().method_34578(field_29414)
            .method_34577(new class_4683(net.minecraft.class_2960.method_60656("textures/block/white_concrete.png"),false,false))
            .method_23615(field_21370).method_23603(field_21345)
            .method_23616(field_21350).method_23617(false));
    private static final Map<class_2960, class_1921> SPRITES = new HashMap<>();
    private static final Map<TrailStyle, class_1921> STYLES = new EnumMap<>(TrailStyle.class);

    /** Full-bright translucent quads over any mod texture (trails, hit sprites). */
    static class_1921 sprite(class_2960 texture) {
        return SPRITES.computeIfAbsent(texture, t -> method_24049("killerranking_sprite_" + t.method_12832().replace('/', '_'),
            class_290.field_1580, class_293.class_5596.field_27382, 1536, false, true,
            class_4688.method_23598()
                // Entity-translucent-emissive still applies directional normal lighting.
                // The eyes shader preserves the texture's RGB regardless of blade direction.
                .method_34578(field_29414)
                .method_34577(new class_4683(t, false, false))
                .method_23615(field_21370)
                .method_23603(field_21345)
                .method_23616(field_21350)
                .method_23617(false)));
    }

    static class_1921 of(TrailStyle style) { return STYLES.computeIfAbsent(style, s -> sprite(s.texture)); }

    static final class_1921 NEUNGSA = of(TrailStyle.NEUNGSA);
    static final class_1921 LAYER = of(TrailStyle.GENERIC);

    private WeaponTrailRenderType() {
        super("killerranking_weapon_trail", class_290.field_1580,
            class_293.class_5596.field_27382, 1536, false, true, () -> {}, () -> {});
    }
}
