package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.NeungsaIaidoRules;
import dev.killerranking.network.NeungsaIaidoVisualPayload;
import dev.killerranking.visual.NeungsaBreathMotion;
import dev.killerranking.visual.NeungsaIaidoDrawMotion;
import dev.kosmx.playerAnim.api.firstPerson.*;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.api.layered.modifier.SpeedModifier;
import dev.kosmx.playerAnim.minecraftApi.*;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import java.util.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_742;

/** Compact fixed-grip Iaido with two connected purple streams inhaled below the chin. */
public final class NeungsaIaidoVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("neungsa_iaido_layer");
    private static final Map<UUID,State> ACTIVE=new HashMap<>();
    private static int breaths,breathSegments;
    private static final class State {int age,remaining,phase;boolean full,animated;State(NeungsaIaidoVisualPayload p){age=p.age();phase=p.phase();full=p.full();remaining=full&&phase==NeungsaIaidoRules.SLASHING?NeungsaIaidoDrawMotion.VISUAL_TICKS-age:p.remaining();}}
    public static void register(){
        WorldRenderEvents.AFTER_ENTITIES.register(NeungsaIaidoVfx::renderBreath);
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{
            var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new SpeedModifier(32));
            layer.addModifierLast(new LeftHandedHelperModifier(p));stack.addAnimLayer(3200,layer);
            PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
        });
        ClientTickEvents.END_CLIENT_TICK.register(c->{
            if(c.field_1687==null||c.method_1493())return;
            for(var id:new ArrayList<>(ACTIVE.keySet())){
                var s=ACTIVE.get(id);var p=c.field_1687.method_18470(id);
                if(!(p instanceof class_742 player)||!player.method_5805()||!player.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA)||s.remaining--<=0){remove(id);continue;}
                if(!s.animated)s.animated=animate(player,s);
                s.age++;
            }
        });
    }
    private static void renderBreath(WorldRenderContext context){
        breathSegments=0;
        var c=class_310.method_1551();
        if(c.field_1687==null||context.matrixStack()==null||context.consumers()==null)return;
        var camera=context.camera().method_19326();float partial=context.tickCounter().method_60637(false);int players=0;
        for(var entry:ACTIVE.entrySet()){
            var state=entry.getValue();if(state.phase!=NeungsaIaidoRules.CHARGING||state.age<8)continue;
            var raw=c.field_1687.method_18470(entry.getKey());
            if(!(raw instanceof class_742 p)||p.method_5707(camera)>1024||++players>8)continue;
            boolean first=p==c.method_1560()&&c.field_1690.method_31044().method_31034();
            var look=p.method_5720();var side=new class_243(look.field_1350,0,-look.field_1352).method_1029();
            if(side.method_1027()<.01)side=new class_243(1,0,0);
            var up=look.method_1036(side).method_1029();
            var position=p.method_30950(partial).method_1031(0,p.method_5751()-(first?.10:.34),0).method_1019(look.method_1021(first?.30:.24));
            float scale=first?.62f:1,age=state.age+partial;
            float fade=Math.clamp((age-8)/6,0,1);
            var stack=context.matrixStack();stack.method_22903();stack.method_22904(position.field_1352-camera.field_1352,position.field_1351-camera.field_1351,position.field_1350-camera.field_1350);
            var vertices=context.consumers().getBuffer(WeaponTrailRenderType.BREATH);
            for(int hand:new int[]{-1,1})for(int i=0;i<NeungsaBreathMotion.SEGMENTS;i++){
                float u=i/(float)NeungsaBreathMotion.SEGMENTS,v=(i+1)/(float)NeungsaBreathMotion.SEGMENTS;
                var a=NeungsaBreathMotion.point(u,hand,age);var b=NeungsaBreathMotion.point(v,hand,age);
                float dx=b.side()-a.side(),dy=b.height()-a.height();float length=(float)Math.sqrt(dx*dx+dy*dy);
                var normal=side.method_1021(-dy/length).method_1019(up.method_1021(dx/length));
                var start=side.method_1021(a.side()*scale).method_1019(up.method_1021(a.height()*scale)).method_1019(look.method_1021(a.forward()*scale));
                var end=side.method_1021(b.side()*scale).method_1019(up.method_1021(b.height()*scale)).method_1019(look.method_1021(b.forward()*scale));
                for(int pass=0;pass<3;pass++){
                    float width=(pass==0?2.4f:pass==1?1:.32f)*scale;
                    float wa=NeungsaBreathMotion.width(u)*width,wb=NeungsaBreathMotion.width(v)*width;
                    float alpha=fade*(pass==0?.16f:pass==1?.68f:.92f);
                    float aa=alpha*NeungsaBreathMotion.flow(u,age)*(float)Math.sin(Math.PI*u);
                    float ab=alpha*NeungsaBreathMotion.flow(v,age)*(float)Math.sin(Math.PI*v);
                    float r=pass==2?.94f:.58f,g=pass==2?.78f:.24f;
                    vertex(stack,vertices,start.method_1019(normal.method_1021(-wa)),0,1,aa,r,g);
                    vertex(stack,vertices,start.method_1019(normal.method_1021(wa)),0,0,aa,r,g);
                    vertex(stack,vertices,end.method_1019(normal.method_1021(wb)),1,0,ab,r,g);
                    vertex(stack,vertices,end.method_1019(normal.method_1021(-wb)),1,1,ab,r,g);
                }
                breathSegments++;breaths++;
            }
            stack.method_22909();
        }
    }
    private static void vertex(class_4587 stack,class_4588 vertices,class_243 at,float u,float v,float alpha,float r,float g){
        vertices.method_22918(stack.method_23760().method_23761(),(float)at.field_1352,(float)at.field_1351,(float)at.field_1350).method_22915(r,g,1,alpha)
            .method_22913(u,v).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(stack.method_23760(),0,0,1);
    }
    public static void accept(NeungsaIaidoVisualPayload p){
        var old=ACTIVE.get(p.player());
        if(p.remaining()==0||p.phase()==0){
            // Finish the cut on the server after one second, while the drawn
            // blade remains visible for its separate two-second follow-through.
            // Early cancellation still removes the presentation immediately.
            if(old!=null&&old.full&&old.phase==NeungsaIaidoRules.SLASHING&&p.full()&&p.age()>=NeungsaIaidoRules.DURATION)return;
            remove(p.player());return;
        }
        if(old==null||old.phase!=p.phase()||old.full!=p.full()||p.age()<old.age-3)ACTIVE.put(p.player(),new State(p));
        else if(!old.full||old.phase!=NeungsaIaidoRules.SLASHING)old.remaining=p.remaining();
    }
    @SuppressWarnings("unchecked") private static boolean animate(class_742 p,State s){
        var raw=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(!(raw instanceof ModifierLayer<?> layer))return false;
        String name="neungsa_katana_iaido";
        if(s.phase==NeungsaIaidoRules.CHARGING||s.full)name+="_"+(s.phase==NeungsaIaidoRules.CHARGING?"charge":"dash")+(p.method_52814().comp_1629()==net.minecraft.class_8685.class_7920.field_41122?"_slim":"");
        var clip=PlayerAnimationRegistry.getAnimation(KillerRankingMod.id(name));if(clip==null)return false;
        NeungsaDrawController.iaido(p);
        var k=(KeyframeAnimationPlayer)clip.playAnimation();
        for(int i=0;i<s.age*32;i++)k.tick();
        k.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);k.setFirstPersonConfiguration(new FirstPersonConfiguration(true,true,true,false));
        ((ModifierLayer<IAnimation>)layer).setAnimation(k);return true;
    }
    public static boolean active(UUID id){return ACTIVE.containsKey(id);}
    public static boolean blocksAttack(UUID id){var s=ACTIVE.get(id);return s!=null&&(!s.full||s.phase!=NeungsaIaidoRules.SLASHING||s.age<NeungsaIaidoRules.DURATION);}
    public static boolean interruptRecovery(UUID id){
        var s=ACTIVE.get(id);
        if(s==null||!s.full||s.phase!=NeungsaIaidoRules.SLASHING||s.age<NeungsaIaidoRules.DURATION)return false;
        remove(id);return true;
    }
    public static int phase(UUID id){var s=ACTIVE.get(id);return s==null?0:s.phase;}
    public static boolean full(UUID id){var s=ACTIVE.get(id);return s!=null&&s.full;}
    public static int breaths(){return breaths;}
    public static int breathSegments(){return breathSegments;}
    private static void remove(UUID id){
        ACTIVE.remove(id);var c=class_310.method_1551();if(c.field_1687==null)return;
        var p=c.field_1687.method_18470(id);if(p instanceof class_742 player){
            var layer=PlayerAnimationAccess.getPlayerAssociatedData(player).get(LAYER);if(layer instanceof ModifierLayer<?> l)l.setAnimation(null);
        }
    }
    public static void clear(){for(var id:new ArrayList<>(ACTIVE.keySet()))remove(id);breaths=0;breathSegments=0;NeungsaCutParticle.clear();}
    private NeungsaIaidoVfx(){ }
}
