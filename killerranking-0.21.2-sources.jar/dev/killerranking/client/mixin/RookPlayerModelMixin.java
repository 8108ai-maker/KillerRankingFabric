package dev.killerranking.client.mixin;
import dev.killerranking.client.RookLegRenderer;
import net.minecraft.class_1309;
import net.minecraft.class_591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_591.class)
abstract class RookPlayerModelMixin {
    @Inject(method="setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V",at=@At("TAIL"))
    private void killerranking$rookParts(class_1309 entity,float walk,float speed,float age,float yaw,float pitch,CallbackInfo ci) {
        RookLegRenderer.bind((class_591<?>)(Object)this,entity);
    }
}
