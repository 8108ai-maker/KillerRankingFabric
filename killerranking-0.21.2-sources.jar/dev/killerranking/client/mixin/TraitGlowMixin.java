package dev.killerranking.client.mixin;

import dev.killerranking.client.TraitVisuals;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
abstract class TraitGlowMixin {
    @Inject(method="shouldEntityAppearGlowing", at=@At("RETURN"), cancellable=true)
    private void killerranking$outline(class_1297 entity, CallbackInfoReturnable<Boolean> result) {
        if (dev.killerranking.client.ClientShoulderStab.outlines(entity)||dev.killerranking.client.ClientKnifePursuit.outlines(entity)||dev.killerranking.client.ClientMadnessLeap.outlines(entity)||dev.killerranking.client.ClientRook.outlines(entity)||TraitVisuals.glows(entity)) result.setReturnValue(true);
    }
}
