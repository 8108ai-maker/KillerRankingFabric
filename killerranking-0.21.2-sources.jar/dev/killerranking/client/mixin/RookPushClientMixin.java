package dev.killerranking.client.mixin;

import dev.killerranking.client.RookVfx;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
abstract class RookPushClientMixin {
    @Inject(method="push(DDD)V",at=@At("HEAD"),cancellable=true)
    private void killer$noClientPush(double x,double y,double z,CallbackInfo ci) {
        if(RookVfx.immobilized((class_1297)(Object)this)||dev.killerranking.client.ShoulderStabVfx.casting(((class_1297)(Object)this).method_5667()))ci.cancel();
    }
}
