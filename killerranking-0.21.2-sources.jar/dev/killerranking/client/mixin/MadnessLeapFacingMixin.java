package dev.killerranking.client.mixin;

import dev.killerranking.client.MadnessLeapVfx;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Aim can move freely; only the visible body faces its committed landing point. */
@Mixin(class_922.class)
abstract class MadnessLeapFacingMixin {
    @ModifyVariable(method="setupRotations",at=@At("HEAD"),argsOnly=true,ordinal=1)
    private float madnessLeap$facing(float yaw,class_1309 entity,class_4587 pose,float age,float bodyYaw,float partialTick,float scale) {
        return FirstPersonMode.isFirstPersonPass()?yaw:dev.killerranking.client.HeavyPunchVfx.facing(entity,MadnessLeapVfx.yaw(entity.method_5667(),yaw));
    }
}
