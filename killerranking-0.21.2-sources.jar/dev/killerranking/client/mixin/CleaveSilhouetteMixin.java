package dev.killerranking.client.mixin;
import dev.killerranking.client.*;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
@Mixin(class_922.class)
abstract class CleaveSilhouetteMixin {
    @ModifyVariable(method="render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At("HEAD"),argsOnly=true)
    private class_4597 cleave$shadow(class_4597 buffers,class_1309 e,float yaw,float delta,class_4587 stack,class_4597 original,int light){
        return e instanceof class_742 p&&CleaveVfx.full(p.method_5667())?new CleaveSilhouetteBuffers(buffers):buffers;
    }
}
