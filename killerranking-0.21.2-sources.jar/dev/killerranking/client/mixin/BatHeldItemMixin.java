package dev.killerranking.client.mixin;

import dev.killerranking.client.NightBatTrail;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_759;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
abstract class BatHeldItemMixin {
    @Inject(method="renderItem",at=@At("HEAD"),cancellable=true)
    private void begin(class_1309 entity,class_1799 item,class_811 display,boolean left,class_4587 pose,class_4597 buffers,int light,CallbackInfo ci) {
        if (entity instanceof net.minecraft.class_742 player
            && item.method_31574(dev.killerranking.KillerRankingMod.NEUNGSA_KATANA)
            && (display == class_811.field_4321 || display == class_811.field_4322)
            && (left != (player.method_6068() == net.minecraft.class_1306.field_6182)
                || !player.method_6047().method_31574(dev.killerranking.KillerRankingMod.NEUNGSA_KATANA))) {
            ci.cancel();return;
        }
        if(dev.killerranking.client.KnifePursuitVfx.hideItem(entity,item,display,left)){ci.cancel();return;}
        NightBatTrail.begin(entity,item,display,left);
    }
    @Inject(method="renderItem",at=@At("RETURN"))
    private void end(CallbackInfo ci) { NightBatTrail.end(); }
}
