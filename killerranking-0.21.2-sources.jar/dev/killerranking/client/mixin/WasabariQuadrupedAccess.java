package dev.killerranking.client.mixin;
import net.minecraft.class_597;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Use an actual hind leg of native four-legged models, including their own sizes and pivots. */
@Mixin(class_597.class)
public interface WasabariQuadrupedAccess {
    @Accessor("rightHindLeg") class_630 wasabari$rightHindLeg();
    @Accessor("leftHindLeg") class_630 wasabari$leftHindLeg();
}
