package dev.killerranking.client.mixin;

import dev.killerranking.client.RookVfx;
import dev.killerranking.combat.RookMountPose;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
public abstract class RookProneMixin {
    @Inject(method="setupRotations",at=@At("HEAD"),cancellable=true)
    private void killer$groundedMount(class_1309 victim,class_4587 pose,float age,float bodyYaw,float partialTick,float scale,CallbackInfo ci) {
        var owner=RookVfx.mountingOwner(victim.method_5667());
        boolean wasabari=false;if(owner==null){owner=dev.killerranking.client.WasabariVfx.captor(victim.method_5667());wasabari=owner!=null;}if(owner==null)return;
        float progress=wasabari?dev.killerranking.client.WasabariVfx.proneProgress(victim.method_5667(),partialTick):1;
        float impact=RookVfx.mountImpact(victim.method_5667(),partialTick);
        pose.method_22904(.035*impact,.02*impact,0);
        var direction=victim.method_19538().method_1020(owner.method_19538());
        float forwardYaw=(float)Math.toDegrees(Math.atan2(-direction.field_1352,direction.field_1350));
        if(RookMountPose.inverted(victim)) {
            pose.method_22907(class_7833.field_40716.rotationDegrees(180-forwardYaw));
            pose.method_22904(0,victim.method_17682()*.98*progress,0);
            pose.method_22907(class_7833.field_40718.rotationDegrees(180*progress));
        } else {
            float yaw=forwardYaw+180;
            pose.method_22907(class_7833.field_40716.rotationDegrees(180-yaw));
            pose.method_22904(0,(.18+victim.method_17681()*.15)*progress,-victim.method_17682()*.52*progress);
            pose.method_22907(class_7833.field_40714.rotationDegrees(90*progress));
        }
        ci.cancel();
    }
}
