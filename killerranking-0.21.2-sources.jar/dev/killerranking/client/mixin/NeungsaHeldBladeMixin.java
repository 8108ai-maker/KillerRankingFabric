package dev.killerranking.client.mixin;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.client.NeungsaHeldBlade;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3881;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_742;
import net.minecraft.class_811;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_989.class)
abstract class NeungsaHeldBladeMixin<T extends class_1309, M extends class_583<T> & class_3881> extends class_3887<T, M> {
    protected NeungsaHeldBladeMixin(class_3883<T, M> parent) { super(parent); }

    @Inject(method="renderArmWithItem", at=@At("HEAD"), cancellable=true)
    private void kr$attach(T entity, class_1799 stack, class_811 display, class_1306 arm,
                          class_4587 pose, class_4597 buffers, int light, CallbackInfo ci) {
        if (!(entity instanceof class_742 player) || !stack.method_31574(KillerRankingMod.NEUNGSA_KATANA)) return;
        // Offhand/inventory swords stay assembled in their body-mounted sheath.
        // Attaching the main-hand wrist channels to the offhand exposed a separate full blade.
        if (arm == player.method_6068() && player.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA) && !NeungsaHeldBlade.hidden(player))
            NeungsaHeldBlade.render(method_17165(), player, stack, arm, pose, buffers, light);
        ci.cancel();
    }
}
