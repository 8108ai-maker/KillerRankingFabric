package dev.killerranking.client.mixin;
import dev.killerranking.client.RookLegRenderer;
import java.util.List;
import java.util.Map;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_630.class)
abstract class RookLegRenderMixin {
    @Shadow @Final private List<class_630.class_628> cubes;
    @Shadow @Final private Map<String,class_630> children;
    @Inject(method="render(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;III)V",at=@At("HEAD"),cancellable=true)
    private void killerranking$kneelingLeg(class_4587 pose,class_4588 vertices,int light,int overlay,int color,CallbackInfo ci) {
        if(RookLegRenderer.render((class_630)(Object)this,cubes,children,pose,vertices,light,overlay,color)) ci.cancel();
    }
}
