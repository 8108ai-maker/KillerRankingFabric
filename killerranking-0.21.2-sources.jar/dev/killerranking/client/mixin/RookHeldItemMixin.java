package dev.killerranking.client.mixin;
import dev.killerranking.client.RookVfx;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_989.class)
abstract class RookHeldItemMixin {
    @Inject(method="renderArmWithItem",at=@At("HEAD"),cancellable=true)
    private void killerranking$grabHands(class_1309 entity,class_1799 item,class_811 context,class_1306 arm,class_4587 pose,class_4597 source,int light,CallbackInfo ci){if(dev.killerranking.client.ShoulderStabVfx.casting(entity.method_5667())||dev.killerranking.client.WasabariVfx.active(entity.method_5667())){ci.cancel();return;}if(RookVfx.active(entity.method_5667())&&!item.method_31574(dev.killerranking.KillerRankingMod.ROOK_KNUCKLE_GLOVES))ci.cancel();}
}
