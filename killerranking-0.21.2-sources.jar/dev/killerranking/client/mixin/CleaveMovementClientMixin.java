package dev.killerranking.client.mixin;
import dev.killerranking.client.CleaveVfx;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_1309.class)
abstract class CleaveMovementClientMixin {
    @Inject(method="travel",at=@At("HEAD"),cancellable=true)
    private void cleave$casting(class_243 movement,CallbackInfo ci){var e=(class_1309)(Object)this;if(dev.killerranking.client.ShoulderStabVfx.casting(e.method_5667())||dev.killerranking.client.KnifePursuitVfx.casting(e.method_5667())||CleaveVfx.slashing(e.method_5667())||dev.killerranking.client.MadnessLeapVfx.casting(e.method_5667())){e.method_18799(class_243.field_1353);ci.cancel();}}
}
