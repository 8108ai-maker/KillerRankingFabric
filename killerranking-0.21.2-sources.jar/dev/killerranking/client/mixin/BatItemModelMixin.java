package dev.killerranking.client.mixin;

import dev.killerranking.client.NightBatTrail;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_918.class)
abstract class BatItemModelMixin {
    @Inject(method="renderModelLists",at=@At("HEAD"))
    private void sample(class_1087 model,class_1799 item,int light,int overlay,class_4587 pose,class_4588 vertices,CallbackInfo ci) {
        NightBatTrail.sample(item,pose);
    }
}
