package dev.killerranking.client.mixin;
import dev.killerranking.client.HeavyPunchPose;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Apply the held wrist after each concrete humanoid's complete animation. */
@Mixin(class_922.class)
abstract class HeavyPunchCaptiveMixin {
    @Shadow protected class_583<?> model;
    @Inject(method="render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/model/EntityModel;setupAnim(Lnet/minecraft/world/entity/Entity;FFFFF)V",shift=At.Shift.AFTER))
    private void killerranking$heldWrist(class_1309 e,float yaw,float delta,class_4587 stack,class_4597 buffer,int light,CallbackInfo ci){
        if(model instanceof class_572<?> human)HeavyPunchPose.apply(e,human,stack,delta);
        dev.killerranking.client.WasabariPose.apply(e,model,stack,delta);
        dev.killerranking.client.ShoulderStabPose.apply(e,model,stack,delta);
    }
}
