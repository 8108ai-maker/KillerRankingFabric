package dev.killerranking.client.mixin;
import dev.killerranking.client.RookMountScene;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_1007.class)
abstract class RookMountPlayerMixin {
    @Inject(method="render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At("HEAD"),cancellable=true)
    private void rook$hideBodyModel(class_742 player,float yaw,float delta,class_4587 stack,class_4597 buffer,int light,CallbackInfo ci) {
        if(RookMountScene.hideOriginal(player))ci.cancel();
    }
}
