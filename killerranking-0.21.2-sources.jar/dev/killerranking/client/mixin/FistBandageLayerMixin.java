package dev.killerranking.client.mixin;

import dev.killerranking.client.RushArmRenderer;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
abstract class FistBandageLayerMixin {
    @Inject(method="render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At("HEAD"))
    private void killerranking$beginWraps(class_1309 entity,float yaw,float delta,class_4587 stack,class_4597 buffers,int light,CallbackInfo ci) {
        RushArmRenderer.beginBandages(entity);
    }
    @Inject(method="render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At("TAIL"))
    private void killerranking$finishWraps(class_1309 entity,float yaw,float delta,class_4587 stack,class_4597 buffers,int light,CallbackInfo ci) {
        RushArmRenderer.finishBandages(entity,buffers);
    }
}
