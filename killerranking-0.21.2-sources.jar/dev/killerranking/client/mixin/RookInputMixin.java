package dev.killerranking.client.mixin;
import dev.killerranking.client.ClientRook;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
abstract class RookInputMixin extends class_744 {
    @Inject(method="tick",at=@At("TAIL"))
    private void killerranking$grabKeys(boolean slow,float multiplier,CallbackInfo ci){
        if(ClientRook.locked()||dev.killerranking.client.ClientShoulderStab.phase()>=dev.killerranking.combat.ShoulderStabRules.CAST){field_3907=0;field_3905=0;field_3904=false;field_3903=false;field_3910=false;field_3909=false;field_3908=false;field_3906=false;}
    }
}
