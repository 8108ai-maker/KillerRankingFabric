package dev.killerranking.client.mixin;

import dev.killerranking.client.RookVfx;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
abstract class RookMovementClientMixin {
    @Inject(method="travel",at=@At("HEAD"),cancellable=true)
    private void killer$fixedClient(class_243 input,CallbackInfo ci) {
        var entity=(class_1309)(Object)this;
        if(RookVfx.immobilized(entity)){entity.method_18799(class_243.field_1353);ci.cancel();}
    }
    @Inject(method="knockback",at=@At("HEAD"),cancellable=true)
    private void killer$noRecoil(double force,double x,double z,CallbackInfo ci) {
        if(RookVfx.immobilized((class_1309)(Object)this))ci.cancel();
    }
    @Inject(method="isPushable",at=@At("HEAD"),cancellable=true)
    private void killer$noCollision(CallbackInfoReturnable<Boolean> cir) {
        if(RookVfx.immobilized((class_1309)(Object)this))cir.setReturnValue(false);
    }
    @Inject(method="push(Lnet/minecraft/world/entity/Entity;)V",at=@At("HEAD"),cancellable=true)
    private void killer$noPairPush(class_1297 other,CallbackInfo ci) {
        if(RookVfx.immobilized((class_1309)(Object)this)||RookVfx.immobilized(other))ci.cancel();
    }
}
