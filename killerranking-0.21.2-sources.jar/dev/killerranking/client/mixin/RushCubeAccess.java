package dev.killerranking.client.mixin;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_630.class_628.class)
public interface RushCubeAccess {
    @Accessor("polygons") class_630.class_593[] killerranking$rushFaces();
}
