package dev.killerranking.client.mixin;

import dev.killerranking.client.CombatCameraFeedback;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(class_757.class)
abstract class CombatCameraRendererMixin {
    @Inject(method="getFov",at=@At("RETURN"),cancellable=true)
    private void combatCamera$focus(class_4184 camera,float delta,boolean useOptions,CallbackInfoReturnable<Double> ci){
        // Both world and hand projections receive the same relative focus.
        ci.setReturnValue(CombatCameraFeedback.fov(ci.getReturnValueD(),delta));
    }
    @Inject(method="bobHurt",at=@At("RETURN"))
    private void combatCamera$shake(class_4587 stack,float delta,CallbackInfo ci){CombatCameraFeedback.shake(stack,delta);}
}
