package dev.killerranking.client.mixin;
import dev.killerranking.client.RookVfx;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_922.class)
abstract class RookCaptiveModelMixin {
    @Shadow protected class_583<?> model;
    @Inject(method="render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/model/EntityModel;setupAnim(Lnet/minecraft/world/entity/Entity;FFFFF)V",shift=At.Shift.AFTER))
    private void rook$proneArms(class_1309 entity,float yaw,float delta,class_4587 stack,class_4597 buffer,int light,CallbackInfo ci) {
        if(entity instanceof class_742||RookVfx.mountingOwner(entity.method_5667())==null)return;
        if(!(model instanceof class_572<?> human))return;
        human.field_3401.field_3654=human.field_27433.field_3654=0;
        human.field_3401.field_3675=human.field_27433.field_3675=0;
        human.field_3401.field_3674=.06f;human.field_27433.field_3674=-.06f;
    }
}
