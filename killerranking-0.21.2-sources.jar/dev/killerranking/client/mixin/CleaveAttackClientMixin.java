package dev.killerranking.client.mixin;
import dev.killerranking.client.CleaveVfx;
import dev.killerranking.client.ClientSkillCombat;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.*;
// Earlier injector order places these guards before Better Combat's default-order callbacks.
@Mixin(value=class_310.class,priority=1200)
abstract class CleaveAttackClientMixin {
    private static boolean casting(){var p=class_310.method_1551().field_1724;return p!=null&&(CleaveVfx.active(p.method_5667())||dev.killerranking.client.MadnessLeapVfx.casting(p.method_5667()));}
    @Inject(method="startAttack",at=@At("HEAD"),cancellable=true,order=900)
    private void cleave$attack(CallbackInfoReturnable<Boolean> ci){if(ClientSkillCombat.blocksAttack())ci.setReturnValue(false);}
    @Inject(method="continueAttack",at=@At("HEAD"),cancellable=true,order=900)
    private void cleave$mine(boolean held,CallbackInfo ci){if(ClientSkillCombat.blocksAttack())ci.cancel();}
    @Inject(method="tick",at=@At("HEAD"),order=900)
    private void killerranking$pendingAttack(CallbackInfo ci){
        if(ClientSkillCombat.blocksAttack())ClientSkillCombat.cancelPendingAttack((class_310)(Object)this);
    }
    @Inject(method="startUseItem",at=@At("HEAD"),cancellable=true)
    private void cleave$use(CallbackInfo ci){if(casting())ci.cancel();}
}
