package dev.killerranking.client.mixin;
import dev.killerranking.client.RookMountScene;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_898.class)
abstract class RookMountSceneMixin {
    @Inject(method="render(Lnet/minecraft/world/entity/Entity;DDDFFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",at=@At("HEAD"),cancellable=true)
    private void rook$hideStandingCaster(class_1297 entity,double x,double y,double z,float yaw,float delta,class_4587 stack,class_4597 buffer,int light,CallbackInfo ci) {
        if(entity instanceof class_742 player&&RookMountScene.hideOriginal(player))ci.cancel();
    }
}
