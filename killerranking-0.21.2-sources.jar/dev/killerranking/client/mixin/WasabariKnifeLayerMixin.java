package dev.killerranking.client.mixin;
import dev.killerranking.client.WasabariKnifeLayer;
import net.minecraft.class_1007;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_1007.class)
abstract class WasabariKnifeLayerMixin extends class_922<class_742,class_591<class_742>> {
    protected WasabariKnifeLayerMixin(class_5617.class_5618 context,class_591<class_742> model,float radius){super(context,model,radius);}
    @Inject(method="<init>",at=@At("TAIL")) private void wasabari$knife(class_5617.class_5618 context,boolean slim,CallbackInfo ci){method_4046(new WasabariKnifeLayer((class_1007)(Object)this,context.method_43338()));method_4046(new dev.killerranking.client.ShoulderStabKnifeLayer((class_1007)(Object)this,context.method_43338()));}
}
