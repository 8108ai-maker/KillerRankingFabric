package dev.killerranking.client.mixin;
import dev.killerranking.client.CleaveEyesLayer;
import net.minecraft.class_1007;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import net.minecraft.client.renderer.entity.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_1007.class)
abstract class CleaveEyesMixin extends class_922<class_742,class_591<class_742>> {
    protected CleaveEyesMixin(class_5617.class_5618 context,class_591<class_742> model,float radius){super(context,model,radius);}
    @Inject(method="<init>",at=@At("TAIL"))
    private void cleave$eyes(class_5617.class_5618 context,boolean slim,CallbackInfo ci){method_4046(new CleaveEyesLayer((class_1007)(Object)this));}
}
