package dev.killerranking.client.mixin;

import dev.killerranking.client.RushVfx;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hide held-item geometry during the fist animation without changing equipment or inventory. */
@Mixin(class_989.class)
abstract class RushHeldItemMixin {
    @Inject(method="renderArmWithItem",at=@At("HEAD"),cancellable=true)
    private void killerranking$rushHands(class_1309 entity,class_1799 item,class_811 display,class_1306 arm,
            class_4587 stack,class_4597 buffers,int light,CallbackInfo ci) {
        if(RushVfx.active(entity.method_5667())||dev.killerranking.client.HeavyPunchVfx.active(entity.method_5667())) ci.cancel();
    }
}
