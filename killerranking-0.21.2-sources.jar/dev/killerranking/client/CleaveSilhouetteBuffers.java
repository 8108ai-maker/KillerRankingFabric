package dev.killerranking.client;
import net.minecraft.class_1921;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;

/** Tint the real animated mesh, armour and held item. No detached duplicate body. */
public final class CleaveSilhouetteBuffers implements class_4597 {
    private final class_4597 original;
    public CleaveSilhouetteBuffers(class_4597 original){this.original=original;}
    public static class_4597 unwrap(class_4597 b){return b instanceof CleaveSilhouetteBuffers s?s.original:b;}
    @Override public class_4588 getBuffer(class_1921 type){return new DarkVertex(original.getBuffer(type));}
    private record DarkVertex(class_4588 v) implements class_4588 {
        @Override public class_4588 method_22912(float x,float y,float z){v.method_22912(x,y,z);return this;}
        @Override public class_4588 method_1336(int r,int g,int b,int a){v.method_1336(0,0,0,a);return this;}
        @Override public class_4588 method_22913(float u,float w){v.method_22913(u,w);return this;}
        @Override public class_4588 method_60796(int u,int w){v.method_22922(class_4608.field_21444);return this;}
        @Override public class_4588 method_22921(int u,int w){v.method_22921(u,w);return this;}
        @Override public class_4588 method_22914(float x,float y,float z){v.method_22914(x,y,z);return this;}
    }
}
