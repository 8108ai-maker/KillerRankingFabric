package dev.killerranking.client;
import com.mojang.blaze3d.vertex.*;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.ShoulderStabRules;
import dev.killerranking.network.ShoulderStabVisualPayload;
import dev.killerranking.visual.*;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.firstPerson.*;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.world.entity.*;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.*;

public final class ShoulderStabVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("shoulder_stab_layer");
    private static final class State {
        ShoulderStabVisualPayload value;int age,ttl;boolean animated,arrived;class_243 tip;
        State(ShoulderStabVisualPayload p){update(p);}
        void update(ShoulderStabVisualPayload p){value=p;age=p.age();ttl=25;}
    }
    private static final Map<UUID,State> ACTIVE=new HashMap<>();private static long knives,ribbons,snaps;
    public static void register(){
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{var layer=new ModifierLayer<IAnimation>();stack.addAnimLayer(3550,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);});
        WorldRenderEvents.AFTER_ENTITIES.register(ShoulderStabVfx::render);
    }
    public static void accept(ShoulderStabVisualPayload p){
        if(p.phase()==0){remove(p.player());return;}
        ACTIVE.compute(p.player(),(id,s)->{if(s==null||s.value.phase()!=p.phase()||p.age()<s.age-3)return new State(p);s.update(p);return s;});
    }
    public static boolean active(UUID id){return ACTIVE.containsKey(id);}
    public static boolean casting(UUID id){var s=ACTIVE.get(id);return s!=null&&s.value.phase()>=ShoulderStabRules.CAST;}
    public static boolean counter(UUID id){var s=ACTIVE.get(id);return s!=null&&s.value.phase()==ShoulderStabRules.COUNTER;}
    public static float age(UUID id,float delta){var s=ACTIVE.get(id);return s==null?-1:s.age+delta;}
    public static long renderedKnives(){return knives;}public static long renderedRibbons(){return ribbons;}public static long snappedArrivals(){return snaps;}
    public static class_243 knifeTip(UUID id){var s=ACTIVE.get(id);return s==null?null:s.tip;}
    public static class_243 airCatch(UUID id){var s=ACTIVE.get(id);return s==null?null:s.value.airCatch();}
    public static void recordKnife(UUID id,class_4587 stack){var s=ACTIVE.get(id);if(s==null)return;var v=stack.method_23760().method_23761().transformPosition(new Vector3f(0,(SalmosaKnifeGeometry.TIP-8)/16,0));s.tip=class_310.method_1551().field_1773.method_19418().method_19326().method_1031(v.x,v.y,v.z);knives++;}
    public static class_243 wound(UUID id,float delta){var s=ACTIVE.get(id);if(s==null)return null;var c=class_310.method_1551();var p=c.field_1687==null?null:c.field_1687.method_18470(id);var target=target(s);
        return target==null||p==null?s.value.wound():ShoulderStabRules.shoulder(target.method_30950(delta),target.method_17681(),target.method_17682(),s.value.yaw(),p.method_6068()==class_1306.field_6182);}
    private static class_1309 target(State s){var c=class_310.method_1551();if(c.field_1687==null)return null;for(var e:c.field_1687.method_18112())if(e.method_5667().equals(s.value.target())&&e instanceof class_1309 living)return living;return null;}
    private static class_243 nativePoint(class_4587 stack,class_243 world){var at=world.method_1020(class_310.method_1551().field_1773.method_19418().method_19326());var local=new Matrix4f(stack.method_23760().method_23761()).invert().transformPosition(new Vector3f((float)at.field_1352,(float)at.field_1351,(float)at.field_1350));return new class_243(local.x*16,local.y*16,local.z*16);}
    public static class_243 knifeDirection(class_1309 e,class_4587 stack){var s=ACTIVE.get(e.method_5667());var at=wound(e.method_5667(),0);if(s==null||at==null)return new class_243(0,.96,-.28).method_1029();return nativePoint(stack,at.method_1019(ShoulderStabRules.incoming(s.value.yaw()))).method_1020(nativePoint(stack,at)).method_1029();}
    public static WasabariMotion.Pose pose(class_1309 e,class_4587 stack,float delta){
        var state=ACTIVE.get(e.method_5667());float age=age(e.method_5667(),delta);boolean left=e.method_6068()==class_1306.field_6182;var at=wound(e.method_5667(),delta);
        // Interpolated animation time may reach the blink beat before its server packet.
        // Keep the raised hand with the caster until the confirmed arrival is applied.
        boolean firstPerson=e==class_310.method_1551().field_1724&&FirstPersonMode.isFirstPersonPass();
        if(state!=null&&state.value.phase()==ShoulderStabRules.COUNTER&&at!=null)return ShoulderStabMotion.counterContact(age,left,nativePoint(stack,at),knifeDirection(e,stack),nativePoint(stack,state.value.airCatch()),HeavyPunchPose.center(e),firstPerson);
        return state==null||!state.arrived||age<ShoulderStabRules.BLINK||at==null?ShoulderStabMotion.pose(age,left):ShoulderStabMotion.contact(age,left,nativePoint(stack,at),knifeDirection(e,stack),HeavyPunchPose.center(e),firstPerson);
    }
    public static void tick(class_310 c){if(c.field_1687==null||c.method_1493())return;for(var id:new ArrayList<>(ACTIVE.keySet())){
        var s=ACTIVE.get(id);var p=c.field_1687.method_18470(id);
        boolean counter=s.value.phase()==ShoulderStabRules.COUNTER;
        if(--s.ttl<=0||p==null||!p.method_5805()||p.method_7325()||s.value.phase()>=ShoulderStabRules.CAST&&s.age>=(counter?ShoulderStabRules.COUNTER_DURATION:ShoulderStabRules.DURATION)){remove(id);continue;}
        if(s.value.phase()>=ShoulderStabRules.CAST){
            if(counter){var at=ShoulderStabRules.counterPosition(s.value.origin(),s.value.destination(),s.value.airCatch(),s.age);p.method_5759(at.field_1352,at.field_1351,at.field_1350,p.method_36454(),p.method_36455(),1);p.method_33574(at);s.arrived=s.age>=4;}
            else if(s.value.age()>=ShoulderStabRules.BLINK&&!s.arrived){var at=s.value.destination();p.method_5759(at.field_1352,at.field_1351,at.field_1350,p.method_36454(),p.method_36455(),1);p.method_33574(at);p.field_6014=p.field_6038=at.field_1352;p.field_6036=p.field_5971=at.field_1351;p.field_5969=p.field_5989=at.field_1350;s.arrived=true;snaps++;}
            p.field_6283=p.field_6220=s.value.yaw();if(!s.animated&&p instanceof class_742 skin)s.animated=animate(skin,s);
        }
        s.age++;
    }}
    @SuppressWarnings("unchecked") private static boolean animate(class_742 p,State s){var layer=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(!(layer instanceof ModifierLayer<?> mods))return false;((ModifierLayer<IAnimation>)mods).setAnimation(new Motion(p,s));return true;}
    private static final class Motion implements IAnimation {
        final class_742 player;final State state;Motion(class_742 p,State s){player=p;state=s;}
        public boolean isActive(){return ACTIVE.get(player.method_5667())==state&&state.value.phase()>=ShoulderStabRules.CAST;}
        public void setupAnim(float delta){ }
        public FirstPersonMode getFirstPersonMode(float delta){return FirstPersonMode.THIRD_PERSON_MODEL;}
        public FirstPersonConfiguration getFirstPersonConfiguration(float delta){return new FirstPersonConfiguration(true,true,false,false);}
        public Vec3f get3DTransform(String name,TransformType type,float delta,Vec3f baseline){
            var pose=state.value.phase()==ShoulderStabRules.COUNTER?ShoulderStabMotion.counterPose(state.age+delta,player.method_6068()==class_1306.field_6182):ShoulderStabMotion.pose(state.age+delta,player.method_6068()==class_1306.field_6182);
            var limb=switch(name){case "torso"->pose.torso();case "head"->pose.head();case "rightArm"->pose.rightArm();case "leftArm"->pose.leftArm();case "rightLeg"->pose.rightLeg();case "leftLeg"->pose.leftLeg();default->null;};
            if(limb==null)return name.equals("body")&&type!=TransformType.SCALE?Vec3f.ZERO:baseline;
            if(type==TransformType.SCALE)return new Vec3f(1,1,1);if(type==TransformType.BEND)return Vec3f.ZERO;
            var value=type==TransformType.POSITION?limb.pivot():limb.rotation();return new Vec3f((float)value.field_1352,(float)value.field_1351,(float)value.field_1350);
        }
    }
    private static void remove(UUID id){ACTIVE.remove(id);var c=class_310.method_1551();if(c.field_1687!=null&&c.field_1687.method_18470(id) instanceof class_742 p){var l=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(l instanceof ModifierLayer<?> layer)layer.setAnimation(null);}}
    public static void clear(){for(var id:new ArrayList<>(ACTIVE.keySet()))remove(id);}
    private static void render(WorldRenderContext context){
        if(context.matrixStack()==null||context.consumers()==null)return;float delta=context.tickCounter().method_60637(false);
        for(var entry:ACTIVE.entrySet()){var s=entry.getValue();if(s.value.phase()<ShoulderStabRules.CAST)continue;float age=s.age+delta;var direction=ShoulderStabRules.incoming(s.value.yaw());
            boolean counter=s.value.phase()==ShoulderStabRules.COUNTER;
            if(counter&&age<ShoulderStabRules.COUNTER_CATCH){var p=class_310.method_1551().field_1687.method_18470(entry.getKey());if(p!=null)KnifePursuitVfx.airKnife(context,p,ShoulderStabRules.counterKnife(s.value.airStart(),s.value.airCatch(),age),s.value.yaw());}
            if(!counter&&s.arrived&&age>=ShoulderStabRules.BLINK&&age<ShoulderStabRules.BLINK+3){ribbon(context,s.value.origin().method_1031(0,.9,0),class_243.method_1030(0,s.value.yaw()),.9f,.3f,age-ShoulderStabRules.BLINK,.65f);ribbon(context,s.value.destination().method_1031(0,.9,0),direction,.8f,.3f,age-ShoulderStabRules.BLINK,.8f);}
            int impact=counter?ShoulderStabRules.COUNTER_IMPACT:ShoulderStabRules.IMPACT;
            if(s.arrived&&age>=impact-1&&age<impact+3){var at=wound(entry.getKey(),delta);if(at!=null){ribbon(context,at,direction,counter?1.25f:.65f,counter?.2f:.16f,age-impact+1,1);ribbons++;}}
        }
    }
    private static void ribbon(WorldRenderContext context,class_243 at,class_243 direction,float length,float width,float time,float alpha){
        var pose=context.matrixStack();var camera=context.camera().method_19326();int frame=Math.clamp((int)time,0,3);
        pose.method_22903();pose.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);pose.method_22907(new Quaternionf().rotationTo(new Vector3f(1,0,0),new Vector3f((float)direction.field_1352,(float)direction.field_1351,(float)direction.field_1350)));
        var v=context.consumers().getBuffer(class_1921.method_23580(KillerRankingMod.id("textures/effect/wasabari_stab.png")));float lo=frame/4f,hi=(frame+1)/4f;
        vertex(pose,v,-length,-width,0,hi,alpha);vertex(pose,v,0,-width,1,hi,alpha);vertex(pose,v,0,width,1,lo,alpha);vertex(pose,v,-length,width,0,lo,alpha);pose.method_22909();
    }
    private static void vertex(class_4587 p,class_4588 v,float x,float y,float u,float tex,float alpha){v.method_22918(p.method_23760().method_23761(),x,y,0).method_22915(.88f,.68f,1,alpha).method_22913(u,tex).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(p.method_23760(),0,0,1);}
    private ShoulderStabVfx(){ }
}
