package dev.killerranking.client;

import dev.killerranking.combat.BishopBarrageMotion;
import dev.killerranking.network.NeungsaCutEffectPayload;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;

/** The same animated ribbons as Brothers' Help, fitted to the victim rather than the whole damage zone. */
public final class NeungsaHitCutVfx {
    private static final List<Cut> ACTIVE=new ArrayList<>();
    private static int segments;
    private static final class Cut {
        final class_1309 target;
        final BishopBarrageMotion.Stroke[] strokes=new BishopBarrageMotion.Stroke[2];
        int age;
        Cut(class_1309 target){
            this.target=target;long seed=ThreadLocalRandom.current().nextLong();
            for(int i=0;i<strokes.length;i++){
                var source=BishopBarrageMotion.stroke(seed,0,i);
                // Center each moving ribbon on the struck torso; retain Bishop's shape and staggered sweep.
                strokes[i]=new BishopBarrageMotion.Stroke(0,0,0,source.cosine(),source.sine(),source.halfLength(),source.bend(),source.depthTilt()*.15f,source.depthBend()*.15f);
            }
        }
    }
    public static void register(){
        WorldRenderEvents.AFTER_ENTITIES.register(NeungsaHitCutVfx::render);
        ClientTickEvents.END_CLIENT_TICK.register(c->{
            if(c.field_1687==null){clear();return;}if(c.method_1493())return;
            ACTIVE.removeIf(cut->++cut.age>=8||cut.target.method_31481()||cut.target.method_37908()!=c.field_1687);
        });
    }
    public static void emit(NeungsaCutEffectPayload p){
        var c=class_310.method_1551();if(c.field_1687==null)return;
        var e=c.field_1687.method_8469(p.entity());if(e instanceof class_1309 target&&target.method_5667().equals(p.uuid()))ACTIVE.add(new Cut(target));
    }
    public static boolean active(UUID target){return ACTIVE.stream().anyMatch(c->c.target.method_5667().equals(target));}
    public static int segments(){return segments;}
    public static void clear(){ACTIVE.clear();segments=0;}
    private static void render(WorldRenderContext context){
        segments=0;if(context.matrixStack()==null||context.consumers()==null)return;
        var camera=context.camera().method_19326();float partial=context.tickCounter().method_60637(false);
        var vertices=context.consumers().getBuffer(WeaponTrailRenderType.LAYER);
        for(var cut:ACTIVE){
            var target=cut.target;if(target.method_31481()||target.method_5707(camera)>4096)continue;
            var center=new class_243(target.field_6038+(target.method_23317()-target.field_6038)*partial,target.field_5971+(target.method_23318()-target.field_5971)*partial+target.method_17682()*.56,target.field_5989+(target.method_23321()-target.field_5989)*partial);
            var at=center.method_1019(camera.method_1020(center).method_1029().method_1021(target.method_17681()*.65+.08));
            var stack=context.matrixStack();stack.method_22903();stack.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);
            stack.method_22907(context.camera().method_23767());
            // Bishop's bright inner ribbon uses negative local depth. With a camera-facing plane,
            // flip that axis so the inner ribbon is nearer and blends over the dark outer ribbon.
            float size=Math.clamp(target.method_17682()*.42f,.45f,1.6f);stack.method_22905(size,size,-size);
            for(int i=0;i<cut.strokes.length;i++)segments+=BishopBarrageVfx.renderStroke(stack,vertices,cut.strokes[i],cut.age+partial-i*.8f);
            stack.method_22909();
        }
    }
    private NeungsaHitCutVfx(){ }
}
