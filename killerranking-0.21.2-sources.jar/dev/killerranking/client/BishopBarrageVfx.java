package dev.killerranking.client;
import dev.killerranking.combat.BishopBarrageRules;
import dev.killerranking.combat.BishopBarrageMotion;
import dev.killerranking.network.BishopBarrageVisualPayload;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.class_1059;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3999;
import net.minecraft.class_4003;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_7833;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Fast traveling cuts fill the forward space only after the four brief helpers vanish. */
public final class BishopBarrageVfx {
    private static final Map<UUID,State> ACTIVE=new HashMap<>();
    private static int renderedSegments;
    private static final class State {
        final class_243 origin;final float yaw;final long seed=ThreadLocalRandom.current().nextLong();int age,ttl=25;boolean departed;
        State(BishopBarrageVisualPayload p){origin=new class_243(p.x(),p.y(),p.z());yaw=p.yaw();age=BishopBarrageRules.DURATION-p.remaining();departed=age>=BishopBarrageRules.ECHO_TICKS;if(!departed)flash(this);}
    }
    private static final class Blink extends class_4003 {
        Blink(class_638 level,class_243 at){
            super(level,at.field_1352,at.field_1351,at.field_1350);field_3847=4;field_3862=false;field_17867=.8f;method_3084(1,.92f,1);
            var atlas=(class_1059)class_310.method_1551().method_1531().method_4619(class_1059.field_17898);
            method_18141(atlas.method_4608(class_2960.method_60656("flash")));
        }
        @Override public float method_18132(float partial){return field_17867*(float)Math.sin(Math.PI*Math.clamp((field_3866+partial)/field_3847,0,1));}
        @Override public int method_3068(float partial){return 0xF000F0;}
        @Override public class_3999 method_18122(){return class_3999.field_17829;}
    }
    public static void register(){WorldRenderEvents.AFTER_ENTITIES.register(BishopBarrageVfx::render);}
    public static void accept(BishopBarrageVisualPayload p){
        if(p.remaining()==0){ACTIVE.remove(p.player());return;}
        ACTIVE.compute(p.player(),(id,old)->{
            if(old==null||old.origin.method_1025(new class_243(p.x(),p.y(),p.z()))>.001||old.age>BishopBarrageRules.DURATION-p.remaining()+5)return new State(p);
            old.age=BishopBarrageRules.DURATION-p.remaining();old.ttl=25;return old;
        });
    }
    public static void tick(class_310 c){
        if(c.field_1687==null||c.method_1493())return;
        ACTIVE.values().removeIf(s->{
            ++s.age;
            if(!s.departed&&s.age>=BishopBarrageRules.ECHO_TICKS){s.departed=true;flash(s);}
            return s.age>=BishopBarrageRules.DURATION||--s.ttl<=0;
        });
    }
    private static void flash(State s){
        var c=class_310.method_1551();if(c.field_1687==null)return;
        double angle=Math.toRadians(s.yaw);var forward=new class_243(-Math.sin(angle),0,Math.cos(angle));var side=new class_243(forward.field_1350,0,-forward.field_1352);
        for(int helper=0;helper<4;helper++){
            var at=s.origin.method_1019(side.method_1021(helper<2?1.4:-1.4)).method_1019(forward.method_1021(helper%2==0?.65:-.65)).method_1031(0,1.25,0);
            c.field_1713.method_3058(new Blink(c.field_1687,at));
        }
    }
    public static boolean active(UUID player){return ACTIVE.containsKey(player);}
    public static void clear(){ACTIVE.clear();renderedSegments=0;}
    public static int segments(){return renderedSegments;}
    private static void render(WorldRenderContext context){
        renderedSegments=0;if(context.matrixStack()==null||context.consumers()==null)return;
        var camera=context.camera().method_19326();float partial=context.tickCounter().method_60637(false);int zones=0;
        for(var state:ACTIVE.values()){
            if(state.origin.method_1025(camera)>4096||++zones>8)continue;
            var stack=context.matrixStack();stack.method_22903();stack.method_22904(state.origin.field_1352-camera.field_1352,state.origin.field_1351-camera.field_1351,state.origin.field_1350-camera.field_1350);stack.method_22907(class_7833.field_40716.rotationDegrees(-state.yaw));
            var vertices=context.consumers().getBuffer(WeaponTrailRenderType.LAYER);float age=state.age+partial;
            blink(stack,vertices,age);
            float time=age-BishopBarrageMotion.START;
            if(time<0){stack.method_22909();continue;}
            int latest=(int)(time/BishopBarrageMotion.SPACING);
            for(int pulse=Math.max(0,latest-2);pulse<=latest;pulse++){
                float elapsed=time-pulse*BishopBarrageMotion.SPACING;if(elapsed<0||elapsed>=BishopBarrageMotion.LIFE)continue;
                for(int slash=0;slash<BishopBarrageMotion.STRIKES;slash++){
                    renderedSegments+=renderStroke(stack,vertices,BishopBarrageMotion.stroke(state.seed,pulse,slash),elapsed);
                }
            }
            stack.method_22909();
        }
    }
    /** Shared by victim cuts: the actual Bishop texture frames, moving head/tail, thickness and colors. */
    static int renderStroke(class_4587 stack,class_4588 vertices,BishopBarrageMotion.Stroke stroke,float elapsed){
        if(elapsed<0||elapsed>=BishopBarrageMotion.LIFE)return 0;
        float tail=BishopBarrageMotion.tail(elapsed),head=BishopBarrageMotion.head(elapsed);if(head-tail<.001f)return 0;
        int frame=Math.min(7,(int)(elapsed*8/BishopBarrageMotion.LIFE));float alpha=.95f*Math.min(1,(BishopBarrageMotion.LIFE-elapsed)/2);
        for(int segment=0;segment<12;segment++){
            float u0=segment/12f,u1=(segment+1)/12f;
            var a=stroke.point(tail+(head-tail)*u0);var b=stroke.point(tail+(head-tail)*u1);
            float vx=b.x()-a.x(),vy=b.y()-a.y(),length=(float)Math.sqrt(vx*vx+vy*vy);
            float nx=-vy/length,ny=vx/length;
            for(int edge=0;edge<2;edge++){
                float width=edge==0?.115f:.085f;
                float w0=width*(float)Math.sin(Math.PI*u0),w1=width*(float)Math.sin(Math.PI*u1);
                float depth=edge==0?0:-.003f;
                quad(stack,vertices,a.x()-nx*w0,a.y()-ny*w0,a.z()+depth,a.x()+nx*w0,a.y()+ny*w0,a.z()+depth,b.x()+nx*w1,b.y()+ny*w1,b.z()+depth,b.x()-nx*w1,b.y()-ny*w1,b.z()+depth,u0,u1,frame,alpha,edge==0?.045f:1,edge==0?.012f:.94f,edge==0?.03f:.97f);
            }
        }
        return 12;
    }
    private static void blink(class_4587 stack,class_4588 vertices,float age){
        float phase=age<BishopBarrageRules.ECHO_TICKS?age:age-BishopBarrageRules.ECHO_TICKS;
        float life=age<BishopBarrageRules.ECHO_TICKS?BishopBarrageRules.ECHO_TICKS:3;
        if(phase>=life)return;
        float alpha=.95f*(1-phase/life),width=.22f*(1-phase/life);
        for(int helper=0;helper<4;helper++){
            float x=helper<2?1.4f:-1.4f,z=(helper%2==0?.65f:-.65f)+.4f;
            // A brief vertical glint and a forward smear frame the appearance/disappearance, not a long smoke cloud.
            quad(stack,vertices,x-width,.05f,z,x+width,.05f,z,x+width,2.65f,z,x-width,2.65f,z,0,1,2,alpha,1,.9f,1);
            quad(stack,vertices,x-.8f,2.08f-width,z,x-.8f,2.08f+width,z,x+.8f,2.08f+width,z,x+.8f,2.08f-width,z,0,1,2,alpha,1,.9f,1);
            if(age>=BishopBarrageRules.ECHO_TICKS){
                float end=z+1.4f+phase*.7f;
                quad(stack,vertices,x,1.05f,z,x,1.28f,z,x,1.28f,end,x,1.05f,end,0,1,2,alpha,1,.9f,1);
            }
        }
    }
    private static void quad(class_4587 stack,class_4588 vertices,float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz,float dx,float dy,float dz,float u0,float u1,int frame,float alpha,float red,float green,float blue){
        float low=(frame+.015625f)/8,high=(frame+.984375f)/8;
        vertex(stack,vertices,ax,ay,az,u0,high,alpha,red,green,blue);vertex(stack,vertices,bx,by,bz,u0,low,alpha,red,green,blue);
        vertex(stack,vertices,cx,cy,cz,u1,low,alpha,red,green,blue);vertex(stack,vertices,dx,dy,dz,u1,high,alpha,red,green,blue);
    }
    private static void vertex(class_4587 s,class_4588 v,float x,float y,float z,float u,float texY,float alpha,float red,float green,float blue){
        v.method_22918(s.method_23760().method_23761(),x,y,z).method_22915(red,green,blue,alpha).method_22913(u,texY).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(s.method_23760(),0,0,1);
    }
    private BishopBarrageVfx() { }
}
