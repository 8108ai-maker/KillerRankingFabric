package dev.killerranking.client;

import net.minecraft.class_1657;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;

/** A rising violet veil, anchored behind the body and rendered with vanilla smoke sprites. */
final class PoisonAuraParticle extends class_4003 {
    private final class_1657 owner;
    private final class_4002 sprites;
    private final boolean dark;
    private final boolean salmosa;
    private final float side, startHeight, phase, size, rear;
    PoisonAuraParticle(class_638 world, class_1657 owner, class_4002 sprites, boolean dark) {
        super(world, owner.method_23317(), owner.method_23318(), owner.method_23321());
        this.owner = owner; this.sprites = sprites; this.dark = dark;
        salmosa = PoisonVfx.salmosa(owner.method_5667());
        field_3862 = false;
        field_3847 = 24 + field_3840.method_43048(12);
        side = (field_3840.method_43057() - .5f) * (salmosa ? 3.2f : 2.8f);
        startHeight = field_3840.method_43057() * 2.8f - .10f;
        phase = field_3840.method_43057() * (float) (Math.PI * 2);
        rear = (salmosa ? 2.25f : .9f) + field_3840.method_43057() * .6f;
        size = dark ? .48f + field_3840.method_43057() * .22f : .55f + field_3840.method_43057() * .27f;
        if (dark) method_3084(.10f, .015f, .19f);
        else if (salmosa) method_3084(.49f + field_3840.method_43057() * .12f, .20f, .78f + field_3840.method_43057() * .12f);
        else method_3084(.36f + field_3840.method_43057() * .12f, .025f, .68f + field_3840.method_43057() * .15f);
        field_3841 = 0;
        place(); field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871;
        method_18142(sprites);
    }
    private void place() {
        float progress = field_3866 / (float) field_3847;
        double yaw = Math.toRadians(owner.field_6283);
        double sweep = side * (1 + progress * .24) + Math.sin(phase + progress * 5) * .13;
        double back = rear + Math.cos(phase + progress * 4) * .10;
        method_3063(owner.method_23317() + Math.cos(yaw) * sweep + Math.sin(yaw) * back,
            owner.method_23318() + startHeight + progress * 1.65,
            owner.method_23321() + Math.sin(yaw) * sweep - Math.cos(yaw) * back);
    }
    @Override public void method_3070() {
        field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871; field_3857 = field_3839;
        if (owner.method_31481() || !owner.method_5805() || owner.method_5767() || owner.method_7325()) { method_3085(); return; }
        if (!PoisonVfx.active(owner.method_5667())) field_3866 = Math.max(field_3866, field_3847 - 4);
        if (++field_3866 >= field_3847) { method_3085(); return; }
        float progress = field_3866 / (float) field_3847;
        field_3841 = Math.min(1, field_3866 / 3f) * Math.min(1, (field_3847 - field_3866) / 7f) * (dark ? .36f : .40f);
        if (salmosa) field_3841 *= .62f;
        field_17867 = size * (1.05f - progress * .45f);
        field_3839 = (float) Math.sin(phase + progress * 3) * .20f;
        place(); method_18142(sprites);
        if ((field_3874 - field_3858) * (field_3874 - field_3858) + (field_3871 - field_3856) * (field_3871 - field_3856) > 16) { field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871; }
    }
    @Override public void method_3074(class_4588 vertices, class_4184 camera, float delta) {
        if (!KillingIntentVfx.hiddenForCamera(owner)) super.method_3074(vertices, camera, delta);
    }
    @Override protected int method_3068(float delta) { return 0xF000F0; }
    @Override public class_3999 method_18122() { return class_3999.field_17829; }
}
