package dev.killerranking.client;

import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import net.minecraft.class_310;
import net.minecraft.class_742;

/** Scopes view poses to the camera player; remote players may render during the same pass. */
public final class FirstPersonWeaponView {
    private static boolean rendering;
    public static void begin(class_742 player) {
        var client=class_310.method_1551();
        rendering=player==client.method_1560()&&client.field_1690.method_31044().method_31034()
            &&FirstPersonMode.isFirstPersonPass();
    }
    public static boolean active() { return rendering; }
    public static void end() { rendering=false; }
    private FirstPersonWeaponView() { }
}
