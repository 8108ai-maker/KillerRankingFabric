package dev.killerranking.client;

import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;

/** Unlit anime speed strokes with ordinary alpha and depth testing. */
final class RushRenderType extends class_1921 {
    static final class_1921 STREAK = method_24049("killerranking_rush_strokes", class_290.field_1580,
        class_293.class_5596.field_27382, 2048, false, true, class_4688.method_23598()
            .method_34578(field_29414)
            .method_34577(new class_4683(class_2960.method_60656("textures/block/white_concrete.png"), false, false))
            .method_23615(field_21370).method_23603(field_21345)
            .method_23616(field_21350).method_23617(false));
    private RushRenderType() {
        super("killerranking_rush_strokes", class_290.field_1580, class_293.class_5596.field_27382,
            2048, false, true, () -> {}, () -> {});
    }
}
