package dev.killerranking.client;

import dev.killerranking.client.mixin.RushCubeAccess;
import dev.killerranking.visual.RookLegShape;
import dev.killerranking.visual.RookMountLayout;
import dev.killerranking.combat.RookMountPose;
import java.util.*;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;
import org.joml.Vector3f;

/** Keep the original cuboid faces and skin UVs on detached leg blocks. */
public final class RookLegRenderer {
    private record Binding(UUID player,boolean left) { }
    private record Point(float x,float y,float z,float u,float v) { }
    private record Face(List<Point> points,Vector3f normal) { }
    private static final Map<class_630,Binding> PARTS=new WeakHashMap<>();
    private static final Map<class_630.class_628,List<Face>> MESH=new WeakHashMap<>();
    private static long rendered;
    public static void bind(class_591<?> model,class_1309 entity) {
        boolean active=entity instanceof class_742&&RookVfx.mounting(entity.method_5667());
        for(var part:List.of(model.field_3392,model.field_3479,model.field_3397,model.field_3482)) {
            if(active) PARTS.put(part,new Binding(entity.method_5667(),part==model.field_3397||part==model.field_3482));
            else PARTS.remove(part);
        }
    }
    public static boolean render(class_630 part,List<class_630.class_628> cubes,Map<String,class_630> children,class_4587 stack,class_4588 v,int light,int overlay,int color) {
        var binding=PARTS.get(part);if(binding==null||!RookVfx.mounting(binding.player())) return false;
        var client=class_310.method_1551();
        if(client.field_1687==null||!(client.field_1687.method_18470(binding.player()) instanceof class_742 owner)) return false;
        var victim=RookVfx.mountVictim(binding.player());if(victim==null)return false;
        if(!part.field_3665)return false;
        double spread=RookMountLayout.spread(victim.method_17681(),owner.method_55693());
        double lift=RookMountLayout.legLift(victim.method_17682(),victim.method_17681(),RookMountPose.inverted(victim),owner.method_55693());
        stack.method_22903();part.method_22703(stack);
        if(!part.field_38456) for(var cube:cubes) for(var face:MESH.computeIfAbsent(cube,RookLegRenderer::faces)) draw(stack,v,face,binding.left(),spread,lift,light,overlay,color);
        for(var child:children.values()) child.method_22699(stack,v,light,overlay,color);
        stack.method_22909();rendered++;return true;
    }
    private static List<Face> faces(class_630.class_628 cube) {
        var faces=new ArrayList<Face>();
        for(var polygon:((RushCubeAccess)(Object)cube).killerranking$rushFaces()) {
            var points=Arrays.stream(polygon.field_3502).map(v->new Point(v.field_3605.x,v.field_3605.y,v.field_3605.z,v.field_3604,v.field_3603)).toList();
            faces.add(new Face(points,new Vector3f(polygon.field_21618)));
        }
        return List.copyOf(faces);
    }
    private static void draw(class_4587 stack,class_4588 v,Face face,boolean left,double spread,double lift,int light,int overlay,int color) {
        var pose=stack.method_23760();
        var normal=RookLegShape.normal(face.normal.x,face.normal.y,face.normal.z,left,spread);
        for(var point:face.points) {
            var p=RookLegShape.deform(point.x,point.y,point.z,left,spread,lift);
            v.method_22918(pose.method_23761(),(float)p.x()/16,(float)p.y()/16,(float)p.z()/16).method_39415(color).method_22913(point.u,point.v)
                .method_22922(overlay).method_60803(light).method_60831(pose,(float)normal.x(),(float)normal.y(),(float)normal.z());
        }
    }
    public static long renderedParts() { return rendered; }
    private RookLegRenderer() { }
}
