package dev.killerranking.client;

import net.minecraft.class_1657;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import net.minecraft.client.particle.*;

/** Rising dark-red mist behind the character contrasts with the downward liquid streams. */
final class MadnessAuraParticle extends class_4003 {
    private final class_1657 owner;
    private final class_4002 sprites;
    private final float side,height,rear,phase,size;
    private final boolean ember;
    MadnessAuraParticle(class_638 world,class_1657 owner,class_4002 sprites,boolean ember) {
        super(world,owner.method_23317(),owner.method_23318(),owner.method_23321());
        this.owner=owner;this.sprites=sprites;this.ember=ember;field_3862=false;
        field_3847=ember?18+field_3840.method_43048(8):28+field_3840.method_43048(12);
        side=(field_3840.method_43057()-.5f)*4.15f;height=field_3840.method_43057()*3.45f-.10f;
        rear=1.20f+field_3840.method_43057()*.25f;phase=field_3840.method_43057()*6.283f;
        size=ember?.055f+field_3840.method_43057()*.035f:.40f+field_3840.method_43057()*.24f;
        if(ember) method_3084(.95f,.24f,.12f);
        else if(field_3840.method_43057()<.28f) method_3084(.10f,.004f,.018f);
        else method_3084(.43f+field_3840.method_43057()*.26f,.01f,.045f);
        field_3841=0;place();field_3858=field_3874;field_3838=field_3854;field_3856=field_3871;method_18142(sprites);
    }
    private void place() {
        float progress=field_3866/(float)field_3847;double yaw=Math.toRadians(owner.field_6283);
        double sweep=side*(1+progress*.16)+Math.sin(phase+progress*4)*.12;
        method_3063(owner.method_23317()+Math.cos(yaw)*sweep+Math.sin(yaw)*rear,
            owner.method_23318()+height+progress*(ember?2:1.75),owner.method_23321()+Math.sin(yaw)*sweep-Math.cos(yaw)*rear);
    }
    @Override public void method_3070() {
        field_3858=field_3874;field_3838=field_3854;field_3856=field_3871;field_3857=field_3839;
        if(owner.method_31481() || !owner.method_5805() || owner.method_5767() || owner.method_7325() || !MadnessVfx.active(owner.method_5667())) { method_3085();return; }
        if(++field_3866>=field_3847) { method_3085();return; }
        float progress=field_3866/(float)field_3847;
        field_3841=Math.min(1,field_3866/4f)*Math.min(1,(field_3847-field_3866)/8f)*(ember?.9f:.44f);
        field_17867=size*(1.05f-progress*.45f);field_3839=(float)Math.sin(phase+progress*3)*.15f;
        place();method_18142(sprites);
        if((field_3874-field_3858)*(field_3874-field_3858)+(field_3871-field_3856)*(field_3871-field_3856)>16) { field_3858=field_3874;field_3838=field_3854;field_3856=field_3871; }
    }
    @Override public void method_3074(class_4588 v,class_4184 camera,float delta) {
        if(MadnessVfx.active(owner.method_5667()) && !KillingIntentVfx.hiddenForCamera(owner)) super.method_3074(v,camera,delta);
    }
    @Override protected int method_3068(float delta) { return 0xF000F0; }
    @Override public class_3999 method_18122() { return class_3999.field_17829; }
}
