package dev.killerranking.client;

import net.minecraft.class_2400;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4066;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

/**
 * Small full-bright pixel shards in the weapon's color. They fly off the blade during a swing
 * and burst from the contact point on a hit, then drift, spin and fade like petals.
 */
public final class SlashShardParticle extends class_4003 {
    private static class_4002 sprites;
    private final float spin;
    private final float baseSize;

    private SlashShardParticle(class_638 level, double x, double y, double z, class_243 velocity, int rgb, float size, int life, class_4002 set) {
        super(level, x, y, z, velocity.field_1352, velocity.field_1351, velocity.field_1350);
        field_3852 = velocity.field_1352; field_3869 = velocity.field_1351; field_3850 = velocity.field_1350;
        field_3862 = false;
        field_3844 = 0.045f + field_3840.method_43057() * 0.03f;
        field_28786 = 0.90f;
        field_3847 = life;
        baseSize = size;
        field_17867 = size;
        spin = (field_3840.method_43057() - 0.5f) * 0.9f;
        field_3839 = field_3840.method_43057() * 6.283f; field_3857 = field_3839;
        float brighten = 0.85f + field_3840.method_43057() * 0.15f;
        method_3084(((rgb >> 16) & 255) / 255f * brighten, ((rgb >> 8) & 255) / 255f * brighten, (rgb & 255) / 255f * brighten);
        method_18141(set.method_18139(field_3840));
        field_3841 = 1;
    }

    @Override public void method_3070() {
        field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871; field_3857 = field_3839;
        if (field_3866++ >= field_3847) { method_3085(); return; }
        field_3869 -= field_3844 * 0.04;
        method_3069(field_3852, field_3869, field_3850);
        field_3852 *= field_28786; field_3869 *= 0.96; field_3850 *= field_28786;
        field_3839 += spin * Math.max(0.25f, 1 - field_3866 / (float) field_3847);
        float tail = (field_3847 - field_3866) / (float) Math.max(1, field_3847 * 0.4f);
        field_3841 = Math.min(1, tail);
        field_17867 = baseSize * (0.7f + 0.3f * Math.min(1, tail));
    }

    @Override protected int method_3068(float delta) { return 0xF000F0; }
    @Override public class_3999 method_18122() { return class_3999.field_17829; }

    /** Spawn `count` shards at `origin`, pushed along `direction` with spread; honours the particle setting. */
    public static void burst(class_243 origin, class_243 direction, int count, int rgb, float speed, float spread, float size, int life) {
        var c = class_310.method_1551();
        if (c.field_1687 == null || sprites == null) return;
        var setting = c.field_1690.method_42475().method_41753();
        if (setting == class_4066.field_18199) count = Math.max(1, count / 4);
        else if (setting == class_4066.field_18198) count = Math.max(1, count / 2);
        var rng = c.field_1687.field_9229;
        for (int i = 0; i < count; i++) {
            class_243 v = direction.method_1021(speed * (0.5 + rng.method_43057()))
                .method_1031((rng.method_43057() - 0.5) * spread, (rng.method_43057() - 0.3) * spread, (rng.method_43057() - 0.5) * spread);
            float s = size * (0.6f + rng.method_43057() * 0.8f);
            int l = life + rng.method_43048(Math.max(1, life / 2));
            c.field_1713.method_3058(new SlashShardParticle(c.field_1687, origin.field_1352 + (rng.method_43057() - 0.5) * 0.1, origin.field_1351 + (rng.method_43057() - 0.5) * 0.1,
                origin.field_1350 + (rng.method_43057() - 0.5) * 0.1, v, rgb, s, l, sprites));
        }
    }

    public static final class Provider implements class_707<class_2400> {
        public Provider(class_4002 set) { sprites = set; }
        @Override public class_703 createParticle(class_2400 type, class_638 level, double x, double y, double z, double dx, double dy, double dz) {
            return new SlashShardParticle(level, x, y, z, new class_243(dx, dy, dz), 0xFFFFFF, 0.08f, 24, sprites);
        }
    }
}
