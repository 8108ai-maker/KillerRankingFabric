package dev.killerranking.client;

import dev.killerranking.client.mixin.RushCubeAccess;
import dev.killerranking.visual.RushTorso;
import java.util.*;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;
import org.joml.Vector3f;

/** Rigid native skin arms reposition at the shoulder; cloth follows the same matrix. */
public final class RushArmRenderer {
    private record Binding(UUID player,boolean left,boolean hand) { }
    private record Bandage(org.joml.Matrix4f pose,org.joml.Matrix3f normal,boolean slim,float center,
                           int light,int overlay,int color) { }
    private static final Map<UUID,List<Bandage>> BANDAGES=new HashMap<>();
    private record Point(float x,float y,float z,float u,float v) {
        Point between(Point b,float t) { return new Point(x+(b.x-x)*t,y+(b.y-y)*t,z+(b.z-z)*t,u+(b.u-u)*t,v+(b.v-v)*t); }
    }
    private record Face(List<Point> points,Vector3f normal) { }
    private static final Map<class_630,Binding> PARTS=new WeakHashMap<>();
    private static final Map<class_630.class_628,List<Face>> MESH=new WeakHashMap<>();
    private static long rendered;
    public static void bind(class_591<?> model,class_1309 entity) {
        SkillArmTrails.bind(model,entity);
        boolean active=entity instanceof class_742&&(RushVfx.active(entity.method_5667())||HeavyPunchVfx.active(entity.method_5667()));
        if(active)anchorTorso(model);
        for(var part:List.of(model.field_3401,model.field_3486,model.field_27433,model.field_3484)) {
            if(active) PARTS.put(part,new Binding(entity.method_5667(),part==model.field_27433||part==model.field_3484,
                part==model.field_27433||part==model.field_3401));
            else PARTS.remove(part);
        }
    }
    private static void anchorTorso(class_591<?> model){
        var hip=new class_243((model.field_3397.field_3657+model.field_3392.field_3657)*.5,(model.field_3397.field_3656+model.field_3392.field_3656)*.5,(model.field_3397.field_3655+model.field_3392.field_3655)*.5);
        var pivot=RushTorso.pivot(hip,new class_243(model.field_3391.field_3654,model.field_3391.field_3675,model.field_3391.field_3674));
        float dx=(float)pivot.field_1352-model.field_3391.field_3657,dy=(float)pivot.field_1351-model.field_3391.field_3656,dz=(float)pivot.field_1350-model.field_3391.field_3655;
        model.field_3391.field_3657=(float)pivot.field_1352;model.field_3391.field_3656=(float)pivot.field_1351;model.field_3391.field_3655=(float)pivot.field_1350;
        model.field_3483.method_17138(model.field_3391);
        for(var part:List.of(model.field_3398,model.field_3394,model.field_3401,model.field_3486,model.field_27433,model.field_3484)){
            part.field_3657+=dx;part.field_3656+=dy;part.field_3655+=dz;
        }
    }
    public static boolean render(class_630 part,List<class_630.class_628> cubes,Map<String,class_630> children,class_4587 stack,class_4588 v,int light,int overlay,int color) {
        SkillArmTrails.sample(part,stack);
        var binding=PARTS.get(part);if(binding==null||!(RushVfx.active(binding.player())||HeavyPunchVfx.active(binding.player()))) return false;
        var client=class_310.method_1551();
        if(client.field_1687==null||!(client.field_1687.method_18470(binding.player()) instanceof class_742 p)) return false;
        if(!part.field_3665) return false;
        boolean firstPerson=p==client.field_1724&&client.field_1690.method_31044().method_31034();
        double center=(p.method_52814().comp_1629()==net.minecraft.class_8685.class_7920.field_41122?.5:1)*(binding.left()?1:-1);
        stack.method_22903();part.method_22703(stack);
        if(firstPerson&&!HeavyPunchVfx.active(binding.player()))stack.method_22904(0,.06,.05);
        if(!part.field_38456) for(var cube:cubes) for(var face:MESH.computeIfAbsent(cube,RushArmRenderer::subdivide)) draw(stack,v,face,light,overlay,color);
        for(var child:children.values()) child.method_22699(stack,v,light,overlay,color);
        var hand=binding.left()==(p.method_6068()==net.minecraft.class_1306.field_6182)
            ?net.minecraft.class_1268.field_5808:net.minecraft.class_1268.field_5810;
        if(binding.hand()&&!part.field_38456&&p.method_5998(hand).method_31574(dev.killerranking.KillerRankingMod.TTEOKBAL_FIST))
            BANDAGES.computeIfAbsent(binding.player(),id->new ArrayList<>()).add(new Bandage(
                new org.joml.Matrix4f(stack.method_23760().method_23761()),new org.joml.Matrix3f(stack.method_23760().method_23762()),
                p.method_52814().comp_1629()==net.minecraft.class_8685.class_7920.field_41122,(float)center,light,overlay,color));
        stack.method_22909();rendered++;return true;
    }
    public static void beginBandages(class_1309 entity) { BANDAGES.remove(entity.method_5667()); }
    public static void finishBandages(class_1309 entity,net.minecraft.class_4597 buffers) {
        var layers=BANDAGES.remove(entity.method_5667());if(layers==null)return;
        // Changing textures only after the model finishes preserves its active skin buffer.
        var stack=new class_4587();
        for(var b:layers) {
            stack.method_23760().method_23761().set(b.pose());stack.method_23760().method_23762().set(b.normal());
            FistBandages.render(stack,buffers,b.slim(),b.center(),b.light(),b.overlay(),b.color());
        }
    }
    private static List<Face> subdivide(class_630.class_628 cube) {
        var faces=new ArrayList<Face>();
        for(var polygon:((RushCubeAccess)(Object)cube).killerranking$rushFaces()) {
            var points=Arrays.stream(polygon.field_3502).map(v->new Point(v.field_3605.x,v.field_3605.y,v.field_3605.z,v.field_3604,v.field_3603)).toList();
            float low=points.stream().map(p->p.y).min(Float::compare).orElse(0f),high=points.stream().map(p->p.y).max(Float::compare).orElse(0f);
            if(high-low<.001) {faces.add(new Face(points,new Vector3f(polygon.field_21618)));continue;}
            for(float y=low;y<high;y+=.75f) {
                var clipped=clip(clip(points,y,true),Math.min(y+.75f,high),false);
                if(clipped.size()==4) faces.add(new Face(clipped,new Vector3f(polygon.field_21618)));
            }
        }
        return List.copyOf(faces);
    }
    private static List<Point> clip(List<Point> input,float y,boolean above) {
        var result=new ArrayList<Point>();if(input.isEmpty())return result;
        var previous=input.getLast();boolean prev=above?previous.y>=y:previous.y<=y;
        for(var current:input) {
            boolean inside=above?current.y>=y:current.y<=y;
            if(inside!=prev) result.add(previous.between(current,(y-previous.y)/(current.y-previous.y)));
            if(inside)result.add(current);previous=current;prev=inside;
        }
        return result;
    }
    private static void draw(class_4587 stack,class_4588 v,Face face,int light,int overlay,int color) {
        var pose=stack.method_23760();var n=face.normal;
        for(var point:face.points) {
            v.method_22918(pose.method_23761(),point.x/16,point.y/16,point.z/16).method_39415(color).method_22913(point.u,point.v)
                .method_22922(overlay).method_60803(light).method_60831(pose,n.x,n.y,n.z);
        }
    }
    public static long renderedParts() { return rendered; }
    private RushArmRenderer() { }
}
