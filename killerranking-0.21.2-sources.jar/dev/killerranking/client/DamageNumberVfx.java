package dev.killerranking.client;

import dev.killerranking.combat.WeaponFamily;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_638;

/** Floating pixel damage numbers at each weapon contact: rise, hang, then fade. Crits pop bigger and gold, kills red. */
public final class DamageNumberVfx {
    private record Number(class_243 position, String text, int color, float scale, long born, float drift) { }
    private static final List<Number> NUMBERS = new ArrayList<>();
    private static final float LIFE = 22f;
    private static class_638 world;

    public static void register() { WorldRenderEvents.AFTER_ENTITIES.register(DamageNumberVfx::render); }

    public static void add(class_243 at, float damage, WeaponFamily family, boolean crit, boolean lethal) {
        var c = class_310.method_1551();
        if (c.field_1687 == null || damage <= 0) return;
        if (world != c.field_1687) { clear(); world = c.field_1687; }
        if (NUMBERS.size() >= 48) NUMBERS.removeFirst();
        String text = damage >= 10 ? Integer.toString(Math.round(damage)) : String.format(java.util.Locale.ROOT, "%.1f", damage);
        int color = lethal ? 0xFF5A4A : crit ? 0xFFD54A : switch (family) {
            case SAW -> 0xFF7A6A;
            case HATCHET -> 0xFFC37A;
            case FIST, KNUCKLE -> 0xDDFFD2;
            case PIERCE -> 0xEADFFF;
            default -> 0xFFFFFF;
        };
        float scale = (crit || lethal ? 1.45f : 1f) * (damage >= 20 ? 1.2f : 1f);
        float drift = (c.field_1687.field_9229.method_43057() - 0.5f) * 0.5f;
        NUMBERS.add(new Number(at.method_1031(0, 0.25, 0), text, color, scale, c.field_1687.method_8510(), drift));
    }

    public static void tick(class_310 c) {
        if (c.field_1687 != world) { clear(); world = c.field_1687; return; }
        if (world == null || c.method_1493()) return;
        NUMBERS.removeIf(n -> world.method_8510() - n.born >= LIFE + 1);
    }

    public static void clear() { NUMBERS.clear(); world = null; }

    private static void render(WorldRenderContext ctx) {
        if (ctx.world() != world || ctx.matrixStack() == null || ctx.consumers() == null || NUMBERS.isEmpty()) return;
        var camera = ctx.camera().method_19326();
        var font = class_310.method_1551().field_1772;
        float delta = ctx.tickCounter().method_60637(false);
        for (var n : NUMBERS) {
            if (n.position.method_1025(camera) > 1024) continue;
            float age = world.method_8510() - n.born + delta;
            if (age < 0 || age >= LIFE) continue;
            // quick pop, slow rise, late fade
            float pop = age < 2 ? 1.35f - 0.175f * age : 1f;
            float rise = (float) (1 - Math.exp(-age / 5f)) * 0.65f;
            float alpha = age < LIFE - 6 ? 1f : (LIFE - age) / 6f;
            if (alpha < 0.04f) continue; // Font treats near-zero alpha as opaque; skip the last sliver instead.
            float size = 0.028f * n.scale * pop;
            var stack = ctx.matrixStack();
            stack.method_22903();
            stack.method_22904(n.position.field_1352 - camera.field_1352 + n.drift * rise, n.position.field_1351 - camera.field_1351 + rise, n.position.field_1350 - camera.field_1350);
            stack.method_22907(ctx.camera().method_23767());
            stack.method_22905(-size, -size, size);
            float x = -font.method_1727(n.text) / 2f;
            int a = (int) (alpha * 255) << 24;
            var m = stack.method_23760().method_23761();
            // thick pixel outline: four offset shadow passes, then the coloured number
            for (int[] o : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}})
                font.method_27521(n.text, x + o[0], o[1], a | 0x1A1A1A, false, m, ctx.consumers(), class_327.class_6415.field_33994, 0, 0xF000F0);
            font.method_27521(n.text, x, 0, a | n.color, false, m, ctx.consumers(), class_327.class_6415.field_33994, 0, 0xF000F0);
            stack.method_22909();
        }
    }

    private DamageNumberVfx() { }
}
