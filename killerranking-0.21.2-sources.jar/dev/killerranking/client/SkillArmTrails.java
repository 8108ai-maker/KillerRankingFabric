package dev.killerranking.client;

import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import java.util.*;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;

/** Captures real hand matrices for bare-hand skills, including Rook's separate mounted scene. */
public final class SkillArmTrails {
    private record Binding(class_742 player,boolean left){ }
    private static final Map<class_630,Binding> PARTS=new WeakHashMap<>();
    public static void bind(class_591<?> model,class_1309 entity){
        if(entity instanceof class_742 p&&(RushVfx.active(p.method_5667())||RookVfx.active(p.method_5667()))){
            PARTS.put(model.field_3401,new Binding(p,false));PARTS.put(model.field_27433,new Binding(p,true));
        }else{PARTS.remove(model.field_3401);PARTS.remove(model.field_27433);}
    }
    public static void sample(class_630 part,class_4587 stack){
        var b=PARTS.get(part);if(b==null||!part.field_3665||part.field_38456)return;
        var p=b.player();var client=class_310.method_1551();
        boolean markerLeft=b.left();
        // Player Animator mirrors native arm names, but custom markers need an explicit swap.
        if(RookVfx.active(p.method_5667())&&p.method_6068()==net.minecraft.class_1306.field_6182)markerLeft=!markerLeft;
        var marker=PlayerAnimationAccess.getPlayerAnimLayer(p).get3DTransform(markerLeft?"leftSkillTrail":"rightSkillTrail",TransformType.POSITION,client.method_60646().method_60637(false),Vec3f.ZERO);
        float center=(p.method_52814().comp_1629()==net.minecraft.class_8685.class_7920.field_41122?.5f:1)*(b.left()?1:-1);
        stack.method_22903();part.method_22703(stack);
        if(RushVfx.active(p.method_5667())&&p==client.field_1724&&client.field_1690.method_31044().method_31034())stack.method_22904(0,.06,.05);
        NightBatTrail.hand(p,b.left(),stack,center,marker);stack.method_22909();
    }
    static void clear(){PARTS.clear();}
    private SkillArmTrails(){ }
}
