package dev.killerranking.client;

import dev.killerranking.visual.HeavyPunchGrip;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Apply the complete reference pose after vanilla and the animation library finish setup. */
public final class HeavyPunchPose {
    public static void apply(class_1309 e,class_572<?> model,class_4587 stack,float delta){
        if(!HeavyPunchVfx.active(e.method_5667()))return;
        boolean left=e.method_6068()==class_1306.field_6182;
        boolean fp=e==class_310.method_1551().field_1724&&dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode.isFirstPersonPass();
        var pose=HeavyPunchGrip.pose(HeavyPunchVfx.age(e.method_5667(),delta),left,fp,center(e));
        set(model.field_3391,pose.torso());set(model.field_3398,pose.head());
        set(left?model.field_27433:model.field_3401,pose.punch());set(left?model.field_3401:model.field_27433,pose.brace());
        set(model.field_3392,pose.rightLeg());set(model.field_3397,pose.leftLeg());
        model.field_3394.method_17138(model.field_3398);
        if(model instanceof class_591<?> player){
            player.field_3484.method_17138(model.field_27433);player.field_3486.method_17138(model.field_3401);
            player.field_3483.method_17138(model.field_3391);player.field_3482.method_17138(model.field_3397);player.field_3479.method_17138(model.field_3392);
        }
    }
    private static void set(class_630 part,HeavyPunchGrip.Limb pose){
        var p=pose.pivot();var r=pose.rotation();
        part.method_2851((float)p.field_1352,(float)p.field_1351,(float)p.field_1350);part.method_33425((float)r.field_1352,(float)r.field_1351,(float)r.field_1350);
        part.field_37938=part.field_37939=part.field_37940=1;
    }
    public static float center(class_1309 e){return e instanceof class_742 p&&p.method_52814().comp_1629()==net.minecraft.class_8685.class_7920.field_41122?.5f:1;}
    public static Vector3f localPoint(class_630 arm,float handX,float handY){
        return new Matrix4f().translation(arm.field_3657,arm.field_3656,arm.field_3655).rotateZYX(arm.field_3674,arm.field_3675,arm.field_3654).transformPosition(new Vector3f(handX,handY,0));
    }
    private HeavyPunchPose() { }
}
