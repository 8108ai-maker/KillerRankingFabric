package dev.killerranking.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_437;
import net.minecraft.class_6382;

public abstract class PanelScreen extends class_437 {
    protected static final int W = 340, H = 286, WHITE = 0xFFF1F4FA, MUTED = 0xFF9FACBF, ACCENT = 0xFF81D6C5;
    protected final class_437 parent;
    protected int left, top;
    protected float scale;
    protected PanelScreen(String title, class_437 parent) { super(class_2561.method_43470(title)); this.parent = parent; if (parent == null) UiSounds.open(); }
    @Override protected void method_25426() {
        scale = FixedUi.factor();
        left = Math.round((field_22789 - W * scale) / 2); top = Math.round((field_22790 - H * scale) / 2);
        button(303, 11, 22, 18, "×", this::method_25419);
    }
    protected class_4264 button(int x, int y, int w, int h, String label, Runnable action) {
        return method_37063(new class_4264(left + Math.round(x * scale), top + Math.round(y * scale), Math.round(w * scale), Math.round(h * scale), class_2561.method_43470(label)) {
            @Override public void method_25306() { action.run(); }
            @Override protected void method_48579(class_332 g, int mx, int my, float delta) {
                // Keep widgets above the separately batched panel background.
                g.method_51448().method_22903(); g.method_51448().method_46416(0, 0, 10);
                g.method_25294(method_46426(), method_46427(), method_46426() + method_25368(), method_46427() + method_25364(), !field_22763 ? 0xFF202C3D : method_25367() ? 0xFF456478 : 0xFF2E425A);
                if (method_25370()) g.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), WHITE);
                g.method_51448().method_22903(); g.method_51448().method_46416(method_46426() + method_25368() / 2f, method_46427() + (method_25364() - 8 * scale) / 2f, 0); g.method_51448().method_22905(scale, scale, 1);
                g.method_27534(field_22793, method_25369(), 0, 0, field_22763 ? WHITE : MUTED); g.method_51448().method_22909();
                g.method_51448().method_22909();
            }
            @Override protected void method_47399(class_6382 output) { method_37021(output); }
            @Override public void method_25354(net.minecraft.class_1144 manager) { UiSounds.click(manager); }
        });
    }
    @Override public void method_25420(class_332 g, int mx, int my, float delta) {
        super.method_25420(g, mx, my, delta);
        g.method_51448().method_22903(); g.method_51448().method_46416(left, top, 0); g.method_51448().method_22905(scale, scale, 1);
        g.method_25294(0, 0, W, H, 0xFF101723); g.method_49601(0, 0, W, H, 0xFF456478);
        g.method_27534(field_22793, field_22785, W / 2, 16, ACCENT);
        g.method_25294(16, 34, W - 16, 35, 0xFF344053);
        content(g);
        g.method_25300(field_22793, "ESC로 닫기", W / 2, 266, MUTED);
        g.method_51448().method_22909();
        g.method_51452();
    }
    protected abstract void content(class_332 g);
    protected void text(class_332 g, String value, int x, int y, int color) { g.method_51433(field_22793, value, x, y, color, false); }
    @Override public void method_25419() { if (parent == null) UiSounds.close(); field_22787.method_1507(parent); }
    @Override public boolean method_25421() { return false; }
}
