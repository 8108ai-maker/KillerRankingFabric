package dev.killerranking.client;

import dev.killerranking.visual.CombatCameraMotion;
import java.util.ArrayList;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_7833;

/** Camera feedback never writes entity rotation, movement, aim or options. */
public final class CombatCameraFeedback {
    private record Pulse(double born,float power,float side,boolean parry){ }
    private static final ArrayList<Pulse> PULSES=new ArrayList<>();
    private static class_638 world;
    private static long parries,fovFrames,shakeFrames;
    private static float minimumFov=1,maximumAngle;
    private static void prepare(class_310 c){if(world!=c.field_1687){clear();world=c.field_1687;}}
    public static void parry(java.util.UUID owner){
        var c=class_310.method_1551();if(c.field_1724==null||c.field_1687==null||!c.field_1724.method_5667().equals(owner))return;
        prepare(c);add(new Pulse(world.method_8510(),1,1,true));parries++;
    }
    private static float hitSide=1;
    /** A lighter, alternating-side kick for ordinary weapon contacts; heavy families and crits push harder. */
    public static void hit(dev.killerranking.combat.WeaponFamily family,boolean crit){
        var c=class_310.method_1551();if(c.field_1724==null||c.field_1687==null)return;
        prepare(c);hitSide=-hitSide;
        float power=switch(family){case BLUNT,HATCHET->.62f;case KNUCKLE->.55f;case SAW->.5f;default->.4f;};
        if(crit)power*=1.35f;
        add(new Pulse(world.method_8510(),power,hitSide,false));
    }
    private static void add(Pulse p){if(PULSES.size()>=8)PULSES.removeFirst();PULSES.add(p);}
    public static void tick(class_310 c){prepare(c);if(world==null||c.method_1493())return;PULSES.removeIf(p->world.method_8510()-p.born>=8);}
    public static CombatCameraMotion.Pose sample(float delta){
        var c=class_310.method_1551();prepare(c);
        if(world==null||c.field_1724==null||c.method_1560()!=c.field_1724||!c.field_1690.method_31044().method_31034()||c.field_1755!=null||!c.field_1724.method_5805())return CombatCameraMotion.Pose.REST;
        float pitch=0,yaw=0,roll=0,x=0,y=0,fov=1;
        double time=world.method_8510()+delta;
        for(var p:PULSES){var v=CombatCameraMotion.sample((float)(time-p.born),p.power(),p.side(),p.parry());pitch+=v.pitch();yaw+=v.yaw();roll+=v.roll();x+=v.x();y+=v.y();fov+=v.fov()-1;}
        return new CombatCameraMotion.Pose(Math.clamp(pitch,-1.6f,1.6f),Math.clamp(yaw,-1.2f,1.2f),Math.clamp(roll,-.9f,.9f),Math.clamp(x,-.008f,.008f),Math.clamp(y,-.01f,.01f),Math.clamp(fov,.90f,1.025f));
    }
    public static double fov(double original,float delta){
        var p=sample(delta);if(p.fov()!=1){fovFrames++;minimumFov=Math.min(minimumFov,p.fov());}return original*p.fov();
    }
    public static void shake(class_4587 stack,float delta){
        var p=sample(delta);if(p.equals(CombatCameraMotion.Pose.REST))return;
        stack.method_46416(p.x(),p.y(),0);stack.method_22907(class_7833.field_40714.rotationDegrees(p.pitch()));stack.method_22907(class_7833.field_40716.rotationDegrees(p.yaw()));stack.method_22907(class_7833.field_40718.rotationDegrees(p.roll()));
        shakeFrames++;maximumAngle=Math.max(maximumAngle,Math.max(Math.abs(p.pitch()),Math.max(Math.abs(p.yaw()),Math.abs(p.roll()))));
    }
    public static long parries(){return parries;}
    public static long fovFrames(){return fovFrames;}public static long shakeFrames(){return shakeFrames;}
    public static float minimumFov(){return minimumFov;}public static float maximumAngle(){return maximumAngle;}
    public static int activeCount(){return PULSES.size();}
    public static void clear(){PULSES.clear();world=null;parries=fovFrames=shakeFrames=0;minimumFov=1;maximumAngle=0;}
    private CombatCameraFeedback(){ }
}
