package dev.killerranking.client;

import net.minecraft.class_310;
import net.minecraft.class_332;

/** Mod coordinates use three physical pixels per unit, independent of vanilla GUI scale. */
public final class FixedUi {
    public static final int SCALE = 3;
    public static float factor() { return (float) (SCALE / class_310.method_1551().method_22683().method_4495()); }
    public static int width() { return (int) Math.ceil(class_310.method_1551().method_22683().method_4489() / (double) SCALE); }
    public static int height() { return (int) Math.ceil(class_310.method_1551().method_22683().method_4506() / (double) SCALE); }
    public static void begin(class_332 graphics) {
        graphics.method_51448().method_22903();
        graphics.method_51448().method_22905(factor(), factor(), 1);
    }
    public static void end(class_332 graphics) { graphics.method_51448().method_22909(); }
    private FixedUi() { }
}
