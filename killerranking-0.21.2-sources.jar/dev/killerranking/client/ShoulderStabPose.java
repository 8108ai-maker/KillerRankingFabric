package dev.killerranking.client;
import dev.killerranking.visual.HeavyPunchGrip;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public final class ShoulderStabPose {
    public static void apply(class_1309 e,class_583<?> base,class_4587 stack,float delta){
        if(!ShoulderStabVfx.casting(e.method_5667())||!(base instanceof class_572<?> model))return;
        var pose=ShoulderStabVfx.pose(e,stack,delta);
        set(model.field_3391,pose.torso());set(model.field_3398,pose.head());set(model.field_3401,pose.rightArm());set(model.field_27433,pose.leftArm());set(model.field_3392,pose.rightLeg());set(model.field_3397,pose.leftLeg());
        model.field_3394.method_17138(model.field_3398);if(model instanceof class_591<?> p){p.field_3483.method_17138(model.field_3391);p.field_3486.method_17138(model.field_3401);p.field_3484.method_17138(model.field_27433);p.field_3479.method_17138(model.field_3392);p.field_3482.method_17138(model.field_3397);}
    }
    private static void set(class_630 part,HeavyPunchGrip.Limb limb){var p=limb.pivot();var r=limb.rotation();part.method_2851((float)p.field_1352,(float)p.field_1351,(float)p.field_1350);part.method_33425((float)r.field_1352,(float)r.field_1351,(float)r.field_1350);part.field_37938=part.field_37939=part.field_37940=1;}
    private ShoulderStabPose(){ }
}
