package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.*;
import dev.killerranking.network.MadnessLeapStatusPayload;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class ClientMadnessLeap {
    private static MadnessLeapStatusPayload value;private static int elapsed;
    public static void set(MadnessLeapStatusPayload status){value=status;elapsed=0;}
    public static void clear(){value=null;elapsed=0;}
    public static void tick(){if(value!=null&&elapsed<Integer.MAX_VALUE)elapsed++;}
    public static boolean available(){return value!=null&&value.available();}
    public static int phase(){return value==null?0:value.phase();}
    public static int age(){return value==null?0:value.age()+elapsed;}
    public static int cooldown(){return value==null?0:Math.max(0,value.cooldown()-elapsed);}
    public static class_1309 selected(){var p=class_310.method_1551().field_1724;return p==null?null:MadnessLeapTargeting.selected(p);}
    public static boolean outlines(class_1297 e){return phase()==MadnessLeapRules.AIM&&e==selected();}
    public static float progress(){return phase()==MadnessLeapRules.AIM?1:phase()==MadnessLeapRules.CAST?
        Math.max(0,1-age()/(float)MadnessLeapRules.DURATION):CombatRules.cooldownProgress(cooldown(),MadnessLeapRules.COOLDOWN);}
    public static class_2561 status(){
        if(phase()==MadnessLeapRules.AIM)return class_2561.method_43470(selected()==null?"2~10m 지정":"놓으면 도약");
        if(phase()==MadnessLeapRules.CAST)return class_2561.method_43470("도약 · 내려찍기");
        if(cooldown()>0)return class_2561.method_43470(CombatHud.seconds(cooldown()));
        if(!TraitVisuals.enabled())return class_2561.method_43470("꺼짐");
        var p=class_310.method_1551().field_1724;
        return class_2561.method_43470(p!=null&&!p.method_6047().method_31574(KillerRankingMod.EUNBAL_HATCHET)?"도끼 필요":"준비");
    }
    private ClientMadnessLeap() { }
}
