package dev.killerranking.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Block-built, coiled purple apparition; no entity, armor slot or gameplay hitbox. */
final class PoisonSnakeModel {
    private static final class_1921 LAYER = class_1921.method_23580(class_2960.method_60656("textures/block/white_concrete.png"));
    private static final int BODY = 0x7042A8, SCALE = 0xA674E5, BELLY = 0xC5A4DD;
    static void render(WorldRenderContext context, class_1657 player, float delta, float alpha) {
        if (PoisonVfx.salmosa(player.method_5667())) { SalmosaSnakeModel.render(context, player, delta, alpha); return; }
        var stack = context.matrixStack();
        var camera = context.camera().method_19326();
        var vertices = context.consumers().getBuffer(LAYER);
        stack.method_22903();
        stack.method_22904(class_3532.method_16436(delta, player.field_6038, player.method_23317()) - camera.field_1352,
            class_3532.method_16436(delta, player.field_5971, player.method_23318()) - camera.field_1351,
            class_3532.method_16436(delta, player.field_5989, player.method_23321()) - camera.field_1350);
        stack.method_22907(class_7833.field_40716.rotationDegrees(-class_3532.method_17821(delta, player.field_6220, player.field_6283)));
        float time = player.field_6012 + delta;
        float sway = (float) Math.sin(time * .055) * .10f;
        // Long, thick Minecraft-style blocks with a small visible joint gap.
        Vector3f previous = coil(0, time);
        for (int i = 1; i <= 16; i++) {
            float progress = i / 16f;
            var next = coil(progress, time);
            segment(stack, vertices, previous, next, .13f + .39f * Math.min(1, progress * 4), i, alpha);
            previous = next;
        }
        var base = previous;
        for (int i = 1; i <= 4; i++) {
            float t = i / 4f;
            var next = new Vector3f(base.x - (float) Math.sin(t * Math.PI) * .52f + sway * t,
                base.y + t * 1.65f, base.z + t * .95f);
            segment(stack, vertices, previous, next, .52f + .04f * t, i + 16, alpha);
            previous = next;
        }
        float age = PoisonVfx.age(player.method_5667()) + delta;
        stack.method_22903();
        stack.method_46416(previous.x, previous.y, previous.z);
        stack.method_22907(class_7833.field_40716.rotationDegrees((float) Math.sin(time * .04) * 12));
        stack.method_22907(class_7833.field_40714.rotationDegrees(headPitch(time, age)));
        head(stack, vertices, alpha, age);
        stack.method_22909();
        stack.method_22909();
    }
    private static void head(class_4587 s, class_4588 v, float alpha, float age) {
        float threat = threat(age);
        // Broad flat skull and a short blunt muzzle; no triangular beak or pupils.
        box(s,v,-.47f,-.045f,-.40f,.94f,.36f,.60f,BODY,alpha);
        box(s,v,-.34f,-.040f,.13f,.68f,.24f,.49f,BODY,alpha);
        box(s,v,-.30f,.202f,.18f,.60f,.025f,.36f,SCALE,alpha);
        box(s,v,-.29f,-.068f,.05f,.58f,.022f,.53f,0x2D163D,alpha);
        for (int side : new int[]{-1, 1}) {
            // Long fangs fold into the closed mouth and unfold during the hiss.
            s.method_22903();s.method_46416(side*.235f,-.065f,.36f);
            s.method_22907(class_7833.field_40714.rotationDegrees(72*(1-threat)));
            box(s,v,-.045f,-.12f,-.045f,.09f,.12f,.09f,0xEDE2F7,alpha);
            box(s,v,-.031f,-.255f,-.031f,.062f,.135f,.062f,0xEDE2F7,alpha);
            box(s,v,-.015f,-.36f,-.015f,.03f,.105f,.03f,0xF6EDFF,alpha);
            s.method_22909();
        }
        s.method_22903();s.method_46416(0,-.035f,-.20f);
        s.method_22907(class_7833.field_40714.rotationDegrees(34*threat));
        box(s,v,-.39f,-.13f,0,.78f,.13f,.56f,0x76538D,alpha);
        box(s,v,-.29f,-.12f,.44f,.58f,.12f,.38f,BELLY,alpha);
        box(s,v,-.33f,.001f,.08f,.66f,.012f,.65f,0x381F46,alpha);
        float flick = tongue(age)*threat;
        if(flick>.02f){
            // The jaw drops, but the tongue probes forward out of the mouth.
            s.method_22903();s.method_46416(0,.018f,.69f);s.method_22907(class_7833.field_40714.rotationDegrees(-24*threat));
            float length=.12f+.46f*flick;
            box(s,v,-.024f,0,0,.048f,.022f,length,0xCF3764,alpha);
            for(int side:new int[]{-1,1}){
                s.method_22903();s.method_46416(side*.014f,0,length-.015f);
                s.method_22907(class_7833.field_40716.rotationDegrees(side*24));
                box(s,v,-.012f,0,0,.024f,.018f,.15f*flick,0xF06488,alpha);
                s.method_22909();
            }
            s.method_22909();
        }
        s.method_22909();
    }
    static Vector3f headPoint(class_1657 player, float delta, float x, float y, float z) {
        if (PoisonVfx.salmosa(player.method_5667())) return SalmosaSnakeModel.headPoint(player, delta, x, y, z);
        float time = player.field_6012 + delta;
        var origin = new Vector3f(x, y, z)
            .rotateX((float) Math.toRadians(headPitch(time, PoisonVfx.age(player.method_5667())+delta)))
            .rotateY((float) Math.toRadians(Math.sin(time * .04) * 12));
        var base = coil(1, time);
        origin.add(base.x + (float) Math.sin(time * .055) * .10f, base.y + 1.65f, base.z + .95f);
        return origin.rotateY((float) Math.toRadians(-class_3532.method_17821(delta, player.field_6220, player.field_6283)));
    }
    private static float headPitch(float time,float age){return 24+(float)Math.sin(time*.03)*2-6*threat(age);}
    private static float threat(float age){
        float t=age%72;
        return smooth((t-7)/10)*smooth((47-t)/12);
    }
    private static float smooth(float t){t=class_3532.method_15363(t,0,1);return t*t*(3-2*t);}
    private static float tongue(float age){
        float t=age%72,value=0;
        for(int center:new int[]{20,28,36})value=Math.max(value,Math.max(0,1-Math.abs(t-center)/3));
        return smooth(value);
    }
    private static Vector3f coil(float t, float time) {
        double angle = -Math.PI / 2 + t * Math.PI * 3.5;
        float radius = .80f + .43f * (float) Math.sin(t * Math.PI);
        return new Vector3f((float) Math.sin(angle) * radius,
            .28f + t * 1.22f + (float) Math.sin(angle * 2 + time * .065) * .045f,
            -1.55f + (float) Math.cos(angle) * .57f);
    }
    private static void segment(class_4587 stack, class_4588 v, Vector3f a, Vector3f b, float width, int index, float alpha) {
        var direction = new Vector3f(b).sub(a);
        float length = direction.length();
        stack.method_22903(); stack.method_22904((a.x + b.x) * .5, (a.y + b.y) * .5, (a.z + b.z) * .5);
        stack.method_22907(new Quaternionf().rotationTo(new Vector3f(0, 1, 0), direction.normalize()));
        float half = width * .5f;
        float blockLength=length*.90f;
        box(stack, v, -half, -blockLength * .5f, -half, width, blockLength, width, BODY, alpha);
        // Flush pixel panels, rather than more small raised geometric parts.
        float patch = width * (index % 3 == 0 ? .65f : .45f);
        face(stack,v,SCALE,alpha,0,0,1,-patch*.5f,-blockLength*.26f,half+.001f,patch*.5f,-blockLength*.26f,half+.001f,patch*.5f,blockLength*.26f,half+.001f,-patch*.5f,blockLength*.26f,half+.001f);
        face(stack,v,BELLY,alpha,0,0,-1,half*.7f,-blockLength*.40f,-half-.001f,-half*.7f,-blockLength*.40f,-half-.001f,-half*.7f,blockLength*.40f,-half-.001f,half*.7f,blockLength*.40f,-half-.001f);
        stack.method_22909();
    }
    static void box(class_4587 s, class_4588 v, float x, float y, float z, float w, float h, float d, int color, float alpha) {
        float X = x + w, Y = y + h, Z = z + d;
        face(s,v,color,alpha,0,0,-1, X,y,z, x,y,z, x,Y,z, X,Y,z);
        face(s,v,color,alpha,0,0,1, x,y,Z, X,y,Z, X,Y,Z, x,Y,Z);
        face(s,v,color,alpha,-1,0,0, x,y,z, x,y,Z, x,Y,Z, x,Y,z);
        face(s,v,color,alpha,1,0,0, X,y,Z, X,y,z, X,Y,z, X,Y,Z);
        face(s,v,color,alpha,0,1,0, x,Y,Z, X,Y,Z, X,Y,z, x,Y,z);
        face(s,v,color,alpha,0,-1,0, x,y,z, X,y,z, X,y,Z, x,y,Z);
    }
    static void face(class_4587 s, class_4588 v, int c, float a, float nx, float ny, float nz, float... p) {
        for (int i = 0; i < 4; i++) v.method_22918(s.method_23760().method_23761(), p[i*3], p[i*3+1], p[i*3+2])
            .method_22915((c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f, (c & 255) / 255f, a)
            .method_22913(i == 0 || i == 3 ? 0 : 1, i < 2 ? 1 : 0).method_22922(class_4608.field_21444)
            .method_60803(0xF000F0).method_60831(s.method_23760(), nx, ny, nz);
    }
    private PoisonSnakeModel() { }
}
