package dev.killerranking.client;

import com.mojang.blaze3d.vertex.*;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.AutomaticParryState;
import dev.killerranking.network.*;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.firstPerson.*;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.api.layered.modifier.MirrorModifier;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.*;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.class_1059;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_8685;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.world.item.*;
import java.util.*;

/** Native-size upper-body echoes; rapid hits never restart the body's current parry. */
public final class AutoParryVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("auto_parry_layer");
    private static final Map<UUID,Integer> HOLDS=new HashMap<>();
    private static final List<Echo> ECHOES=new ArrayList<>();
    private static class_591<class_742> wide,slim;
    private static long bodyMotions,createdEchoes,renderedEchoes;
    private static final class Echo {
        final UUID player;final float yaw;final class_1306 hand;final boolean bladeBraced;
        final ModifierLayer<IAnimation> animation;int age;
        Echo(class_742 p,AutoParryEffectPayload event,IAnimation motion,class_1306 authoredHand,boolean bladeBraced){
            boolean mirror=p.method_6068()==class_1306.field_6182;
            player=p.method_5667();yaw=event.yaw();hand=mirror?authoredHand.method_5928():authoredHand;
            this.bladeBraced=bladeBraced;
            animation=new ModifierLayer<>();animation.addModifierLast(new MirrorModifier(mirror));animation.setAnimation(motion);
        }
    }
    public static void register(){
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{
            var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new LeftHandedHelperModifier(p));
            stack.addAnimLayer(3100,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
        });
        WorldRenderEvents.AFTER_ENTITIES.register(AutoParryVfx::render);
    }
    public static boolean active(UUID player){return HOLDS.containsKey(player);}
    public static void accept(AutoParryStatusPayload event){
        if(!event.active()){stop(event.player());return;}
        boolean first=!HOLDS.containsKey(event.player());HOLDS.put(event.player(),25);
        if(first){var p=player(event.player());if(p!=null)idle(p);}
    }
    public static void accept(AutoParryEffectPayload event){
        var p=player(event.player());if(p==null||!p.method_5805()||p.method_7325())return;
        HOLDS.put(event.player(),25);
        String name=event.echo()?(switch(Math.floorMod(event.sequence()-1,10)){
            case 0->"pawn6_katana_echo_horizontal";
            case 1->"pawn6_katana_echo_horizontal_reverse";
            case 2->"pawn6_katana_echo_down";
            case 3->"pawn6_katana_echo_down_reverse";
            case 4->"pawn6_katana_echo_upright";
            case 5->"pawn6_katana_echo_upright_reverse";
            case 6->"pawn6_katana_echo_overhead";
            case 7->"pawn6_katana_echo_overhead_reverse";
            case 8->"pawn6_katana_echo_cross_guard";
            default->"pawn6_katana_echo_cross_guard_reverse";
        })
            :(event.reversed()?"pawn6_katana_auto_parry_reverse":"pawn6_katana_auto_parry");
        IAnimation motion=motion(name,!event.echo());
        if(motion==null)return;
        if(!event.echo()){set(p,motion);bodyMotions++;}
        else{
            if(ECHOES.stream().filter(e->e.player.equals(event.player())).count()>=16){
                for(var iterator=ECHOES.iterator();iterator.hasNext();)if(iterator.next().player.equals(event.player())){iterator.remove();break;}
            }
            if(ECHOES.size()>=96)ECHOES.removeFirst();
            // The reference guard grips the raised hilt with the left hand and braces
            // the lower blade with the right. Its reverse uses the opposite hands.
            class_1306 swordHand=name.equals("pawn6_katana_echo_cross_guard")?class_1306.field_6182:class_1306.field_6183;
            ECHOES.add(new Echo(p,event,motion,swordHand,name.startsWith("pawn6_katana_echo_cross_guard")));createdEchoes++;
        }
    }
    private static class_742 player(UUID id){var c=class_310.method_1551();var p=c.field_1687==null?null:c.field_1687.method_18470(id);return p instanceof class_742 clientPlayer?clientPlayer:null;}
    private static IAnimation motion(String name,boolean firstPerson){
        var data=PlayerAnimationRegistry.getAnimation(KillerRankingMod.id(name));if(data==null)return null;
        var motion=(IAnimation)data.playAnimation();
        if(firstPerson&&motion instanceof KeyframeAnimationPlayer key){key.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);key.setFirstPersonConfiguration(new FirstPersonConfiguration(true,true,true,false));}
        return motion;
    }
    @SuppressWarnings("unchecked") private static void set(class_742 p,IAnimation motion){
        var layer=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(layer instanceof ModifierLayer<?> l)((ModifierLayer<IAnimation>)l).setAnimation(motion);
    }
    private static void idle(class_742 p){set(p,motion("pawn6_katana_auto_guard",true));}
    public static void tick(class_310 c){
        if(c.field_1687==null||c.method_1493())return;
        for(var id:new ArrayList<>(HOLDS.keySet())){
            var p=player(id);int ttl=HOLDS.get(id)-1;
            if(ttl<=0||p==null||!p.method_5805()||p.method_7325()||!p.method_6047().method_31574(KillerRankingMod.PAWN6_KATANA)){stop(id);continue;}
            HOLDS.put(id,ttl);var layer=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);
            if(layer instanceof ModifierLayer<?> l&&(l.getAnimation()==null||!l.getAnimation().isActive()))idle(p);
        }
        ECHOES.removeIf(e->{e.age++;e.animation.tick();return e.age>=AutomaticParryState.MOTION_TICKS||!HOLDS.containsKey(e.player);});
    }
    public static void stop(UUID id){HOLDS.remove(id);ECHOES.removeIf(e->e.player.equals(id));var p=player(id);if(p!=null)set(p,null);}
    public static void clear(){for(var id:new ArrayList<>(HOLDS.keySet()))stop(id);ECHOES.clear();wide=slim=null;bodyMotions=createdEchoes=renderedEchoes=0;}
    public static int echoCount(){return ECHOES.size();}
    public static long bodyMotionCount(){return bodyMotions;}
    public static long createdEchoCount(){return createdEchoes;}
    public static long renderedEchoCount(){return renderedEchoes;}
    private static class_591<class_742> model(boolean narrow){
        var found=narrow?slim:wide;if(found!=null)return found;
        found=new class_591<>(class_310.method_1551().method_31974().method_32072(narrow?class_5602.field_27581:class_5602.field_27577),narrow);
        found.field_3448=false;
        if(narrow)slim=found;else wide=found;return found;
    }
    private static void joint(class_630 part,String name,Echo echo,float delta){
        part.method_41923();
        var pos=echo.animation.get3DTransform(name,TransformType.POSITION,delta,new Vec3f(part.field_3657,part.field_3656,part.field_3655));
        var rot=echo.animation.get3DTransform(name,TransformType.ROTATION,delta,Vec3f.ZERO);
        part.method_2851(pos.getX(),pos.getY(),pos.getZ());part.method_33425(rot.getX(),rot.getY(),rot.getZ());
        part.field_37938=part.field_37939=part.field_37940=1;
    }
    private static void render(WorldRenderContext context){
        if(context.matrixStack()==null||context.consumers()==null)return;
        var c=class_310.method_1551();var camera=context.camera().method_19326();float delta=context.tickCounter().method_60637(false);
        for(var echo:ECHOES){
            var p=player(echo.player);if(p==null||p.method_5767())continue;
            // Follow the source player's interpolated origin, including movement during a chain.
            var at=p.method_30950(delta);if(at.method_1025(camera)>1024)continue;
            boolean firstPerson=p==c.field_1724&&c.field_1690.method_31044().method_31034();
            float opacity=(firstPerson?.24f:.48f)*Math.min(1,(echo.age+delta+1)/2)*(1-(echo.age+delta)/AutomaticParryState.MOTION_TICKS);
            if(opacity<=.01f)continue;
            echo.animation.setupAnim(delta);var model=model(p.method_52814().comp_1629()==class_8685.class_7920.field_41122);
            joint(model.field_3391,"body",echo,delta);joint(model.field_3401,"rightArm",echo,delta);joint(model.field_27433,"leftArm",echo,delta);
            // Slim-skin held-item anchors shift each hand outward by half a pixel.
            // Bring the blade-support hand to the same side as the hilt anchor.
            if(echo.bladeBraced&&p.method_52814().comp_1629()==class_8685.class_7920.field_41122){
                if(echo.hand==class_1306.field_6182)model.field_3401.field_3657-=1;
                else model.field_27433.field_3657+=1;
            }
            model.field_3483.method_17138(model.field_3391);model.field_3486.method_17138(model.field_3401);model.field_3484.method_17138(model.field_27433);
            var stack=context.matrixStack();stack.method_22903();stack.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);
            float nativeScale=.9375f*p.method_55693();
            stack.method_22907(class_7833.field_40716.rotationDegrees(180-echo.yaw));stack.method_22905(-nativeScale,-nativeScale,nativeScale);stack.method_22904(0,-1.501,0);
            int color=((int)(opacity*255)<<24)|0xDCEEFF;
            var skinType=firstPerson?class_1921.method_23689(p.method_52814().comp_1626()):class_1921.method_42600(p.method_52814().comp_1626());
            renderUpperBody(model,stack,context.consumers().getBuffer(skinType),color,!firstPerson);
            stack.method_22903();model.method_2803(echo.hand,stack);stack.method_22907(class_7833.field_40714.rotationDegrees(-90));stack.method_22907(class_7833.field_40716.rotationDegrees(180));
            stack.method_22904(echo.hand==class_1306.field_6182?-1f/16:1f/16,.125,-.625);
            String part=echo.hand==class_1306.field_6182?"leftItem":"rightItem";
            var pos=echo.animation.get3DTransform(part,TransformType.POSITION,delta,Vec3f.ZERO);var rot=echo.animation.get3DTransform(part,TransformType.ROTATION,delta,Vec3f.ZERO);
            stack.method_46416(pos.getX()/16,pos.getY()/16,pos.getZ()/16);stack.method_22907(class_7833.field_40718.rotation(rot.getZ()));stack.method_22907(class_7833.field_40716.rotation(rot.getY()));stack.method_22907(class_7833.field_40714.rotation(rot.getX()));
            class_4588 vertices=context.consumers().getBuffer(class_1921.method_23580(class_1059.field_5275));
            class_4597 tinted=type->new Tint(vertices,opacity);
            c.method_1480().method_23177(p,new class_1799(KillerRankingMod.PAWN6_KATANA),echo.hand==class_1306.field_6182?class_811.field_4323:class_811.field_4320,
                echo.hand==class_1306.field_6182,stack,tinted,c.field_1687,0xF000F0,class_4608.field_21444,p.method_5628());
            stack.method_22909();stack.method_22909();renderedEchoes++;
        }
    }
    private static void renderUpperBody(class_591<?> model,class_4587 stack,class_4588 vertices,int color,boolean torso){
        // Render only these parts directly: no head/legs and no AgeableListModel baby-body scale.
        // The local first-person camera is inside this torso; keep its arms/sword visible.
        if(torso)model.field_3391.method_22699(stack,vertices,0xF000F0,class_4608.field_21444,color);
        model.field_3401.method_22699(stack,vertices,0xF000F0,class_4608.field_21444,color);
        model.field_27433.method_22699(stack,vertices,0xF000F0,class_4608.field_21444,color);
        if(torso)model.field_3483.method_22699(stack,vertices,0xF000F0,class_4608.field_21444,color);
        model.field_3486.method_22699(stack,vertices,0xF000F0,class_4608.field_21444,color);
        model.field_3484.method_22699(stack,vertices,0xF000F0,class_4608.field_21444,color);
    }
    private record Tint(class_4588 target,float alpha) implements class_4588 {
        public class_4588 method_22912(float x,float y,float z){target.method_22912(x,y,z);return this;}
        public class_4588 method_1336(int r,int g,int b,int a){target.method_1336(r,g,b,(int)(a*alpha));return this;}
        public class_4588 method_22913(float u,float v){target.method_22913(u,v);return this;}
        public class_4588 method_60796(int u,int v){target.method_60796(u,v);return this;}
        public class_4588 method_22921(int u,int v){target.method_22921(u,v);return this;}
        public class_4588 method_22914(float x,float y,float z){target.method_22914(x,y,z);return this;}
    }
    private AutoParryVfx() { }
}
