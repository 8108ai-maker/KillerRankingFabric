package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.WeaponFamily;
import dev.killerranking.network.WeaponHitPayload;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_7833;

/**
 * Camera-facing pixel sprite at every ordinary weapon contact. Each weapon family has its
 * own 8-frame sheet (4x2 grid); slashes lean with the swing and alternate direction so
 * left and right cuts read differently, bursts stay upright.
 */
public final class WeaponHitVfx {
    private static final int FRAMES = 8, COLS = 4, ROWS = 2;
    private static final float LIFE_TICKS = 7f;

    private record Impact(UUID attacker, WeaponFamily family, class_243 position, float roll, float size, boolean lethal, long born, float seed) { }

    private static final List<Impact> IMPACTS = new ArrayList<>();
    private static final Map<UUID, Boolean> SIDE = new HashMap<>();
    private static final Map<WeaponFamily, class_2960> SHEETS = new HashMap<>();
    private static final class_2960 LETHAL = KillerRankingMod.id("textures/vfx/hit_lethal.png");
    private static class_638 world;

    static {
        SHEETS.put(WeaponFamily.BLADE, KillerRankingMod.id("textures/vfx/hit_blade.png"));
        SHEETS.put(WeaponFamily.SAW, KillerRankingMod.id("textures/vfx/hit_saw.png"));
        SHEETS.put(WeaponFamily.BLUNT, KillerRankingMod.id("textures/vfx/hit_blunt.png"));
        SHEETS.put(WeaponFamily.FIST, KillerRankingMod.id("textures/vfx/hit_fist.png"));
        SHEETS.put(WeaponFamily.HATCHET, KillerRankingMod.id("textures/vfx/hit_hatchet.png"));
        SHEETS.put(WeaponFamily.PIERCE, KillerRankingMod.id("textures/vfx/hit_pierce.png"));
        SHEETS.put(WeaponFamily.KNUCKLE, KillerRankingMod.id("textures/vfx/hit_knuckle.png"));
    }

    public static void register() { WorldRenderEvents.AFTER_ENTITIES.register(WeaponHitVfx::render); }

    public static void accept(WeaponHitPayload p) {
        var c = class_310.method_1551();
        if (c.field_1687 == null) return;
        if (world != c.field_1687) { clear(); world = c.field_1687; }
        if (!Double.isFinite(p.x()) || !Double.isFinite(p.y()) || !Double.isFinite(p.z())) return;
        var family = WeaponFamily.byOrdinal(p.family());
        if (family == null) return;
        if (IMPACTS.size() >= 64) IMPACTS.removeFirst();
        boolean slash = family == WeaponFamily.BLADE || family == WeaponFamily.SAW || family == WeaponFamily.HATCHET;
        boolean left = !SIDE.getOrDefault(p.attacker(), false);
        SIDE.put(p.attacker(), left);
        float seed = (float) ((p.x() * 31 + p.z() * 17) % 1.0);
        // Slashes lean ±25° around their diagonal and mirror per swing; bursts only jitter.
        float roll = slash ? (left ? 1 : -1) * (20f + seed * 25f) + (left ? 0 : 90) : seed * 360f;
        float size = switch (family) {
            case BLUNT, HATCHET -> 1.7f;
            case KNUCKLE -> 1.5f;
            case PIERCE, FIST -> 1.15f;
            default -> 1.45f;
        } * (p.crit() ? 1.3f : 1f);
        var at = new class_243(p.x(), p.y(), p.z());
        IMPACTS.add(new Impact(p.attacker(), family, at, roll, size, p.lethal(), world.method_8510(), seed));
        // Shards burst away from the attacker; slashes throw them along the cut, bursts all around.
        var style = TrailStyle.of(family);
        var attacker = c.field_1687.method_18470(p.attacker());
        class_243 away = attacker == null ? new class_243(0, 0.3, 0) : at.method_1020(attacker.method_19538().method_1031(0, 1.2, 0)).method_1029().method_1021(0.6).method_1031(0, 0.35, 0);
        int count = switch (family) { case BLUNT, HATCHET -> 18; case SAW -> 22; case PIERCE -> 10; default -> 14; } + (p.crit() ? 8 : 0) + (p.lethal() ? 14 : 0);
        SlashShardParticle.burst(at, away, count, style.shardColor, 0.32f, 0.42f, 0.09f, 18);
        if (p.lethal()) SlashShardParticle.burst(at, new class_243(0, 0.5, 0), 12, 0xFF3A3A, 0.25f, 0.5f, 0.11f, 26);
        DamageNumberVfx.add(at, p.damage(), family, p.crit(), p.lethal());
        if (p.attacker().equals(c.field_1724 == null ? null : c.field_1724.method_5667())) CombatCameraFeedback.hit(family, p.crit());
    }

    public static void tick(class_310 c) {
        if (c.field_1687 != world) { clear(); world = c.field_1687; return; }
        if (world == null || c.method_1493()) return;
        IMPACTS.removeIf(i -> world.method_8510() - i.born >= LIFE_TICKS + 1);
    }

    public static int activeCount() { return IMPACTS.size(); }
    public static void clear() { IMPACTS.clear(); SIDE.clear(); world = null; }

    private static void render(WorldRenderContext ctx) {
        if (ctx.world() != world || ctx.matrixStack() == null || ctx.consumers() == null || IMPACTS.isEmpty()) return;
        var camera = ctx.camera().method_19326();
        float delta = ctx.tickCounter().method_60637(false);
        for (var i : IMPACTS) {
            if (i.position.method_1025(camera) > 4096) continue;
            float age = world.method_8510() - i.born + delta;
            if (age < 0 || age >= LIFE_TICKS) continue;
            int frame = Math.min(FRAMES - 1, (int) (age * FRAMES / LIFE_TICKS));
            var stack = ctx.matrixStack();
            stack.method_22903();
            stack.method_22904(i.position.field_1352 - camera.field_1352, i.position.field_1351 - camera.field_1351, i.position.field_1350 - camera.field_1350);
            stack.method_22907(ctx.camera().method_23767());
            stack.method_22907(class_7833.field_40718.rotationDegrees(i.roll));
            float half = 0.55f * i.size * (1f + 0.15f * Math.min(1, age / 2f));
            sprite(stack, ctx.consumers().getBuffer(WeaponTrailRenderType.sprite(SHEETS.get(i.family))), half, frame, 1f);
            if (i.lethal) {
                stack.method_22907(class_7833.field_40718.rotationDegrees(-i.roll));
                sprite(stack, ctx.consumers().getBuffer(WeaponTrailRenderType.sprite(LETHAL)), half * 1.6f, frame, 0.9f);
            }
            stack.method_22909();
        }
    }

    private static void sprite(class_4587 stack, class_4588 v, float half, int frame, float alpha) {
        var p = stack.method_23760();
        float u0 = (frame % COLS) / (float) COLS, u1 = u0 + 1f / COLS;
        float v0 = (frame / COLS) / (float) ROWS, v1 = v0 + 1f / ROWS;
        int color = ((int) (Math.clamp(alpha, 0, 1) * 255) << 24) | 0xFFFFFF;
        // Two faces so the quad never culls away when the camera roll flips it.
        float[][] corners = {{-half, -half, u0, v1}, {half, -half, u1, v1}, {half, half, u1, v0}, {-half, half, u0, v0}};
        for (int k = 0; k < 4; k++) v.method_22918(p.method_23761(), corners[k][0], corners[k][1], 0.01f).method_39415(color)
            .method_22913(corners[k][2], corners[k][3]).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(p, 0, 0, 1);
    }

    private WeaponHitVfx() { }
}
