package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.CleaveRules;
import dev.killerranking.network.CleaveStatusPayload;
import net.minecraft.class_2561;
import net.minecraft.class_310;
public final class ClientCleave {
    private static CleaveStatusPayload value;private static int elapsed;
    public static void set(CleaveStatusPayload p){value=p;elapsed=0;}
    public static void clear(){value=null;elapsed=0;}
    public static void tick(){if(value!=null&&elapsed<Integer.MAX_VALUE)elapsed++;}
    public static boolean branch(){return value!=null&&value.branch();}
    public static boolean unlocked(){return value!=null&&value.unlocked();}
    public static boolean otherOwned(){return value!=null&&value.otherOwned();}
    public static int cooldown(){return value==null?0:Math.max(0,value.cooldown()-elapsed);}
    public static int phase(){return value==null?0:value.phase();}
    public static int age(){return value==null?0:value.age()+elapsed;}
    public static float progress(){return !unlocked()?0:phase()==CleaveRules.CHARGING?Math.min(1,age()/(float)CleaveRules.CHARGE):phase()==CleaveRules.SLASHING?Math.max(0,1-age()/(float)CleaveRules.CAST):1-cooldown()/(float)CleaveRules.COOLDOWN;}
    public static class_2561 status(){
        if(phase()==CleaveRules.CHARGING)return class_2561.method_43470(age()>=CleaveRules.CHARGE?"완충 · 놓으면 제자리":"충전 "+CombatHud.seconds(Math.min(age(),CleaveRules.CHARGE)));
        if(phase()==CleaveRules.SLASHING)return class_2561.method_43470("베기");
        if(cooldown()>0)return class_2561.method_43470(CombatHud.seconds(cooldown()));
        if(!TraitVisuals.enabled())return class_2561.method_43470("꺼짐");
        var p=class_310.method_1551().field_1724;if(p!=null&&!p.method_6047().method_31574(KillerRankingMod.PAWN6_KATANA))return class_2561.method_43470("카타나 필요");
        return class_2561.method_43470("준비");
    }
    private ClientCleave() { }
}
