package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.entity.BishopFollower;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_909;
import net.minecraft.class_989;
import net.minecraft.client.renderer.entity.*;

public final class BishopFollowerRenderer extends class_909<BishopFollower,BishopModel> {
    private static final class_2960 TEXTURE=KillerRankingMod.id("textures/entity/bishop_brother.png");
    public BishopFollowerRenderer(class_5617.class_5618 context){
        super(context,new BishopModel(context.method_32167(BishopModel.LAYER)),.35f);
        field_4738.removeIf(layer->layer instanceof class_989);
        method_4046(new BishopCloakLayer(this));
        method_4046(new BishopMaskLayer(this,context.method_32167(BishopMaskLayer.LAYER)));
        method_4046(new BishopDaggerLayer(this,context.method_43338()));
    }
    @Override public class_2960 getTextureLocation(BishopFollower entity){return TEXTURE;}
}
