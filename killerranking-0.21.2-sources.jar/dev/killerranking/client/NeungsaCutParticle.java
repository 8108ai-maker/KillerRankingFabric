package dev.killerranking.client;
import dev.killerranking.network.NeungsaCutEffectPayload;
import java.util.*;
import net.minecraft.class_1309;
import net.minecraft.class_2400;
import net.minecraft.class_310;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

/** Pixel frames stay on each struck victim, including movement during their brief lifetime. */
public final class NeungsaCutParticle extends class_4003 {
    private static class_4002 loaded;
    private static final Set<NeungsaCutParticle> LIVE=new HashSet<>();
    private final class_4002 sprites;
    private final class_1309 target;
    private NeungsaCutParticle(class_638 level,double x,double y,double z,class_4002 sprites,class_1309 target){
        super(level,x,y,z);this.sprites=sprites;this.target=target;field_3847=8;field_3862=false;
        field_17867=target==null?.6f:Math.clamp(target.method_17682()*.42f,.45f,1.6f);
        field_3839=(field_3840.method_43056()?1:-1)*.16f;field_3857=field_3839;method_18142(sprites);
        if(target!=null){follow();field_3858=this.field_3874;field_3838=this.field_3854;field_3856=this.field_3871;LIVE.add(this);}
    }
    private void follow(){
        var center=target.method_19538().method_1031(0,target.method_17682()*.57,0);
        var facing=class_310.method_1551().field_1773.method_19418().method_19326().method_1020(center).method_1029();
        var p=center.method_1019(facing.method_1021(target.method_17681()*.55+.08));method_3063(p.field_1352,p.field_1351,p.field_1350);
    }
    @Override public void method_3070(){
        super.method_3070();if(target!=null){if(target.method_31481()){method_3085();return;}follow();}
        method_18142(sprites);field_3841=Math.min(1,(field_3847-field_3866)/3f);
    }
    @Override public void method_3085(){super.method_3085();LIVE.remove(this);}
    @Override protected int method_3068(float delta){return 0xF000F0;}
    @Override public class_3999 method_18122(){return class_3999.field_17829;}
    public static void emit(NeungsaCutEffectPayload p){
        NeungsaHitCutVfx.emit(p);
    }
    public static boolean active(UUID target){return NeungsaHitCutVfx.active(target);}
    public static void clear(){for(var p:new ArrayList<>(LIVE))p.method_3085();LIVE.clear();NeungsaHitCutVfx.clear();}
    public static final class Provider implements class_707<class_2400>{
        private final class_4002 sprites;public Provider(class_4002 sprites){this.sprites=sprites;loaded=sprites;}
        @Override public class_703 createParticle(class_2400 type,class_638 level,double x,double y,double z,double dx,double dy,double dz){return new NeungsaCutParticle(level,x,y,z,sprites,null);}
    }
}
