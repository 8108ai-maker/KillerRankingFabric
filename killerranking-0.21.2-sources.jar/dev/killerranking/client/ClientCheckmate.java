package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.CombatRules;
import dev.killerranking.combat.CheckmateRules;
import dev.killerranking.network.CheckmateStatusPayload;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class ClientCheckmate {
    private static CheckmateStatusPayload value;
    private static int elapsed;
    public static void set(CheckmateStatusPayload status) { value=status;elapsed=0; }
    public static void clear() { value=null;elapsed=0; }
    public static void tick() { if(value!=null&&elapsed<Integer.MAX_VALUE) elapsed++; }
    public static boolean branch() { return value!=null&&value.branch(); }
    public static boolean unlocked() { return value!=null&&value.unlocked(); }
    public static boolean rushOwned() { return value!=null&&value.rushOwned(); }
    private static boolean aiming() { var p=class_310.method_1551().field_1724;return p!=null&&CheckmateVfx.aiming(p.method_5667()); }
    public static int remaining() { return value==null?0:Math.max(0,value.activeTicks()-elapsed); }
    public static int cooldown() { return value==null?0:Math.max(0,value.cooldownTicks()-elapsed); }
    public static float progress() {
        return !unlocked()?0:aiming()?1:remaining()>0?(float)remaining()/CheckmateRules.DURATION:CombatRules.cooldownProgress(cooldown(),CheckmateRules.COOLDOWN);
    }
    public static class_2561 status() {
        if(!unlocked()) return class_2561.method_43470("해금 1,000P");
        if(aiming()) return class_2561.method_43470(CheckmateVfx.selectedTile()<0?"칸 선택":"놓으면 도약");
        if(remaining()>0) return class_2561.method_43470("내려치기");
        if(cooldown()>0) return class_2561.method_43470(CombatHud.seconds(cooldown()));
        if(!TraitVisuals.enabled()) return class_2561.method_43470("꺼짐");
        var p=class_310.method_1551().field_1724;
        if(p!=null&&!p.method_6047().method_31574(KillerRankingMod.NIGHT_BARBED_BAT)) return class_2561.method_43470("방망이 필요");
        return class_2561.method_43470("준비");
    }
    private ClientCheckmate() { }
}
