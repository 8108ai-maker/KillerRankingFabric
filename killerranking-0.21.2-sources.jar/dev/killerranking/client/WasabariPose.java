package dev.killerranking.client;
import dev.killerranking.visual.WasabariMotion;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_597;
import net.minecraft.class_630;
import dev.killerranking.visual.HeavyPunchGrip;
import dev.killerranking.client.mixin.WasabariQuadrupedAccess;

public final class WasabariPose {
    public static void apply(class_1309 e,class_583<?> base,class_4587 stack,float delta){
        var owner=WasabariVfx.captor(e.method_5667());
        if(base instanceof net.minecraft.class_5597<?> tree&&owner!=null){
            boolean left=owner.method_6068()==class_1306.field_6182;
            boolean inverted=dev.killerranking.combat.RookMountPose.inverted(e);
            // The upside-down body reverses its left/right leg sides, as on QuadrupedModel.
            String[] names=inverted?(left?new String[]{"right_hind_leg","right_back_leg","right_leg"}:new String[]{"left_hind_leg","left_back_leg","left_leg"})
                :(left?new String[]{"left_leg"}:new String[]{"right_leg"});
            for(String name:names){var found=tree.method_41909(name);if(found.isEmpty())continue;
                // Includes parents such as the Warden's bone pivot; these models are not HumanoidModel.
                tree.method_32008().method_32088().forEach(class_630::method_41923);
                var leg=found.get();leg.field_3654=inverted?1.1f*(float)WasabariMotion.grabWeight(WasabariVfx.age(owner.method_5667(),delta)):WasabariMotion.raisedLegPitch(WasabariVfx.age(owner.method_5667(),delta));
                leg.field_3675=leg.field_3674=0;
                WasabariVfx.recordLeg(e,tree,leg,name,stack);return;
            }
        }
        if(base instanceof class_597<?> &&base instanceof WasabariQuadrupedAccess quad&&owner!=null){
            var leg=owner.method_6068()==class_1306.field_6182?quad.wasabari$rightHindLeg():quad.wasabari$leftHindLeg();
            leg.field_3654=.55f*(float)WasabariMotion.grabWeight(WasabariVfx.age(owner.method_5667(),delta));
            leg.field_3675=leg.field_3674=0;WasabariVfx.recordLeg(e,leg,stack);return;
        }
        if(!(base instanceof class_572<?> model))return;
        if(WasabariVfx.active(e.method_5667())){
            var pose=WasabariVfx.heldPose(e,stack,delta);
            set(model.field_3391,pose.torso());set(model.field_3398,pose.head());set(model.field_3401,pose.rightArm());set(model.field_27433,pose.leftArm());set(model.field_3392,pose.rightLeg());set(model.field_3397,pose.leftLeg());
        }else if(WasabariVfx.captured(e.method_5667())){
            model.field_3391.method_2851(0,0,0);model.field_3391.method_33425(0,0,0);model.field_3398.method_2851(0,0,0);model.field_3398.method_33425(0,0,0);
            model.field_3401.method_33425(0,0,.1f);model.field_27433.method_33425(0,0,-.1f);
            model.field_3392.method_33425(0,0,.035f);model.field_3397.method_33425(0,0,-.035f);
            var leg=owner!=null&&owner.method_6068()==class_1306.field_6182?model.field_3397:model.field_3392;
            if(owner!=null){leg.field_3654=WasabariMotion.raisedLegPitch(WasabariVfx.age(owner.method_5667(),delta));leg.field_3674=0;WasabariVfx.recordLeg(e,leg,stack);}
        }else return;
        model.field_3394.method_17138(model.field_3398);
        if(model instanceof class_591<?> p){p.field_3483.method_17138(model.field_3391);p.field_3486.method_17138(model.field_3401);p.field_3484.method_17138(model.field_27433);p.field_3479.method_17138(model.field_3392);p.field_3482.method_17138(model.field_3397);}
    }
    private static void set(class_630 p,HeavyPunchGrip.Limb limb){var at=limb.pivot();var r=limb.rotation();p.method_2851((float)at.field_1352,(float)at.field_1351,(float)at.field_1350);p.method_33425((float)r.field_1352,(float)r.field_1351,(float)r.field_1350);p.field_37938=p.field_37939=p.field_37940=1;}
    private WasabariPose() { }
}
