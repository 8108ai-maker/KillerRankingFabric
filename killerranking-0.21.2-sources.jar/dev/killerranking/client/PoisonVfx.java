package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.network.PoisonVfxPayload;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_4002;
import net.minecraft.class_4066;
import java.util.*;

public final class PoisonVfx {
    private static final Map<UUID, State> ACTIVE = new HashMap<>();
    private static class_4002 sprites;
    private static class_4002 flameSprites;
    private static final class State { int ticks, age; final boolean salmosa; State(int ticks, boolean salmosa) { this.ticks = ticks; this.salmosa = salmosa; } }
    public static void register() {
        ParticleFactoryRegistry.getInstance().register(KillerRankingMod.POISON_AURA, set -> {
            sprites = set;
            return (parameters, world, x, y, z, dx, dy, dz) -> null; // Owner-bound particles are spawned below.
        });
        ParticleFactoryRegistry.getInstance().register(KillerRankingMod.POISON_FLAME, set -> {
            flameSprites = set;
            return (parameters, world, x, y, z, dx, dy, dz) -> null;
        });
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            var client = class_310.method_1551();
            if (context.matrixStack() == null || context.consumers() == null || client.field_1687 == null) return;
            float partial = context.tickCounter().method_60637(false);
            for (var player : visible(client)) {
                var state = ACTIVE.get(player.method_5667());
                float alpha = Math.min(1, (state.age + partial) / 8f) * Math.min(1, (state.ticks - partial) / 8f);
                PoisonSnakeModel.render(context, player, partial, Math.max(0, alpha));
            }
        });
    }
    public static void accept(PoisonVfxPayload payload) {
        if (payload.ticks() == 0) ACTIVE.remove(payload.player());
        else ACTIVE.compute(payload.player(), (id, previous) -> {
            if (previous == null || previous.salmosa != payload.salmosa()) return new State(payload.ticks(), payload.salmosa());
            previous.ticks = payload.ticks(); return previous;
        });
    }
    public static void clear() { ACTIVE.clear(); }
    public static boolean active(UUID id) { return ACTIVE.containsKey(id); }
    public static boolean salmosa(UUID id) { var state=ACTIVE.get(id);return state!=null&&state.salmosa; }
    static int age(UUID id) { var state=ACTIVE.get(id);return state==null?0:state.age; }
    private static List<class_1657> visible(class_310 client) {
        var camera = client.method_1560();
        if (camera == null || client.field_1687 == null) return List.of();
        return ACTIVE.keySet().stream().map(id -> client.field_1687.method_18470(id)).filter(Objects::nonNull)
            .filter(p -> !KillingIntentVfx.hiddenForCamera(p) && p.method_5858(camera) <= 1024)
            .sorted(Comparator.comparingDouble(p -> p.method_5858(camera))).limit(4).toList();
    }
    public static void tick(class_310 client) {
        if (client.method_1493() || client.field_1687 == null) return;
        ACTIVE.values().forEach(s -> { s.ticks--; s.age++; });
        ACTIVE.values().removeIf(s -> s.ticks <= 0);
        var camera=client.method_1560();
        if(camera!=null)for(var entry:ACTIVE.entrySet()){
            var player=client.field_1687.method_18470(entry.getKey());
            if(entry.getValue().age%72==14&&player!=null&&player.method_5805()&&!player.method_5767()&&!player.method_7325()&&player.method_5858(camera)<=256){
                var head=PoisonSnakeModel.headPoint(player,0,0,0,.3f);
                client.field_1687.method_8486(player.method_23317()+head.x,player.method_23318()+head.y,player.method_23321()+head.z,
                    dev.killerranking.KillerRankingSounds.POISON_HISS,
                    net.minecraft.class_3419.field_15248,.45f,1f,false);
            }
        }
        if (sprites == null) return;
        var setting = client.field_1690.method_42475().method_41753();
        int count = setting == class_4066.field_18199 ? 1 : setting == class_4066.field_18198 ? 2 : 4;
        for (var player : visible(client)) {
            for (int i = 0; i < count; i++) client.field_1713.method_3058(new PoisonAuraParticle(client.field_1687, player, sprites, player.method_59922().method_43057() < .25f));
            if (flameSprites != null && (setting != class_4066.field_18199 || player.field_6012 % 2 == 0)) {
                int eyeCount = setting == class_4066.field_18197 ? 2 : 1;
                for (int i = 0; i < eyeCount; i++) {
                    boolean orange = (i + player.field_6012) % 3 == 0;
                    client.field_1713.method_3058(new PoisonFlameParticle(client.field_1687, player, flameSprites, -1, orange));
                    client.field_1713.method_3058(new PoisonFlameParticle(client.field_1687, player, flameSprites, 1, orange));
                }
            }
        }
    }
    private PoisonVfx() { }
}
