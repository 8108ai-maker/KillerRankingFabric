package dev.killerranking.client;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.visual.BatTrailHistory;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4066;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_811;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Records the final item matrix, including wrist, handedness and other animation mods. */
public final class NightBatTrail {
    private record Key(UUID player,boolean left,class_1792 item) { }
    private record Capture(class_1309 player,boolean left) { }
    private static final Map<Key,BatTrailHistory> HISTORY=new HashMap<>();
    private static final Map<UUID,class_1309> OWNERS=new HashMap<>();
    private static final Matrix4f VIEW_INVERSE=new Matrix4f();
    private static class_638 world;
    private static Capture capture;
    private static class_243 camera=class_243.field_1353;
    private static double time;
    private static float delta;
    private static boolean frameReady;

    public static void register() {
        WorldRenderEvents.START.register(context->{
            if(world!=context.world()) { clear();world=context.world(); }
            VIEW_INVERSE.set(context.positionMatrix()).invert();
            camera=context.camera().method_19326();
            delta=context.tickCounter().method_60637(false);
            time=world.method_8510()+delta;frameReady=true;
        });
        WorldRenderEvents.AFTER_ENTITIES.register(NightBatTrail::render);
        ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->clear());
        ClientPlayConnectionEvents.JOIN.register((handler,sender,client)->clear());
    }
    public static void begin(class_1309 entity,class_1799 item,class_811 display,boolean left) {
        capture=null;
        if(!frameReady||!supported(item)||!(entity instanceof class_742||entity instanceof dev.killerranking.entity.BishopFollower)
            ||world!=entity.method_37908()||!entity.method_5805()||entity.method_5767()||entity.method_7325()
            ||entity.method_6115()||RushVfx.active(entity.method_5667())||entity.method_19538().method_1025(camera)>1024) return;
        if(display!=class_811.field_4323&&display!=class_811.field_4320
            &&display!=class_811.field_4321&&display!=class_811.field_4322) return;
        capture=new Capture(entity,left);
    }
    public static void end() { capture=null; }
    public static void sample(class_1799 item,class_4587 pose) {
        if(capture==null||!supported(item)||class_310.method_1551().method_1493()) return;
        var c=capture;
        Vec3f marker;
        if(c.player() instanceof class_742 player)marker=PlayerAnimationAccess.getPlayerAnimLayer(player).get3DTransform("nightBatTrail",TransformType.POSITION,delta,Vec3f.ZERO);
        else if(c.player() instanceof dev.killerranking.entity.BishopFollower bishop)marker=((BishopFollowerRenderer)class_310.method_1551().method_1561().method_3953(bishop)).method_4038().trail();
        else marker=Vec3f.ZERO;
        float gate=marker.getY();
        var key=new Key(c.player().method_5667(),c.left(),item.method_7909());
        var history=HISTORY.get(key);
        // Every authored strike gate works with native-size arms, including skills and mobs.
        boolean striking=gate>.25f;
        if(item.method_31574(KillerRankingMod.NEUNGSA_KATANA)&&c.player() instanceof class_742 player) {
            var cut=PlayerAnimationAccess.getPlayerAnimLayer(player).get3DTransform("neungsaCut",TransformType.POSITION,delta,Vec3f.ZERO);
            // Include the approach and follow-through of the authored cut, not
            // just its narrow damage window. The visible arc grows with the sword.
            float progress=Math.abs(cut.getX());
            striking=cut.getZ()>.5f&&progress>=8.5f&&progress<=18;
        }
        if(!striking) { if(history!=null) history.resetStroke();return; }
        if(history==null) {
            if(HISTORY.size()>=48) return;
            history=new BatTrailHistory(item.method_31574(KillerRankingMod.NEUNGSA_KATANA));HISTORY.put(key,history);
        }
        // World renders use the world view; first-person renders can use a different
        // model-view. Convert both to stable world coordinates before storing points.
        var matrix=new Matrix4f(VIEW_INVERSE).mul(RenderSystem.getModelViewMatrix()).mul(pose.method_23760().method_23761());
        class_243 inner,tip;
        if(item.method_31574(KillerRankingMod.GOSSI_INHERITED_KNIFE)) {
            inner=point(matrix,8/16f,9/16f,8/16f);tip=point(matrix,8/16f,20.5f/16f,8/16f);
        } else if(item.method_31574(KillerRankingMod.SALMOSA_MID_DAGGER)) {
            inner=point(matrix,8/16f,dev.killerranking.visual.SalmosaKnifeGeometry.BLADE_BASE/16,8/16f);tip=point(matrix,8/16f,dev.killerranking.visual.SalmosaKnifeGeometry.TIP/16,8/16f);
        } else if(item.method_31574(KillerRankingMod.EUNBAL_HATCHET)) {
            inner=point(matrix,12/16f,12/16f,8/16f);tip=point(matrix,15.5f/16f,16/16f,8/16f);
        } else if(item.method_31574(KillerRankingMod.NEUNGSA_KATANA)) {
            inner=point(matrix,8.5f/16f,10.6f/16f,8/16f);tip=point(matrix,8.53906f/16f,31.87934f/16f,8/16f);
        } else if(item.method_31574(KillerRankingMod.PAWN6_KATANA)) {
            inner=point(matrix,8/16f,9.4f/16f,8/16f);tip=point(matrix,7.91675f/16f,31.60590f/16f,8/16f);
        } else if(item.method_31574(KillerRankingMod.YUHYEOLMOKI_SAW_KNIFE)) {
            inner=point(matrix,8/16f,6/16f,8/16f);tip=point(matrix,7.17500f/16f,29.89648f/16f,8/16f);
        } else if(item.method_31574(KillerRankingMod.BISHOP_DAGGER)){
            inner=point(matrix,8/16f,8.4f/16f,8/16f);tip=point(matrix,8/16f,25.2f/16f,8/16f);
            // Keep the short dagger model; extend only its anime cutting ribbon.
            var blade=tip.method_1020(inner);tip=inner.method_1019(blade.method_1021(2.4));inner=inner.method_1020(blade.method_1021(.15));
        } else {
            inner=point(matrix,8/16f,15/16f,8/16f);tip=point(matrix,8/16f,30/16f,8/16f);
        }
        if(!Double.isFinite(tip.field_1352+tip.field_1351+tip.field_1350)||tip.method_1025(c.player().method_19538())>36) return;
        var style=TrailStyle.of(item.method_7909());
        class_243 modelTip=tip;
        {
            // The sweep reads far larger than the model: push the outer edge past the tip and the
            // inner edge back toward the hand, so a 100° swing becomes a 2–3 block pixel arc.
            var blade=tip.method_1020(inner);double length=blade.method_1033();
            if(length>1e-4) { var unit=blade.method_1021(1/length);tip=tip.method_1019(unit.method_1021(style.tipExtension));inner=inner.method_1020(unit.method_1021(style.innerPull)); }
        }
        OWNERS.put(c.player().method_5667(),c.player());
        shards(key,style,modelTip,inner,tip);
        if(c.player() instanceof dev.killerranking.entity.BishopFollower||CheckmateVfx.active(c.player().method_5667())||CleaveVfx.active(c.player().method_5667())||MadnessLeapVfx.active(c.player().method_5667()))
            history.sampleStroke(time,inner,tip,c.player().method_30950(delta),true,(int)Math.ceil(Math.abs(marker.getX())));
        else history.sample(time,inner,tip,c.player().method_30950(delta),true);
    }
    public static void hand(class_742 player,boolean left,class_4587 pose,float center,Vec3f marker){
        if(!frameReady||world!=player.method_37908()||class_310.method_1551().method_1493()||player.method_5767()||player.method_19538().method_1025(camera)>1024)return;
        var key=new Key(player.method_5667(),left,null);var history=HISTORY.get(key);
        if(marker.getY()<=.25){if(history!=null)history.resetStroke();return;}
        if(history==null){if(HISTORY.size()>=48)return;history=new BatTrailHistory();HISTORY.put(key,history);}
        var matrix=new Matrix4f(VIEW_INVERSE).mul(RenderSystem.getModelViewMatrix()).mul(pose.method_23760().method_23761());
        var inner=point(matrix,center/16,7.5f/16,0);var tip=point(matrix,center/16,11.5f/16,0);
        if(!Double.isFinite(tip.field_1352+tip.field_1351+tip.field_1350)||tip.method_1025(player.method_19538())>36)return;
        OWNERS.put(player.method_5667(),player);history.sampleStroke(time,inner,tip,player.method_30950(delta),true,(int)Math.ceil(Math.abs(marker.getX())));
    }
    private static final Map<Key,class_243> LAST_TIP=new HashMap<>();
    private static final Map<Key,Double> LAST_SHARD=new HashMap<>();
    /** Throw weapon-coloured shards off the moving blade: a few per accepted sample, along its motion. */
    private static void shards(Key key,TrailStyle style,class_243 modelTip,class_243 inner,class_243 tip) {
        double lastTime=LAST_SHARD.getOrDefault(key,-1d);
        if(lastTime>=0&&time-lastTime<.25) return;
        var last=LAST_TIP.put(key,modelTip);
        LAST_SHARD.put(key,time);
        if(last==null||lastTime<0||time-lastTime>3) return;
        var motion=modelTip.method_1020(last);
        double travel=motion.method_1033();
        if(travel<.05||travel>2.5) return;
        var dir=motion.method_1021(1/travel);
        var span=tip.method_1020(inner);
        for(int i=0;i<style.shardsPerSample;i++) {
            double u=.35+Math.random()*.65;
            var at=inner.method_1019(span.method_1021(u));
            SlashShardParticle.burst(at,dir,1,style.shardColor,.10f+(float)travel*.08f,.06f,.07f,14);
        }
    }
    private static class_243 point(Matrix4f matrix,float x,float y,float z) {
        var p=matrix.transformPosition(new Vector3f(x,y,z));return new class_243(p.x+camera.field_1352,p.y+camera.field_1351,p.z+camera.field_1350);
    }
    private static void render(WorldRenderContext context) {
        if(context.matrixStack()==null||context.consumers()==null) return;
        var stack=context.matrixStack();
        class_4588 vertices=null;
        boolean minimal=class_310.method_1551().field_1690.method_42475().method_41753()==class_4066.field_18199;
        for(var iterator=HISTORY.entrySet().iterator();iterator.hasNext();) {
            var entry=iterator.next();var p=OWNERS.get(entry.getKey().player());
            if(p==null||p.method_37908()!=world||p.method_31481()||!p.method_5805()||p.method_5767()||p.method_7325()||p.method_5707(camera)>1024) { iterator.remove();continue; }
            var held=(p.method_6068()==class_1306.field_6182)==entry.getKey().left()?p.method_6047():p.method_6079();
            if(entry.getKey().item()!=null&&(!held.method_31574(entry.getKey().item())||RushVfx.active(p.method_5667()))) { iterator.remove();continue; }
            var ribbons=entry.getValue().visible(time);
            if(ribbons.isEmpty()) { if(entry.getValue().canDiscard(time)) iterator.remove();continue; }
            var style=TrailStyle.of(entry.getKey().item());
            boolean neungsa=style==TrailStyle.NEUNGSA;
            vertices=context.consumers().getBuffer(WeaponTrailRenderType.of(style));
            for(var ribbon:ribbons) {
                double age=Math.max(0,time-ribbon.born());
                int frame=ribbon.frame(time);
                if(frame<0) continue;
                float alpha=style.alpha*(float)(neungsa?Math.max(0,1-age/BatTrailHistory.LIFETIME):Math.min(1,(BatTrailHistory.LIFETIME-age)/1.25));
                var points=ribbon.points();double start=points.getFirst().distance();
                double length=points.getLast().distance()-start;if(length<.001) continue;
                if(neungsa) frame=age<.6?(length<.35?0:length<.9?1:length<1.6?2:3):Math.clamp(4+(int)((age-.6)*4/(BatTrailHistory.LIFETIME-.6)),4,7);
                int step=minimal?2:1;
                for(int i=0;i<points.size()-1;i+=step) {
                    var a=points.get(i);var b=points.get(Math.min(i+step,points.size()-1));
                    float u0=(float)((a.distance()-start)/length),u1=(float)((b.distance()-start)/length);
                    // The live leading edge stays attached to the blade. Once the
                    // cut ends, erase the oldest part first instead of blinking
                    // the entire ribbon out while the sword is still moving.
                    if(neungsa) {
                        float tail=(float)Math.max(0,(age-1)/(BatTrailHistory.LIFETIME-1));
                        if(u1<=tail) continue;
                        if(u0<tail) {
                            double t=(tail-u0)/(u1-u0);
                            a=new BatTrailHistory.Point(a.inner().method_35590(b.inner(),t),a.tip().method_35590(b.tip(),t),a.distance()+(b.distance()-a.distance())*t);
                            u0=tail;
                        }
                    }
                    quad(stack,vertices,a,b,u0,u1,frame,alpha,neungsa);
                }
            }
        }
        OWNERS.keySet().removeIf(id->HISTORY.keySet().stream().noneMatch(key->key.player().equals(id)));
    }
    private static void quad(class_4587 stack,class_4588 v,BatTrailHistory.Point a,BatTrailHistory.Point b,float u0,float u1,int frame,float alpha,boolean neungsa) {
        var pose=stack.method_23760();
        class_243 ai=a.inner(),at=a.tip(),bi=b.inner(),bt=b.tip();
        class_243 across=at.method_1020(ai),along=bt.method_1020(at);
        double areaScale=across.method_1027()*along.method_1027();
        if(areaScale<1e-16) return;
        class_243 normal=across.method_1036(along);
        if(!neungsa&&normal.method_1027()<areaScale*.0004) {
            // A straight thrust has no swept blade plane: give its tip path a
            // small camera-facing width instead of an invisible zero-area quad.
            class_243 direction=bt.method_1020(at).method_1029();
            class_243 side=direction.method_1036(camera.method_1020(at)).method_1029().method_1021(.08);
            if(side.method_1027()<.00001) return;
            ai=at.method_1020(side);at=at.method_1019(side);bi=bt.method_1020(side);bt=bt.method_1019(side);
            normal=at.method_1020(ai).method_1036(bt.method_1020(at));
        }
        normal=normal.method_1029();
        // Eight strip frames occupy consecutive rows in the texture.
        float v0=(frame+.015625f)/BatTrailHistory.FRAMES,v1=(frame+.984375f)/BatTrailHistory.FRAMES;
        var corners=new class_243[]{ai,at,bt,bi};
        for(int i=0;i<4;i++) {
            class_243 c=corners[i].method_1020(camera);
            v.method_22918(pose.method_23761(),(float)c.field_1352,(float)c.field_1351,(float)c.field_1350)
                .method_22915(1,1,1,neungsa?alpha*(.65f+.35f*(i<2?u0:u1)):alpha).method_22913(i<2?u0:u1,i==0||i==3?v1:v0)
                .method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(pose,(float)normal.field_1352,(float)normal.field_1351,(float)normal.field_1350);
        }
    }
    public static int segmentCount() { return HISTORY.values().stream().flatMap(h->h.visible(time).stream()).mapToInt(r->r.points().size()-1).sum(); }
    public static int segmentCount(UUID entity){return HISTORY.entrySet().stream().filter(e->e.getKey().player().equals(entity)).flatMap(e->e.getValue().visible(time).stream()).mapToInt(r->r.points().size()-1).sum();}
    public static int strokeCount(UUID entity){return HISTORY.entrySet().stream().filter(e->e.getKey().player().equals(entity)).mapToInt(e->e.getValue().visible(time).size()).sum();}
    public static int handSegmentCount(UUID entity,boolean left){return HISTORY.entrySet().stream().filter(e->e.getKey().player().equals(entity)&&e.getKey().item()==null&&e.getKey().left()==left).flatMap(e->e.getValue().visible(time).stream()).mapToInt(r->r.points().size()-1).sum();}
    private static boolean supported(class_1799 item) {
        return item.method_31574(KillerRankingMod.SALMOSA_MID_DAGGER)||item.method_31574(KillerRankingMod.BISHOP_DAGGER)||item.method_31574(KillerRankingMod.NIGHT_BARBED_BAT)||item.method_31574(KillerRankingMod.GOSSI_INHERITED_KNIFE)||item.method_31574(KillerRankingMod.EUNBAL_HATCHET)||item.method_31574(KillerRankingMod.PAWN6_KATANA)||item.method_31574(KillerRankingMod.NEUNGSA_KATANA)||item.method_31574(KillerRankingMod.YUHYEOLMOKI_SAW_KNIFE);
    }
    private static void clear() { HISTORY.clear();OWNERS.clear();LAST_TIP.clear();LAST_SHARD.clear();SkillArmTrails.clear();capture=null;frameReady=false;world=null; }
    private NightBatTrail() { }
}
