package dev.killerranking.client;

import dev.killerranking.KillerRankingSounds;
import net.minecraft.class_1109;
import net.minecraft.class_1144;
import net.minecraft.class_310;

/** Non-positional UI feedback for the phone and its panels. */
final class UiSounds {
    static void click(class_1144 manager) { manager.method_4873(class_1109.method_4757(KillerRankingSounds.UI_CLICK, 1.0F, 0.9F)); }
    static void open() { class_310.method_1551().method_1483().method_4873(class_1109.method_4757(KillerRankingSounds.UI_OPEN, 1.0F, 0.8F)); }
    static void close() { class_310.method_1551().method_1483().method_4873(class_1109.method_4757(KillerRankingSounds.UI_CLOSE, 1.0F, 0.8F)); }
    static void deny() { class_310.method_1551().method_1483().method_4873(class_1109.method_4757(KillerRankingSounds.UI_DENY, 1.0F, 0.8F)); }
    private UiSounds() { }
}
