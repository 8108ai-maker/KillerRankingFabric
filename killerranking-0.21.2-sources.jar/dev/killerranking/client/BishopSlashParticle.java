package dev.killerranking.client;
import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;

/** Six authored pixel frames flash briefly at the dagger's impact. */
public final class BishopSlashParticle extends class_4003 {
    private final class_4002 sprites;
    private BishopSlashParticle(class_638 level,double x,double y,double z,class_4002 sprites){
        super(level,x,y,z);this.sprites=sprites;field_3847=6;field_17867=.4f;field_3862=false;method_18142(sprites);
    }
    @Override public void method_3070(){super.method_3070();method_18142(sprites);field_3841=1-field_3866/(float)field_3847;}
    @Override protected int method_3068(float delta){return 0xF000F0;}
    @Override public class_3999 method_18122(){return class_3999.field_17829;}
    public static final class Provider implements class_707<class_2400>{
        private final class_4002 sprites;public Provider(class_4002 sprites){this.sprites=sprites;}
        @Override public class_703 createParticle(class_2400 type,class_638 level,double x,double y,double z,double dx,double dy,double dz){return new BishopSlashParticle(level,x,y,z,sprites);}
    }
}
