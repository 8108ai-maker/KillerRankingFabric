package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5697;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_811;

/** The skill's temporary dagger is visual only; inventory and equipment are preserved. */
public final class WasabariKnifeLayer extends class_5697<class_742,class_591<class_742>> {
    private static long rendered;
    public static long renderedKnives(){return rendered;}
    public WasabariKnifeLayer(class_3883<class_742,class_591<class_742>> parent,class_759 items){super(parent,items);}
    @Override public void render(class_4587 pose,class_4597 buffers,int light,class_742 p,float swing,float amount,float delta,float age,float yaw,float pitch){
        float time=WasabariVfx.age(p.method_5667(),delta);if(!WasabariVfx.active(p.method_5667())||time<22||time>=60||p.method_5767())return;
        var arm=p.method_6068();boolean left=arm==class_1306.field_6182;var direction=WasabariVfx.knifeDirection(p,pose);pose.method_22903();method_17165().method_2803(arm,pose);
        // Handle remains in the palm; the blade points inward through the side of the held shin.
        float centre=HeavyPunchPose.center(p);
        var part=left?method_17165().field_27433:method_17165().field_3401;
        var local=new org.joml.Matrix4f().rotateZYX(part.field_3674,part.field_3675,part.field_3654).invert()
            .transformDirection(new org.joml.Vector3f((float)direction.field_1352,(float)direction.field_1351,(float)direction.field_1350));
        pose.method_22904((left?centre:-centre)/16,10.0/16,0);
        pose.method_22907(new org.joml.Quaternionf().rotationTo(new org.joml.Vector3f(0,1,0),local.normalize()));
        float size=dev.killerranking.visual.SalmosaKnifeGeometry.SKILL_SCALE;
        pose.method_46416(0,(8-dev.killerranking.visual.SalmosaKnifeGeometry.PALM)*size/16,0);pose.method_22905(size,size,size);
        WasabariVfx.recordKnife(p.method_5667(),pose);
        class_310.method_1551().method_1480().method_23177(p,new class_1799(KillerRankingMod.SALMOSA_MID_DAGGER),class_811.field_4315,false,pose,buffers,p.method_37908(),light,class_4608.field_21444,p.method_5628());pose.method_22909();rendered++;
    }
}
