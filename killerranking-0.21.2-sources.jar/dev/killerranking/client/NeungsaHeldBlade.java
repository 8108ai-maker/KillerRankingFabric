package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3881;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.joml.Quaternionf;

/** The palm owns the hilt pivot, including crossfades and first-person rendering. */
public final class NeungsaHeldBlade {
    // An untracked item channel is still holding the katana. Fading toward
    // zero Euler angles would rotate it independently of the rendered fist.
    private static final Vec3f RIGHT_GRIP = new Vec3f(-1.240704479f, -0.295051218f, 2.249155638f);
    private static final Vec3f LEFT_GRIP = new Vec3f(-1.240704479f, 0.295051218f, -2.249155638f);
    public static boolean hidden(class_742 player) {
        var id=player.method_5667();
        return RushVfx.active(id)||HeavyPunchVfx.active(id)||RookVfx.active(id)
            ||WasabariVfx.active(id)||ShoulderStabVfx.casting(id);
    }
    public static void attach(class_3881 model, class_742 player, class_1306 arm,
                              class_4587 pose, float delta) {
        model.method_2803(arm, pose);
        pose.method_22904(arm == class_1306.field_6182 ? 1.0 / 16 : -1.0 / 16, 10.0 / 16, 0);
        var layer = PlayerAnimationAccess.getPlayerAnimLayer(player);
        Vec3f wrist = layer.get3DTransform(arm == class_1306.field_6182 ? "leftItem" : "rightItem",
            TransformType.ROTATION, delta, arm == class_1306.field_6182 ? LEFT_GRIP : RIGHT_GRIP);
        pose.method_22907(new Quaternionf().rotationZYX(wrist.getZ(), wrist.getY(), wrist.getX()));
        // Mirroring a proper rotation reverses the blade's local +X edge.
        if (arm == class_1306.field_6182) pose.method_22907(class_7833.field_40716.rotationDegrees(180));
        pose.method_22905(.9f, .9f, .9f);
    }

    public static void render(class_3881 model, class_742 player, class_1799 stack,
                              class_1306 arm, class_4587 pose, class_4597 buffers, int light) {
        var minecraft = class_310.method_1551();
        float delta = minecraft.method_60646().method_60637(false);
        pose.method_22903();
        attach(model, player, arm, pose, delta);
        var display = arm == class_1306.field_6182 ? class_811.field_4323 : class_811.field_4320;
        var baked = minecraft.method_1480().method_4019(stack, player.method_37908(), player, player.method_5628());
        if(NeungsaIaidoVfx.active(player.method_5667())&&!NeungsaIaidoVfx.full(player.method_5667())&&NeungsaKatanaVisuals.sheathed(player,delta)<.5f)
            baked=((net.fabricmc.fabric.api.client.model.loading.v1.FabricBakedModelManager)minecraft.method_1554()).getModel(KillerRankingMod.id("item/neungsa_katana_iaido"));
        NightBatTrail.begin(player, stack, display, arm == class_1306.field_6182);
        try {
            // NONE has identity display transform. ItemRenderer centers (8,8,8),
            // exactly the grip pivot; no independently blended item position.
            minecraft.method_1480().method_23179(stack, class_811.field_4315, false, pose, buffers,
                light, class_4608.field_21444, baked);
        } finally {
            NightBatTrail.end();
            pose.method_22909();
        }
    }

    private NeungsaHeldBlade() { }
}
