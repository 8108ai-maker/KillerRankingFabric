package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.visual.FirstPersonWeaponPose;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import net.fabricmc.fabric.api.client.model.loading.v1.FabricBakedModelManager;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.joml.Quaternionf;

/** Inventory swords occupy distinct body-mounted slots; drawing leaves an empty saya. */
public final class NeungsaSayaLayer extends class_3887<class_742, class_591<class_742>> {
    public NeungsaSayaLayer(class_3883<class_742, class_591<class_742>> parent) { super(parent); }

    @Override public void render(class_4587 pose, class_4597 buffers, int light, class_742 player,
                                float swing, float amount, float delta, float age, float yaw, float pitch) {
        if (player.method_5767() || player.method_7325() || NeungsaHeldBlade.hidden(player)) return;
        var slots = ClientKatanaHolsters.slots(player);
        slot(pose,buffers,light,player,slots.waist(),false,delta);
        slot(pose,buffers,light,player,slots.back(),true,delta);
    }

    private void slot(class_4587 pose, class_4597 buffers, int light, class_742 player,
                      class_1799 sword, boolean back, float delta) {
        if (sword == null || sword.method_7960()) return;
        boolean neungsa = sword.method_31574(KillerRankingMod.NEUNGSA_KATANA);
        boolean pawn = sword.method_31574(KillerRankingMod.PAWN6_KATANA);
        boolean held = player.method_6047().method_31574(sword.method_7909()) || !neungsa && player.method_6079().method_31574(sword.method_7909());
        if (FirstPersonWeaponView.active() && (back || !neungsa || !held)) return;
        boolean left = player.method_6068() == class_1306.field_6182;
        pose.method_22903();
        if (neungsa && player.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA) && !back && (NeungsaIaidoVfx.full(player.method_5667())||NeungsaEchoVfx.active(player.method_5667()))) {
            // The actual opposite palm owns the saya, just as the sword palm
            // owns the blade. Both shoulder pivots stay on the native body.
            var opposite=left?class_1306.field_6183:class_1306.field_6182;
            method_17165().method_2803(opposite,pose);
            pose.method_22904(left?-1.0/16:1.0/16,10.0/16,0);
            var layer=PlayerAnimationAccess.getPlayerAnimLayer(player);
            var wrist=layer.get3DTransform(left?"rightItem":"leftItem",TransformType.ROTATION,delta,Vec3f.ZERO);
            float grab=layer.get3DTransform("neungsaSaya",TransformType.POSITION,delta,Vec3f.ZERO).getY();
            pose.method_22907(new Quaternionf().rotationZYX(wrist.getZ(),wrist.getY(),wrist.getX()));
            pose.method_46416(0,-grab/16,0);
            pose.method_22905(.9f,.9f,.9f);
            if(left)pose.method_22907(class_7833.field_40716.rotationDegrees(180));
        } else if (neungsa && player.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA) && !back && NeungsaKatanaVisuals.sheathed(player,delta) > .999f) {
            NeungsaHeldBlade.attach(method_17165(),player,player.method_6068(),pose,delta);
        } else {
            if (!FirstPersonWeaponView.active()) method_17165().field_3391.method_22703(pose);
            if (back) {
                pose.method_46416((left ? -2 : 2) / 16f,-3 / 16f,3.8f / 16);
                pose.method_22907(new Quaternionf().rotationZYX(left ? .40f : -.40f,0,.07f));
            } else {
                boolean charged = NeungsaIaidoVfx.phase(player.method_5667())==dev.killerranking.combat.NeungsaIaidoRules.CHARGING||NeungsaIaidoVfx.full(player.method_5667());
                if(FirstPersonWeaponView.active()&&charged)pose.method_46416((left?4:-4)/16f,-.5f/16,-10/16f);
                else {
                    float viewY = FirstPersonWeaponView.active() ? FirstPersonWeaponPose.NEUNGSA_VIEW_DOWN : 0;
                    float viewZ = FirstPersonWeaponView.active() ? -FirstPersonWeaponPose.NEUNGSA_VIEW_FORWARD : 0;
                    pose.method_46416((left ? -4.7f : 4.7f) / 16,(10 + viewY) / 16,(-4.4f + viewZ) / 16);
                }
                pose.method_22907(new Quaternionf().rotationZYX(left ? .1650423f : -.1650423f,left ? -.2467399f : .2467399f,1.3809345f));
            }
            pose.method_22905(.9f,.9f,.9f);
            if (left) pose.method_22907(class_7833.field_40716.rotationDegrees(180));
        }
        var minecraft = class_310.method_1551();
        var manager = (FabricBakedModelManager)minecraft.method_1554();
        var saya = manager.getModel(KillerRankingMod.id("item/" + (neungsa ? "neungsa" : "pawn6") + "_katana_saya"));
        minecraft.method_1480().method_23179(sword,class_811.field_4315,false,pose,buffers,light,class_4608.field_21444,saya);
        if (!held) {
            var hilt = neungsa || pawn ? manager.getModel(KillerRankingMod.id("item/" + (neungsa ? "neungsa" : "pawn6") + "_katana_sheathed"))
                : minecraft.method_1480().method_4019(sword,player.method_37908(),null,player.method_5628());
            minecraft.method_1480().method_23179(sword,class_811.field_4315,false,pose,buffers,light,class_4608.field_21444,hilt);
        }
        pose.method_22909();
    }
}
