package dev.killerranking.client;

import dev.killerranking.combat.SpiritBranch;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_7833;

/** Calligraphic fighting-spirit character, rasterized once from a brush typeface. */
final class SpiritGlyph {
    private static final class_2960 TEXTURE = class_2960.method_60655("killerranking", "textures/vfx/tteokbal_kanji.png");
    private static final class_1921 LAYER = class_1921.method_42600(TEXTURE);
    private static final class_1921 CORE = class_1921.method_23580(TEXTURE);
    static void render(WorldRenderContext context, class_1657 player, float delta, float alpha, SpiritBranch branch) {
        var pose = context.matrixStack();
        var camera = context.camera().method_19326();
        float time = player.field_6012 + delta;
        float yaw = class_3532.method_17821(delta, player.field_6220, player.field_6283);
        pose.method_22903();
        pose.method_22904(class_3532.method_16436(delta, player.field_6038, player.method_23317()) - camera.field_1352,
            class_3532.method_16436(delta, player.field_5971, player.method_23318()) - camera.field_1351,
            class_3532.method_16436(delta, player.field_5989, player.method_23321()) - camera.field_1350);
        pose.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
        pose.method_22904(Math.sin(time * .025) * .025, 1.67 + Math.sin(time * .04) * .035, -.95);
        double radians = Math.toRadians(yaw);
        boolean back = (camera.field_1352 - player.method_23317()) * -Math.sin(radians) + (camera.field_1350 - player.method_23321()) * Math.cos(radians) < 0;
        if (back) pose.method_22907(class_7833.field_40716.rotationDegrees(180));
        float pulse = alpha * (.92f + .08f * (float) Math.sin(time * .06)) * (back ? .85f : 1);
        var vertices = context.consumers().getBuffer(LAYER);
        boolean white = branch == SpiritBranch.KING_AND_KILL;
        quad(context, vertices, 3.40f, 3.88f, -.02f, white ? 0xC5C5C5 : 0x25CE4C, pulse * .12f);
        quad(context, vertices, 3.28f, 3.74f, -.01f, white ? 0xEBEBEB : 0x4BE666, pulse * .24f);
        // The main strokes write depth, so the denser smoke stays behind the character.
        quad(context, context.consumers().getBuffer(CORE), 3.20f, 3.65f, 0, white ? 0xFFFFFF : 0xBDFFAA, pulse * .94f);
        pose.method_22909();
    }
    private static void quad(WorldRenderContext context, class_4588 v, float width, float height,
            float z, int color, float alpha) {
        var pose = context.matrixStack().method_23760();
        float[] x = {-width/2, width/2, width/2, -width/2};
        float[] y = {-height/2, -height/2, height/2, height/2};
        for (int i=0; i<4; i++) v.method_22918(pose.method_23761(), x[i], y[i], z)
            .method_22915((color >> 16 & 255)/255f, (color >> 8 & 255)/255f, (color & 255)/255f, alpha)
            .method_22913(i == 0 || i == 3 ? 0 : 1, i < 2 ? 1 : 0)
            .method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(pose, 0, 1, 0);
    }
    private SpiritGlyph() { }
}
