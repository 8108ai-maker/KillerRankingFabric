package dev.killerranking.client;

import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

/** Cloth wraps the rigid hand at native size when Rush hides held items. */
final class FistBandages {
    private static final class_2960 CLOTH=class_2960.method_60656("textures/block/white_wool.png");

    static void render(class_4587 stack,class_4597 buffers,boolean slim,float center,
                       int light,int overlay,int color) {
        var v=buffers.getBuffer(class_1921.method_23580(CLOTH));var pose=stack.method_23760();
        float radius=slim?1.82f:2.32f;
        // Broad, overlapping wraps leave the player's fingertips and sleeve visible.
        for(int band=0;band<6;band++) {
            float y0=6.4f+band*.84f,y1=y0+.98f;
            float r=radius+(band%2==0?.07f:0);
            float[][] faces={
                {-r,y0,-r,r,y0,-r,r,y1,-r,-r,y1,-r},
                {r,y0,r,-r,y0,r,-r,y1,r,r,y1,r},
                {-r,y0,r,-r,y0,-r,-r,y1,-r,-r,y1,r},
                {r,y0,-r,r,y0,r,r,y1,r,r,y1,-r}
            };
            float[][] normals={{0,0,-1},{0,0,1},{-1,0,0},{1,0,0}};
            for(int face=0;face<4;face++)for(int i=0;i<4;i++) {
                float x=faces[face][i*3],y=faces[face][i*3+1],z=faces[face][i*3+2];
                x+=center;
                var normal=normals[face];
                v.method_22918(pose.method_23761(),x/16,y/16,z/16).method_39415(color)
                    .method_22913(i==0||i==3?0:1,(i<2?0:1)*.25f+band*.1f)
                    .method_22922(overlay).method_60803(light)
                    .method_60831(pose,normal[0],normal[1],normal[2]);
            }
        }
    }
    private FistBandages() { }
}
