package dev.killerranking.client;
import dev.killerranking.combat.RookRules;
import dev.killerranking.network.RookStatusPayload;
import java.util.Comparator;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class ClientRook {
    private static RookStatusPayload value;private static int elapsed;
    public static void set(RookStatusPayload status){value=status;elapsed=0;}
    public static void clear(){value=null;elapsed=0;}
    public static void tick(){if(value!=null&&elapsed<Integer.MAX_VALUE)elapsed++;}
    public static boolean branch(){return value!=null&&value.branch();}
    public static boolean unlocked(){return value!=null&&value.unlocked();}
    public static boolean otherOwned(){return value!=null&&value.otherOwned();}
    public static int phase(){return value==null?0:value.phase();}
    public static boolean choice(){return phase()==RookRules.CHOICE;}
    public static boolean locked(){var p=class_310.method_1551().field_1724;return p!=null&&(WasabariVfx.immobilized(p)||ClientWasabari.remaining()>0||HeavyPunchVfx.locked(p))||value!=null&&(value.captured()||phase()>=RookRules.CHOICE);}
    public static boolean captured(){var p=class_310.method_1551().field_1724;return p!=null&&(WasabariVfx.captured(p.method_5667())||HeavyPunchVfx.captured(p))||value!=null&&value.captured();}
    public static int remaining(){return value==null?0:Math.max(0,value.remaining()-elapsed);}
    public static int cooldown(){return value==null?0:Math.max(0,value.cooldown()-elapsed);}
    public static float progress(){return phase()>0?(float)remaining()/RookRules.duration(phase()):dev.killerranking.combat.CombatRules.cooldownProgress(cooldown(),RookRules.COOLDOWN);}
    public static class_1297 target(){var c=class_310.method_1551();return c.field_1687==null||value==null?null:c.field_1687.method_8469(value.target());}
    public static class_1309 selected(){
        var c=class_310.method_1551();var p=c.field_1724;if(p==null||c.field_1687==null)return null;
        var eye=p.method_33571();var end=eye.method_1019(p.method_5720().method_1021(RookRules.REACH));
        return c.field_1687.method_8390(class_1309.class,p.method_5829().method_1014(RookRules.REACH),e->e!=p&&e.method_5805()&&!e.method_7325()&&e.method_5732()&&!e.method_5765()&&!e.method_5782()
            &&!p.method_5722(e)&&p.method_18395(e)&&!(e instanceof class_1657 other&&other.method_7337())&&!RookVfx.captured(e.method_5667())
            &&p.method_5858(e)<=4&&p.method_6057(e)&&e.method_5829().method_1014(.12).method_992(eye,end).isPresent())
            .stream().min(Comparator.comparingDouble(e->e.method_5829().method_1014(.12).method_992(eye,end).orElse(end).method_1025(eye))).orElse(null);
    }
    public static boolean outlines(class_1297 e){return phase()==RookRules.AIM&&e==selected();}
    public static class_2561 status(){
        if(phase()==RookRules.AIM)return class_2561.method_43470(selected()==null?"2m 안에서 지정":"놓으면 잡기");
        if(choice())return class_2561.method_43470("선택 "+CombatHud.seconds(remaining()));
        if(phase()>RookRules.CHOICE)return class_2561.method_43470(switch(phase()){case RookRules.THROW->"던지기";case RookRules.PUNCH->"주먹 연속타";default->"올라타기";});
        if(cooldown()>0)return class_2561.method_43470(CombatHud.seconds(cooldown()));
        return class_2561.method_43470(!TraitVisuals.enabled()?"꺼짐":unlocked()?"준비":"해금 1,000P");
    }
    private ClientRook(){}
}
