package dev.killerranking.client;

import dev.killerranking.entity.BishopFollower;
import net.minecraft.class_1306;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.client.renderer.*;

/** The weapon shares the authored wrist timeline and emerges only for the strike. */
public final class BishopDaggerLayer extends class_3887<BishopFollower,BishopModel> {
    private final class_759 items;
    public BishopDaggerLayer(class_3883<BishopFollower,BishopModel> parent,class_759 items){super(parent);this.items=items;}
    @Override public void render(class_4587 stack,class_4597 buffers,int light,BishopFollower e,float walk,float speed,float delta,float age,float yaw,float pitch){
        if(!e.striking()||e.method_5767())return;
        var model=method_17165();stack.method_22903();model.globalPose(stack);model.method_2803(class_1306.field_6183,stack);
        stack.method_22907(class_7833.field_40714.rotationDegrees(-90));stack.method_22907(class_7833.field_40716.rotationDegrees(180));stack.method_22904(1/16f,.125,-.625);
        model.daggerPose(stack);items.method_3233(e,e.method_6047(),class_811.field_4320,false,stack,buffers,light);stack.method_22909();
    }
}
