package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.entity.BishopFollower;
import net.minecraft.class_1921;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_630;
import net.minecraft.class_922;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;

/** A dedicated 64-pixel face is held clear of the hood opening. */
public final class BishopMaskLayer extends class_3887<BishopFollower,BishopModel> {
    public static final class_5601 LAYER=new class_5601(KillerRankingMod.id("bishop_mask"),"main");
    private final class_630 face;
    public BishopMaskLayer(class_3883<BishopFollower,BishopModel> parent,class_630 root){super(parent);face=root.method_32086("face");}
    public static class_5607 layer(){
        var mesh=new class_5609();mesh.method_32111().method_32117("face",class_5606.method_32108().method_32101(0,0).method_32097(-32,-32,0,64,64,0),class_5603.field_27701);
        return class_5607.method_32110(mesh,64,64);
    }
    @Override public void render(class_4587 stack,class_4597 buffers,int light,BishopFollower e,float walk,float speed,float delta,float age,float yaw,float pitch){
        if(e.method_5767())return;
        stack.method_22903();method_17165().globalPose(stack);method_17165().field_3398.method_22703(stack);
        stack.method_22904(0,-3.9/16,-4.98/16);stack.method_22905(.122f,.122f,.122f);
        face.method_22698(stack,buffers.getBuffer(class_1921.method_23576(KillerRankingMod.id("textures/entity/bishop_mask.png"))),light,class_922.method_23622(e,0));stack.method_22909();
    }
}
