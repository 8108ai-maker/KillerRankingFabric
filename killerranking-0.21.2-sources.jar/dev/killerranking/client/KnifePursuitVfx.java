package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.KnifePursuitRules;
import dev.killerranking.combat.ShoulderStabRules;
import dev.killerranking.network.KnifePursuitVisualPayload;
import dev.killerranking.visual.SalmosaKnifeGeometry;
import dev.kosmx.playerAnim.api.firstPerson.*;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.minecraftApi.*;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.class_811;
import net.minecraft.world.item.*;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.*;

/** The actual dagger model travels, stays embedded on a moving target, then returns to the animated hand. */
public final class KnifePursuitVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("knife_pursuit_layer"),ANIMATION=KillerRankingMod.id("salmosa_knife_pursuit");
    private static final Map<UUID,State> ACTIVE=new HashMap<>();
    private static long flyingFrames,embeddedFrames,extractFrames,deflectedFrames;
    private static final class State {
        KnifePursuitVisualPayload value;int age,ttl;boolean animated,arrived;
        State(KnifePursuitVisualPayload p){update(p);}
        void update(KnifePursuitVisualPayload p){value=p;age=p.age();ttl=25;}
    }
    public static void register(){
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{
            var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new LeftHandedHelperModifier(p));
            stack.addAnimLayer(3450,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
        });
        WorldRenderEvents.AFTER_ENTITIES.register(KnifePursuitVfx::render);
    }
    public static void accept(KnifePursuitVisualPayload p){
        if(p.phase()==0){remove(p.player());return;}
        var previous=ACTIVE.get(p.player());if(previous!=null&&previous.value.phase()!=p.phase())remove(p.player());
        ACTIVE.compute(p.player(),(id,s)->{if(s==null||s.value.phase()!=p.phase()||p.age()<s.age-3)return new State(p);s.update(p);return s;});
    }
    public static boolean active(UUID id){return ACTIVE.containsKey(id);}
    public static boolean casting(UUID id){var s=ACTIVE.get(id);return s!=null&&s.value.phase()==KnifePursuitRules.CAST;}
    public static boolean hideItem(class_1309 e,class_1799 item,class_811 display,boolean left){
        var s=ACTIVE.get(e.method_5667());return s!=null&&(s.value.phase()==KnifePursuitRules.DEFLECTED||s.value.phase()==KnifePursuitRules.CAST&&KnifePursuitRules.away(s.age))
            &&display!=class_811.field_4315&&item.method_31574(KillerRankingMod.SALMOSA_MID_DAGGER)&&left==(e.method_6068()==class_1306.field_6182);
    }
    public static long flyingFrames(){return flyingFrames;}public static long embeddedFrames(){return embeddedFrames;}public static long extractFrames(){return extractFrames;}
    public static long deflectedFrames(){return deflectedFrames;}
    public static void clear(){for(var id:new ArrayList<>(ACTIVE.keySet()))remove(id);}
    private static void remove(UUID id){ACTIVE.remove(id);var c=class_310.method_1551();if(c.field_1687==null)return;
        if(c.field_1687.method_18470(id) instanceof class_742 p){var l=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(l instanceof ModifierLayer<?> layer)layer.setAnimation(null);}}
    @SuppressWarnings("unchecked") private static boolean animate(class_742 p,State s){
        var l=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);var data=PlayerAnimationRegistry.getAnimation(ANIMATION);
        if(!(l instanceof ModifierLayer<?> layer)||data==null)return false;
        var animation=(IAnimation)data.playAnimation();if(animation instanceof KeyframeAnimationPlayer k){
            for(int i=0;i<Math.min(s.age,KnifePursuitRules.DURATION);i++)k.tick();
            k.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);k.setFirstPersonConfiguration(new FirstPersonConfiguration(true,true,true,true));
        }
        ((ModifierLayer<IAnimation>)layer).setAnimation(animation);return true;
    }
    public static void tick(class_310 c){if(c.field_1687==null||c.method_1493())return;
        for(var id:new ArrayList<>(ACTIVE.keySet())){var s=ACTIVE.get(id);var p=c.field_1687.method_18470(id);
            if(--s.ttl<=0||p==null||!p.method_5805()||p.method_7325()||s.value.phase()==KnifePursuitRules.CAST&&s.age>=KnifePursuitRules.DURATION||s.value.phase()==KnifePursuitRules.DEFLECTED&&s.age>=KnifePursuitRules.AIR_DURATION){remove(id);continue;}
            if(s.value.phase()==KnifePursuitRules.CAST){
                float facing=s.value.yaw();
                if(s.value.age()>=KnifePursuitRules.BLINK){
                    var t=target(s);if(t!=null){var d=t.method_19538().method_1020(s.value.destination());facing=(float)Math.toDegrees(Math.atan2(-d.field_1352,d.field_1350));}
                    if(!s.arrived){
                        // Observers also snap on the arrival packet, rather than lerping through the path.
                        var at=s.value.destination();p.method_5759(at.field_1352,at.field_1351,at.field_1350,facing,p.method_36455(),1);
                        p.method_33574(at);p.field_6014=p.field_6038=at.field_1352;p.field_6036=p.field_5971=at.field_1351;p.field_5969=p.field_5989=at.field_1350;s.arrived=true;
                    }
                }
                p.field_6283=p.field_6220=facing;if(!s.animated&&p instanceof class_742 a)s.animated=animate(a,s);
            }
            s.age++;
        }
    }
    private static class_1309 target(State s){var c=class_310.method_1551();for(var e:c.field_1687.method_18112())if(s.value.target().equals(e.method_5667())&&e instanceof class_1309 living)return living;return null;}
    private static void render(WorldRenderContext context){
        var c=class_310.method_1551();var pose=context.matrixStack();var buffers=context.consumers();
        if(c.field_1687==null||pose==null||buffers==null)return;
        float delta=context.tickCounter().method_60637(false);var camera=context.camera().method_19326();
        for(var entry:ACTIVE.entrySet()){
            var s=entry.getValue();
            var player=c.field_1687.method_18470(entry.getKey());if(player==null||player.method_5707(camera)>4096)continue;
            if(s.value.phase()==KnifePursuitRules.DEFLECTED){
                float time=s.age+delta;var at=KnifePursuitRules.deflected(s.value.origin(),time);
                airKnife(context,player,at,s.value.yaw());deflectedFrames++;
                if(time<5)ribbon(context,at,new class_243(0,1,0),.75f,.1f,time%4,.75f);
                continue;
            }
            if(s.value.phase()!=KnifePursuitRules.CAST)continue;
            float age=s.age+delta;var target=target(s);var forward=class_243.method_1030(0,s.value.yaw());
            var wound=target==null?s.value.wound():target.method_30950(delta).method_1031(0,target.method_17682()*.62,0).method_1020(forward.method_1021(Math.max(.08,target.method_17681()*.5-.07)));
            var direction=wound.method_1020(s.value.origin()).method_1029();
            if(age>=KnifePursuitRules.THROW&&age<KnifePursuitRules.RETURN){
                boolean pulling=age>=KnifePursuitRules.EXTRACT;
                float pull=(float)Math.clamp((age-KnifePursuitRules.EXTRACT)/(KnifePursuitRules.RETURN-KnifePursuitRules.EXTRACT),0,1);
                var at=age<KnifePursuitRules.IMPACT?KnifePursuitRules.flight(s.value.origin(),wound,age):wound.method_1020(forward.method_1021(.65*pull));
                if(age>=KnifePursuitRules.IMPACT&&!s.value.embedded()&&!pulling)continue;
                var bladeDirection=age>=KnifePursuitRules.IMPACT?forward:direction;
                pose.method_22903();pose.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);
                pose.method_22907(new Quaternionf().rotationTo(new Vector3f(0,1,0),new Vector3f((float)bladeDirection.field_1352,(float)bladeDirection.field_1351,(float)bladeDirection.field_1350)));
                // Roll from upright flight to a horizontal blade before gripping and withdrawal.
                float roll=90*(1-(float)Math.clamp((age-KnifePursuitRules.BLINK)/(KnifePursuitRules.GRIP-KnifePursuitRules.BLINK),0,1));
                pose.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(roll));
                float scale=.8f;pose.method_46416(0,(8-SalmosaKnifeGeometry.TIP)*scale/16,0);pose.method_22905(scale,scale,scale);
                recordKnife(entry.getKey(),pose,pulling);
                c.method_1480().method_23177(player,new class_1799(KillerRankingMod.SALMOSA_MID_DAGGER),class_811.field_4315,false,pose,buffers,c.field_1687,0xF000F0,class_4608.field_21444,player.method_5628());pose.method_22909();
                if(age<KnifePursuitRules.IMPACT)flyingFrames++;else embeddedFrames++;
                if(age<KnifePursuitRules.IMPACT)ribbon(context,at,direction,1.15f,.075f,age-KnifePursuitRules.THROW,.8f);
            }
            if(age>=KnifePursuitRules.BLINK&&age<KnifePursuitRules.BLINK+3){
                var at=s.value.destination().method_1031(0,.85,0);ribbon(context,at,forward,.8f,.3f,age-KnifePursuitRules.BLINK,.7f);
                ribbon(context,s.value.origin().method_1031(0,-.55,0),forward,.8f,.3f,age-KnifePursuitRules.BLINK,.5f);
            }
            if(age>=KnifePursuitRules.EXTRACT&&age<KnifePursuitRules.EXTRACT+4){ribbon(context,wound,direction.method_1021(-1),.65f,.13f,age-KnifePursuitRules.EXTRACT,1);extractFrames++;}
        }
    }
    /** Palm anchor is shared with the catching hand, so the same blade passes into its grip. */
    public static void airKnife(WorldRenderContext context,class_1309 player,class_243 palm,float yaw){
        var pose=context.matrixStack();var camera=context.camera().method_19326();var direction=ShoulderStabRules.incoming(yaw);
        pose.method_22903();pose.method_22904(palm.field_1352-camera.field_1352,palm.field_1351-camera.field_1351,palm.field_1350-camera.field_1350);
        pose.method_22907(new Quaternionf().rotationTo(new Vector3f(0,1,0),new Vector3f((float)direction.field_1352,(float)direction.field_1351,(float)direction.field_1350)));
        float scale=SalmosaKnifeGeometry.SKILL_SCALE;pose.method_46416(0,(8-SalmosaKnifeGeometry.PALM)*scale/16,0);pose.method_22905(scale,scale,scale);
        var c=class_310.method_1551();c.method_1480().method_23177(player,new class_1799(KillerRankingMod.SALMOSA_MID_DAGGER),class_811.field_4315,false,pose,context.consumers(),c.field_1687,0xF000F0,class_4608.field_21444,player.method_5628());pose.method_22909();
    }
    /** Native render hook used by capture verification without altering the production model. */
    private static void recordKnife(UUID player,net.minecraft.class_4587 pose,boolean pulling){ }
    private static void ribbon(WorldRenderContext context,class_243 at,class_243 direction,float length,float width,float time,float alpha){
        var pose=context.matrixStack();var camera=context.camera().method_19326();int frame=Math.clamp((int)time,0,3);
        pose.method_22903();pose.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);
        pose.method_22907(new Quaternionf().rotationTo(new Vector3f(1,0,0),new Vector3f((float)direction.field_1352,(float)direction.field_1351,(float)direction.field_1350)));
        var consumer=context.consumers().getBuffer(class_1921.method_23580(KillerRankingMod.id("textures/effect/wasabari_stab.png")));
        float lo=frame/4f,hi=(frame+1)/4f;
        vertex(pose,consumer,-length,-width,0,hi,alpha);vertex(pose,consumer,0,-width,1,hi,alpha);vertex(pose,consumer,0,width,1,lo,alpha);vertex(pose,consumer,-length,width,0,lo,alpha);pose.method_22909();
    }
    private static void vertex(net.minecraft.class_4587 p,net.minecraft.class_4588 v,float x,float y,float u,float tex,float alpha){v.method_22918(p.method_23760().method_23761(),x,y,0).method_22915(.8f,.6f,1,alpha).method_22913(u,tex).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(p.method_23760(),0,0,1);}
    private KnifePursuitVfx(){ }
}
