package dev.killerranking.client;
import dev.killerranking.data.KillerPoints;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class MissionsScreen extends PanelScreen {
    private int page;
    public MissionsScreen(class_437 parent) { super("랜덤 미션 · 10개", parent); }
    @Override protected void method_25426() {
        super.method_25426();
        button(20, 234, 84, 18, "이전 5개", () -> page = 0);
        button(236, 234, 84, 18, "다음 5개", () -> page = 1);
    }
    @Override protected void content(class_332 g) {
        var data = ClientDashboard.get();
        text(g, ClientDashboard.remaining(), 20, 43, ACCENT);
        if (data == null || data.missions().isEmpty()) { text(g, "미션을 불러오는 중…", 20, 70, MUTED); return; }
        for (int i = 0; i < 5; i++) {
            int index = page * 5 + i;
            if (index >= data.missions().size()) break;
            var m = data.missions().get(index); int y = 62 + i * 32;
            g.method_25294(16, y, 324, y + 29, 0xFF1B2636);
            text(g, (index + 1) + ". " + m.title(), 22, y + 4, m.complete() ? ACCENT : WHITE);
            String progress = (m.progress() / m.divisor()) + " / " + (m.goal() / m.divisor()) + " " + m.unit();
            g.method_51433(field_22793, progress, 317 - field_22793.method_1727(progress), y + 4, WHITE, false);
            String reward = (m.complete() ? "지급 완료 " : "보상 ") + KillerPoints.format(m.rewardUnits()) + " P";
            CombatHud.bar(g, 23, y + 19, Math.min(182, 284 - field_22793.method_1727(reward)), 5, m.progress() / (float) m.goal(), ACCENT);
            g.method_51433(field_22793, reward, 317 - field_22793.method_1727(reward), y + 17, m.complete() ? ACCENT : 0xFFF1CF7A, false);
        }
        text(g, "완료 즉시 지급 · " + (page + 1) + " / 2", 118, 239, MUTED);
    }
}
