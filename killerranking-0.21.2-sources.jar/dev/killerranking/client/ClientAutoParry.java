package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.network.AutoParryRequestPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class ClientAutoParry {
    private static boolean held;
    private static int pulse;
    public static void input(class_310 client,boolean down){
        boolean usable=client.field_1724!=null&&client.field_1724.method_5805()&&!client.field_1724.method_7325()&&client.field_1755==null&&!client.method_1493()
            &&ClientCleave.branch()&&ClientCleave.unlocked()&&TraitVisuals.enabled()
            &&client.field_1724.method_6047().method_31574(KillerRankingMod.PAWN6_KATANA)&&!client.field_1724.method_6115()
            &&ClientCleave.phase()==0&&!ClientRook.locked()&&ClientRook.phase()==0&&ClientCheckmate.remaining()==0&&ClientRush.remaining()==0;
        boolean want=down&&usable;
        if(want!=held){held=want;pulse=0;send(want);if(!want&&client.field_1724!=null)AutoParryVfx.stop(client.field_1724.method_5667());}
        else if(held&&++pulse>=5){pulse=0;send(true);}
    }
    private static void send(boolean value){if(ClientPlayNetworking.canSend(AutoParryRequestPayload.TYPE))ClientPlayNetworking.send(new AutoParryRequestPayload(value));}
    public static boolean held(){return held;}
    public static boolean active(){var p=class_310.method_1551().field_1724;return p!=null&&(held||AutoParryVfx.active(p.method_5667()));}
    public static class_2561 status(){
        if(active())return class_2561.method_43470("자동 방어 중");
        if(!TraitVisuals.enabled())return class_2561.method_43470("꺼짐");
        var p=class_310.method_1551().field_1724;
        if(p!=null&&!p.method_6047().method_31574(KillerRankingMod.PAWN6_KATANA))return class_2561.method_43470("카타나 필요");
        return class_2561.method_43470("꾹 눌러 유지");
    }
    public static void clear(){held=false;pulse=0;}
    private ClientAutoParry() { }
}
