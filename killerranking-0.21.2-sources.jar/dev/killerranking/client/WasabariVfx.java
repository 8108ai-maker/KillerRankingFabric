package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.WasabariRules;
import dev.killerranking.network.WasabariVisualPayload;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.minecraftApi.*;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_630;
import net.minecraft.class_742;
import dev.killerranking.visual.WasabariMotion;
import org.joml.Vector3f;
import com.mojang.blaze3d.vertex.*;

public final class WasabariVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("wasabari_layer"),ANIMATION=KillerRankingMod.id("salmosa_wasabari");
    private static final class State {UUID victim;int age,remaining,lastBlood=-1;float yaw;class_243 bladeTip,bladeDirection;boolean tripped,animated;State(WasabariVisualPayload p){victim=p.victim();age=p.age();remaining=p.remaining();yaw=p.yaw();tripped=p.tripped();}}
    private static final Map<UUID,State> ACTIVE=new HashMap<>();private static long sweeps,stabs,prone;
    public record LegPoints(class_243 ankle,class_243 shin,class_243 centre,class_243 outward) { }
    private static final Map<UUID,LegPoints> LEGS=new HashMap<>();
    public static LegPoints legPoints(UUID victim){return LEGS.get(victim);}
    public static LegPoints heldLeg(UUID owner){var s=ACTIVE.get(owner);return s==null||!s.tripped?null:LEGS.get(s.victim);}
    public static class_243 knifeTip(UUID owner){var s=ACTIVE.get(owner);return s==null?null:s.bladeTip;}
    public static class_243 bladeDirection(UUID owner){var s=ACTIVE.get(owner);return s==null?null:s.bladeDirection;}
    public static void recordKnife(UUID owner,class_4587 stack){var s=ACTIVE.get(owner);if(s!=null){var matrix=new org.joml.Matrix4f(stack.method_23760().method_23761());var camera=class_310.method_1551().field_1773.method_19418().method_19326();s.bladeTip=world(matrix,0,(dev.killerranking.visual.SalmosaKnifeGeometry.TIP-8)/16,0,camera);s.bladeDirection=s.bladeTip.method_1020(world(matrix,0,-3f/16,0,camera)).method_1029();}}
    /** Read the rendered limb instead of estimating its position from a standing hitbox. */
    public static void recordLeg(class_1309 victim,class_630 leg,class_4587 stack){
        if(!captured(victim.method_5667()))return;
        var matrix=new org.joml.Matrix4f(stack.method_23760().method_23761());
        var local=new class_4587();leg.method_22703(local);matrix.mul(local.method_23760().method_23761());
        var camera=class_310.method_1551().field_1773.method_19418().method_19326();
        var owner=captor(victim.method_5667());if(owner==null)return;
        var side=class_243.method_1030(0,owner.field_6283+90).method_1021(owner.method_6068()==class_1306.field_6182?-1:1);
        var axis=matrix.transformDirection(new Vector3f(1,0,0)).normalize();
        double sign=side.method_1026(new class_243(axis.x,axis.y,axis.z))>=0?1:-1;
        var centre=world(matrix,0,5.5f/16,0,camera);
        var shin=world(matrix,(float)(sign*2/16),5.5f/16,0,camera);
        LEGS.put(victim.method_5667(),new LegPoints(world(matrix,0,10f/16,0,camera),shin,centre,shin.method_1020(centre).method_1029()));
    }
    /** Visit the real leg cube with all ancestor pivots and native cube dimensions applied. */
    public static void recordLeg(class_1309 victim,net.minecraft.class_5597<?> tree,class_630 leg,String name,class_4587 stack){
        if(!captured(victim.method_5667()))return;
        var owner=captor(victim.method_5667());if(owner==null)return;
        var camera=class_310.method_1551().field_1773.method_19418().method_19326();
        var side=class_243.method_1030(0,owner.field_6283+90).method_1021(owner.method_6068()==class_1306.field_6182?-1:1);
        float[] longest={0};
        tree.method_32008().method_35745(stack,(pose,path,index,cube)->{
            if(!(path.equals(name)||path.endsWith("/"+name)))return;
            float length=cube.field_3647-cube.field_3644;if(length<=longest[0])return;longest[0]=length;
            var matrix=new org.joml.Matrix4f(pose.method_23761());
            var axis=matrix.transformDirection(new Vector3f(1,0,0)).normalize();
            float x=(cube.field_3645+cube.field_3648)/2,z=(cube.field_3643+cube.field_3646)/2;
            float edge=side.method_1026(new class_243(axis.x,axis.y,axis.z))>=0?cube.field_3648:cube.field_3645;
            float shinY=cube.field_3644+length*.46f,ankleY=cube.field_3644+length*.84f;
            var centre=world(matrix,x/16,shinY/16,z/16,camera);
            var shin=world(matrix,edge/16,shinY/16,z/16,camera);
            LEGS.put(victim.method_5667(),new LegPoints(world(matrix,x/16,ankleY/16,z/16,camera),shin,centre,shin.method_1020(centre).method_1029()));
        });
    }
    private static class_243 world(org.joml.Matrix4f matrix,float x,float y,float z,class_243 origin){var v=matrix.transformPosition(new Vector3f(x,y,z));return origin.method_1031(v.x,v.y,v.z);}
    private static class_243 nativePoint(class_4587 stack,class_243 world){
        var at=world.method_1020(class_310.method_1551().field_1773.method_19418().method_19326());
        var local=new org.joml.Matrix4f(stack.method_23760().method_23761()).invert().transformPosition(new Vector3f((float)at.field_1352,(float)at.field_1351,(float)at.field_1350));
        return new class_243(local.x*16,local.y*16,local.z*16);
    }
    public static class_243 knifeDirection(class_1309 e,class_4587 stack){
        var points=heldLeg(e.method_5667());
        return points==null?WasabariMotion.knifeDirection(e.method_6068()==class_1306.field_6182):nativePoint(stack,points.shin().method_1019(incoming(points))).method_1020(nativePoint(stack,points.shin())).method_1029();
    }
    /** Ice-pick grip: a high downward plunge still enters the side of the lifted leg. */
    private static class_243 incoming(LegPoints points){return points.outward().method_1021(-.48).method_1031(0,-.88,0).method_1029();}
    private static WasabariMotion.Pose basePose(class_1309 e,float age){
        var c=class_310.method_1551();boolean left=e.method_6068()==class_1306.field_6182;
        return e==c.field_1724&&c.field_1690.method_31044().method_31034()?WasabariMotion.pose(age,left):WasabariMotion.thirdPersonPose(age,left);
    }
    public static WasabariMotion.Pose heldPose(class_1309 e,class_4587 stack,float delta){
        float age=age(e.method_5667(),delta);boolean left=e.method_6068()==class_1306.field_6182;
        var base=basePose(e,age);var state=ACTIVE.get(e.method_5667());
        var points=state!=null&&state.tripped?LEGS.get(state.victim):null;
        return points==null?base:WasabariMotion.hold(base,age,left,nativePoint(stack,points.ankle()),nativePoint(stack,points.shin()),knifeDirection(e,stack),HeavyPunchPose.center(e));
    }
    public static void register(){
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier(p));stack.addAnimLayer(3500,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);});
        WorldRenderEvents.AFTER_ENTITIES.register(WasabariVfx::render);
    }
    public static void accept(WasabariVisualPayload p){if(p.remaining()==0){remove(p.owner());return;}if(!p.tripped())LEGS.remove(p.victim());ACTIVE.compute(p.owner(),(id,s)->{if(s==null)return new State(p);s.victim=p.victim();s.age=p.age();s.remaining=p.remaining();s.yaw=p.yaw();s.tripped=p.tripped();return s;});}
    public static boolean active(UUID id){return ACTIVE.containsKey(id);}
    public static boolean captured(UUID id){return ACTIVE.values().stream().anyMatch(s->s.tripped&&id.equals(s.victim));}
    public static boolean immobilized(class_1297 e){return e.method_37908().field_9236&&(active(e.method_5667())||captured(e.method_5667()));}
    public static float age(UUID id,float delta){var s=ACTIVE.get(id);return s==null?-1:s.age+delta;}
    public static class_742 captor(UUID victim){var c=class_310.method_1551();if(c.field_1687==null)return null;for(var entry:ACTIVE.entrySet())if(entry.getValue().tripped&&victim.equals(entry.getValue().victim)&&c.field_1687.method_18470(entry.getKey()) instanceof class_742 p)return p;return null;}
    public static float proneProgress(UUID victim,float delta){for(var s:ACTIVE.values())if(s.tripped&&victim.equals(s.victim)){prone++;return Math.clamp((s.age+delta-WasabariRules.BARI)/4f,0,1);}return 0;}
    public static long renderedSweeps(){return sweeps;}public static long renderedStabs(){return stabs;}public static long renderedProne(){return prone;}
    private static class_1309 victim(State s){var c=class_310.method_1551();if(c.field_1687==null)return null;for(var e:c.field_1687.method_18112())if(s.victim.equals(e.method_5667())&&e instanceof class_1309 living)return living;return null;}
    public static void tick(class_310 c){if(c.method_1493()||c.field_1687==null)return;for(var id:new ArrayList<>(ACTIVE.keySet())){
        var s=ACTIVE.get(id);var p=c.field_1687.method_18470(id);if(--s.remaining<=0||p==null||!p.method_5805()||p.method_7325()){remove(id);continue;}
        if(!s.animated)s.animated=animate(p,s.age);p.field_6283=p.field_6220=s.yaw;s.age++;
    }}
    @SuppressWarnings("unchecked") private static boolean animate(net.minecraft.class_1657 p,int age){
        if(!(p instanceof class_742 player))return false;var layer=PlayerAnimationAccess.getPlayerAssociatedData(player).get(LAYER);if(!(layer instanceof ModifierLayer<?>))return false;
        IAnimation animation=null;if(age>=0){var data=PlayerAnimationRegistry.getAnimation(ANIMATION);if(data==null)return false;animation=(IAnimation)data.playAnimation();
            if(animation instanceof KeyframeAnimationPlayer key){for(int i=0;i<age;i++)key.tick();key.setFirstPersonMode(dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode.THIRD_PERSON_MODEL);key.setFirstPersonConfiguration(new dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration(true,true,false,false));}}
        ((ModifierLayer<IAnimation>)layer).setAnimation(animation);return true;
    }
    private static void remove(UUID id){var s=ACTIVE.remove(id);if(s!=null)LEGS.remove(s.victim);var c=class_310.method_1551();if(c.field_1687!=null){var p=c.field_1687.method_18470(id);if(p!=null)animate(p,-1);}}
    public static void clear(){for(var id:new ArrayList<>(ACTIVE.keySet()))remove(id);LEGS.clear();}
    private static void render(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context){
        var c=class_310.method_1551();var pose=context.matrixStack();var buffers=context.consumers();if(c.field_1687==null||pose==null||buffers==null)return;
        float delta=context.tickCounter().method_60637(false);var camera=context.camera().method_19326();
        for(var entry:ACTIVE.entrySet()){
            var player=c.field_1687.method_18470(entry.getKey());if(player==null||player.method_5707(camera)>4096)continue;var s=entry.getValue();float age=s.age+delta;
            var forward=net.minecraft.class_243.method_1030(0,s.yaw);
            for(int beat:new int[]{WasabariRules.WA,WasabariRules.BARI})if(age>=beat-1&&age<beat+4){
                float time=age-beat+1;int frame=Math.min(3,(int)time);var motion=basePose(player,age);var foot=(player.method_6068()==class_1306.field_6182?motion.leftLeg():motion.rightLeg()).point(0,12,0);
                var at=player.method_30950(delta).method_1019(new class_243(forward.field_1350,0,-forward.field_1352).method_1021(foot.field_1352/16)).method_1019(forward.method_1021(-foot.field_1350/16)).method_1031(0,(24-foot.field_1351)/16+.04,0);
                pose.method_22903();pose.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);pose.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-s.yaw+(beat==WasabariRules.BARI?70:-15)));pose.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(90));
                quad(pose,buffers.getBuffer(class_1921.method_23580(KillerRankingMod.id("textures/effect/wasabari_sweep.png"))),-.9f,-.7f,.9f,.7f,frame/4f,(frame+1)/4f,Math.min(1,(5-time)/2));pose.method_22909();sweeps++;
            }
            var target=victim(s);if(!s.tripped||target==null)continue;
            for(int i=0;i<WasabariRules.STABS;i++){
                float time=age-(WasabariRules.FIRST_STAB+i*WasabariRules.STAB_INTERVAL);
                if(time<-.5f||time>=3)continue;int frame=Math.min(3,(int)Math.max(0,time));
                var points=LEGS.get(target.method_5667());
                var at=points==null?target.method_30950(delta).method_1020(forward.method_1021(Math.min(1,target.method_17682()*.36))).method_1031(0,.26,0):points.shin();
                if(time>=0&&s.lastBlood<i&&points!=null){
                    s.lastBlood=i;var dust=new net.minecraft.class_2390(new Vector3f(.88f,.025f,.06f),.85f);
                    for(int fleck=0;fleck<8;fleck++){var random=c.field_1687.field_9229;var spray=points.outward().method_1021(.08+random.method_43057()*.12).method_1031((random.method_43057()-.5)*.10,.04+random.method_43057()*.10,(random.method_43057()-.5)*.10);c.field_1687.method_8406(dust,at.field_1352,at.field_1351,at.field_1350,spray.field_1352,spray.field_1351,spray.field_1350);}
                }
                pose.method_22903();pose.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);var direction=points==null?new class_243(forward.field_1350,-1,-forward.field_1352).method_1029():incoming(points);
                pose.method_22907(new org.joml.Quaternionf().rotationTo(new Vector3f(1,0,0),new Vector3f((float)direction.field_1352,(float)direction.field_1351,(float)direction.field_1350)));
                quad(pose,buffers.getBuffer(class_1921.method_23580(KillerRankingMod.id("textures/effect/wasabari_stab.png"))),-.40f,-.06f,.10f,.06f,frame/4f,(frame+1)/4f,Math.min(1,(3-time)/2));pose.method_22909();stabs++;
            }
        }
    }
    private static void quad(class_4587 s,class_4588 v,float x0,float y0,float x1,float y1,float lo,float hi,float a){vertex(s,v,x0,y0,0,hi,a);vertex(s,v,x1,y0,1,hi,a);vertex(s,v,x1,y1,1,lo,a);vertex(s,v,x0,y1,0,lo,a);}
    private static void vertex(class_4587 s,class_4588 v,float x,float y,float u,float tex,float alpha){v.method_22918(s.method_23760().method_23761(),x,y,0).method_22915(1,1,1,alpha).method_22913(u,tex).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(s.method_23760(),0,0,1);}
    private WasabariVfx() { }
}
