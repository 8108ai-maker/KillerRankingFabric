package dev.killerranking.client;
import com.mojang.blaze3d.vertex.*;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.client.mixin.RushCubeAccess;
import dev.killerranking.visual.RushBarrage;
import dev.killerranking.visual.RushUpperBody;
import dev.killerranking.visual.RushTorso;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1664;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_630;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import net.minecraft.client.model.geom.*;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** One detached native-size head, torso and arm pair with its own punching rhythm. */
final class RushModel {
    private record EchoPart(String bone,Mesh mesh,Matrix4f pose) { }
    private record Point(float x,float y,float z,float u,float v) {
        Point between(Point b,float t){return new Point(x+(b.x-x)*t,y+(b.y-y)*t,z+(b.z-z)*t,u+(b.u-u)*t,v+(b.v-v)*t);}
    }
    private record Face(List<Point> points,Vector3f normal) { }
    private record Mesh(List<Face> faces,float center) { }
    private record Arms(Mesh right,Mesh left,Mesh rightSleeve,Mesh leftSleeve) { }
    private record Upper(Mesh head,Mesh hat,Mesh torso,Mesh jacket,Arms arms) { }
    private static final Map<UUID,KeyframeAnimationPlayer> MOTIONS=new HashMap<>();
    private static final Map<UUID,Float> POSITION_ERRORS=new HashMap<>(),POSE_DIFFERENCES=new HashMap<>();
    private static class_638 world;
    private static Upper wide,slim;private static long rendered,upperBodies;
    static void register(){
        WorldRenderEvents.START.register(c->{
            if(world!=c.world()){clear();world=c.world();}
        });
    }
    static void start(class_742 player,int age){
        if(MOTIONS.containsKey(player.method_5667()))return;
        var data=PlayerAnimationRegistry.getAnimation(KillerRankingMod.id("rush_echo"));if(data==null)return;
        if(!(data.playAnimation() instanceof KeyframeAnimationPlayer motion))return;
        for(int i=0;i<age;i++)motion.tick();MOTIONS.put(player.method_5667(),motion);
    }
    static void render(WorldRenderContext context,class_742 player,float fade){
        var motion=MOTIONS.get(player.method_5667());if(motion==null||context.matrixStack()==null||context.consumers()==null)return;
        float partial=context.tickCounter().method_60637(false);motion.setupAnim(partial);
        // A shared world origin does not share the animation clock or pose.
        var source=RushVfx.motion(player);
        if(source!=null){
            source.setupAnim(partial);
            var a=motion.get3DTransform("torso",TransformType.ROTATION,partial,Vec3f.ZERO);
            var b=source.get3DTransform("torso",TransformType.ROTATION,partial,Vec3f.ZERO);
            POSE_DIFFERENCES.put(player.method_5667(),Math.max(Math.abs(a.getX()-b.getX()),Math.max(Math.abs(a.getY()-b.getY()),Math.abs(a.getZ()-b.getZ()))));
        }
        var torsoRotation=motion.get3DTransform("torso",TransformType.ROTATION,partial,Vec3f.ZERO);
        var torsoPosition=motion.get3DTransform("torso",TransformType.POSITION,partial,Vec3f.ZERO);
        var pinned=RushTorso.pivot(new class_243(0,12,0),new class_243(torsoRotation.getX(),torsoRotation.getY(),torsoRotation.getZ()));
        var correction=pinned.method_1023(torsoPosition.getX(),torsoPosition.getY(),torsoPosition.getZ());
        var bodyPosition=motion.get3DTransform("body",TransformType.POSITION,partial,Vec3f.ZERO);
        var bodyRotation=motion.get3DTransform("body",TransformType.ROTATION,partial,Vec3f.ZERO);
        // Follow the source world position/facing while the echo pose has its own beat.
        float facing=net.minecraft.class_3532.method_17821(partial,player.field_6220,player.field_6283);
        var root=RushUpperBody.root(player.method_30950(partial),facing,player.method_55693(),
            new class_243(bodyPosition.getX(),bodyPosition.getY(),bodyPosition.getZ()),
            new class_243(bodyRotation.getX(),bodyRotation.getY(),bodyRotation.getZ()));
        var waist=part("torso",null,root,motion,partial,correction,0).pose().transformPosition(new Vector3f(0,.75f,0));
        var anchor=new Matrix4f(root).transformPosition(new Vector3f(0,.75f,0));
        POSITION_ERRORS.put(player.method_5667(),waist.distance(anchor)+(float)RushUpperBody.origin(player.method_30950(partial),facing,player.method_55693()).method_1022(player.method_30950(partial)));
        var skin=upper(player.method_52814().comp_1629()==class_8685.class_7920.field_41122);
        boolean fp=player==class_310.method_1551().field_1724&&class_310.method_1551().field_1690.method_31044().method_31034();
        var echoes=new ArrayList<EchoPart>();
        // Match the source player's first-person visibility: its own head/body
        // intersect the camera, while the hands remain visible. Other viewers
        // still see the entire detached upper-body afterimage.
        if(!fp){
            echoes.add(part("torso",skin.torso(),root,motion,partial,correction,0));
            echoes.add(part("head",skin.head(),root,motion,partial,correction,player.method_36455()*(float)Math.PI/180));
            if(player.method_7348(class_1664.field_7564))echoes.add(part("torso",skin.jacket(),root,motion,partial,correction,0));
            if(player.method_7348(class_1664.field_7563))echoes.add(part("head",skin.hat(),root,motion,partial,correction,player.method_36455()*(float)Math.PI/180));
        }
        for(boolean left:new boolean[]{false,true}){
            String arm=left?"leftArm":"rightArm";
            echoes.add(part(arm,left?skin.arms().left():skin.arms().right(),root,motion,partial,correction,0));
            if(player.method_7348(left?class_1664.field_7568:class_1664.field_7570))
                echoes.add(part(arm,left?skin.arms().leftSleeve():skin.arms().rightSleeve(),root,motion,partial,correction,0));
        }
        int color=((int)(255*Math.clamp(RushBarrage.ALPHA*fade*(fp?.6f:1),0,1))<<24)|0xFFFFFF;
        var vertices=context.consumers().getBuffer(class_1921.method_23580(player.method_52814().comp_1626()));
        for(var e:echoes){
            var stack=pose(context,e.pose());draw(stack,vertices,e.mesh(),color);
            stack.method_22909();
        }
        for(var e:echoes){
            if(!(e.bone().equals("leftArm")&&e.mesh()==skin.arms().left()||e.bone().equals("rightArm")&&e.mesh()==skin.arms().right()))continue;
            boolean left=e.bone().equals("leftArm");
            var hand=left==(player.method_6068()==class_1306.field_6182)?class_1268.field_5808:class_1268.field_5810;
            if(!player.method_5998(hand).method_31574(KillerRankingMod.TTEOKBAL_FIST))continue;
            var stack=pose(context,e.pose());
            FistBandages.render(stack,context.consumers(),player.method_52814().comp_1629()==class_8685.class_7920.field_41122,e.mesh().center(),0xF000F0,class_4608.field_21444,color);
            stack.method_22909();
        }
        rendered++;
        if(!fp&&!skin.head().faces().isEmpty()&&!skin.torso().faces().isEmpty())upperBodies++;
    }
    private static EchoPart part(String bone,Mesh mesh,Matrix4f root,KeyframeAnimationPlayer motion,float partial,class_243 correction,float headPitch){
        var pos=motion.get3DTransform(bone,TransformType.POSITION,partial,new Vec3f(bone.equals("leftArm")?5:bone.equals("rightArm")?-5:0,bone.endsWith("Arm")?2:0,0));
        var rot=motion.get3DTransform(bone,TransformType.ROTATION,partial,new Vec3f(headPitch,0,0));
        var matrix=new Matrix4f(root).translate((pos.getX()+(float)correction.field_1352)/16,(pos.getY()+(float)correction.field_1351)/16,(pos.getZ()+(float)correction.field_1350)/16)
            .rotateZYX(rot.getZ(),rot.getY(),rot.getX());
        return new EchoPart(bone,mesh,matrix);
    }
    private static class_4587 pose(WorldRenderContext context,Matrix4f matrix){
        var camera=context.camera().method_19326();var stack=context.matrixStack();stack.method_22903();stack.method_22904(-camera.field_1352,-camera.field_1351,-camera.field_1350);
        stack.method_23760().method_23761().mul(matrix);stack.method_23760().method_23762().mul(new Matrix3f(matrix).invert().transpose());return stack;
    }
    private static Upper upper(boolean narrow){
        var found=narrow?slim:wide;if(found!=null)return found;
        var root=class_310.method_1551().method_31974().method_32072(narrow?class_5602.field_27581:class_5602.field_27577);
        var arms=new Arms(mesh(root.method_32086("right_arm")),mesh(root.method_32086("left_arm")),mesh(root.method_32086("right_sleeve")),mesh(root.method_32086("left_sleeve")));
        found=new Upper(mesh(root.method_32086("head")),mesh(root.method_32086("hat")),mesh(root.method_32086("body")),mesh(root.method_32086("jacket")),arms);
        if(narrow)slim=found;else wide=found;return found;
    }
    private static Mesh mesh(class_630 part){
        var faces=new ArrayList<Face>();float[] bounds={Float.MAX_VALUE,-Float.MAX_VALUE};
        part.method_35745(new class_4587(),(pose,path,index,cube)->{for(var polygon:((RushCubeAccess)(Object)cube).killerranking$rushFaces()){
            var points=Arrays.stream(polygon.field_3502).map(v->new Point(v.field_3605.x,v.field_3605.y,v.field_3605.z,v.field_3604,v.field_3603)).toList();
            for(var p:points){bounds[0]=Math.min(bounds[0],p.x);bounds[1]=Math.max(bounds[1],p.x);}
            float low=points.stream().map(p->p.y).min(Float::compare).orElse(0f),high=points.stream().map(p->p.y).max(Float::compare).orElse(0f);
            if(high-low<.001)faces.add(new Face(points,new Vector3f(polygon.field_21618)));
            else for(float y=low;y<high;y+=.75f){var clipped=clip(clip(points,y,true),Math.min(y+.75f,high),false);if(clipped.size()==4)faces.add(new Face(clipped,new Vector3f(polygon.field_21618)));}
        }});return new Mesh(List.copyOf(faces),(bounds[0]+bounds[1])*.5f);
    }
    private static List<Point> clip(List<Point> input,float y,boolean above){
        var result=new ArrayList<Point>();if(input.isEmpty())return result;
        var previous=input.getLast();boolean prev=above?previous.y>=y:previous.y<=y;
        for(var current:input){boolean inside=above?current.y>=y:current.y<=y;if(inside!=prev)result.add(previous.between(current,(y-previous.y)/(current.y-previous.y)));if(inside)result.add(current);previous=current;prev=inside;}return result;
    }
    private static void draw(class_4587 stack,class_4588 vertices,Mesh mesh,int color){
        var pose=stack.method_23760();for(var face:mesh.faces()){
            var normal=face.normal();
            for(var p:face.points()){
                vertices.method_22918(pose.method_23761(),p.x()/16,p.y()/16,p.z()/16).method_39415(color).method_22913(p.u(),p.v()).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(pose,normal.x,normal.y,normal.z);
            }
        }
    }
    static void forget(UUID player){MOTIONS.remove(player);POSITION_ERRORS.remove(player);POSE_DIFFERENCES.remove(player);}
    static void clear(){MOTIONS.clear();POSITION_ERRORS.clear();POSE_DIFFERENCES.clear();world=null;wide=slim=null;rendered=upperBodies=0;}
    static float positionError(UUID player){return POSITION_ERRORS.getOrDefault(player,Float.POSITIVE_INFINITY);}
    static float poseDifference(UUID player){return POSE_DIFFERENCES.getOrDefault(player,0f);}
    static void tick(UUID player){var motion=MOTIONS.get(player);if(motion!=null)motion.tick();}
    static long renderedEchoes(){return rendered;}
    static long renderedUpperBodies(){return upperBodies;}
    static int upperBodyEchoCount(UUID player){return MOTIONS.containsKey(player)?1:0;}
}
