package dev.killerranking.client;

import com.mojang.blaze3d.vertex.*;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.*;
import dev.killerranking.network.NeungsaEchoVisualPayload;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.firstPerson.*;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.api.layered.modifier.*;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.*;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import java.util.*;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.fabricmc.fabric.api.client.model.loading.v1.FabricBakedModelManager;
import net.minecraft.class_1059;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_8685;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.*;
import net.minecraft.world.item.*;
import net.minecraft.world.phys.*;
import org.joml.Quaternionf;

/** The original sheathes and waits; independent, short-lived skin echoes perform the middle cuts. */
public final class NeungsaEchoVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("neungsa_echo_layer");
    private static final Map<UUID,State> ACTIVE=new HashMap<>();
    private static class_591<class_742> wide,slim;
    private static int created,rendered,segments;
    private static final class State {
        final UUID id;final class_243 origin,direction;final float yaw;
        final Set<Integer> spawned=new HashSet<>();final List<Echo> echoes=new ArrayList<>();
        int age,remaining;boolean animated;
        State(NeungsaEchoVisualPayload p){id=p.player();origin=new class_243(p.x(),p.y(),p.z());direction=new class_243(p.dx(),p.dy(),p.dz());yaw=(float)Math.toDegrees(Math.atan2(-p.dx(),p.dz()));age=p.age();remaining=p.remaining();}
    }
    private static final class Echo {
        final int index;final ModifierLayer<IAnimation> animation=new ModifierLayer<>();int age;
        Echo(class_742 p,int index,int age){
            this.index=index;this.age=age;
            var clip=PlayerAnimationRegistry.getAnimation(KillerRankingMod.id("neungsa_katana_echo_"+(index%2==0?"right":"left")));
            animation.addModifierLast(new SpeedModifier(32));animation.addModifierLast(new MirrorModifier(p.method_6068()==class_1306.field_6182));
            if(clip!=null){animation.setAnimation((IAnimation)clip.playAnimation());for(int n=0;n<age;n++)animation.tick();}
        }
    }
    public static void register(){
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{
            var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new SpeedModifier(32));layer.addModifierLast(new LeftHandedHelperModifier(p));
            stack.addAnimLayer(3300,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
        });
        WorldRenderEvents.AFTER_ENTITIES.register(NeungsaEchoVfx::render);
        ClientTickEvents.END_CLIENT_TICK.register(c->{
            if(c.field_1687==null||c.method_1493())return;
            for(var s:new ArrayList<>(ACTIVE.values())){
                var raw=c.field_1687.method_18470(s.id);
                if(!(raw instanceof class_742 p)||!p.method_5805()||!p.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA)||s.remaining--<=0){remove(s.id);continue;}
                if(!s.animated)s.animated=animate(p,s);
                s.echoes.removeIf(e->{e.animation.tick();return ++e.age>=NeungsaEchoRules.ECHO_LIFE;});
                for(int i=0;i<NeungsaEchoRules.ECHO_COUNT;i++){
                    int age=s.age-NeungsaEchoRules.echoStart(i);
                    if(age>=0&&age<NeungsaEchoRules.ECHO_LIFE&&s.spawned.add(i)){s.echoes.add(new Echo(p,i,age));created++;}
                }
                s.age++;
            }
        });
    }
    public static void accept(NeungsaEchoVisualPayload p){
        if(p.remaining()==0){remove(p.player());return;}
        var old=ACTIVE.get(p.player());
        if(old==null||p.age()<old.age-5)ACTIVE.put(p.player(),new State(p));else old.remaining=p.remaining();
    }
    @SuppressWarnings("unchecked") private static boolean animate(class_742 p,State s){
        var layer=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(!(layer instanceof ModifierLayer<?> raw))return false;
        NeungsaDrawController.interruptIaidoRecovery(p);NeungsaDrawController.iaido(p);
        var clip=PlayerAnimationRegistry.getAnimation(KillerRankingMod.id("neungsa_katana_echo_sequence"+(p.method_52814().comp_1629()==class_8685.class_7920.field_41122?"_slim":"")));
        if(clip==null)return false;
        var k=(KeyframeAnimationPlayer)clip.playAnimation();for(int i=0;i<s.age*32;i++)k.tick();
        k.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);k.setFirstPersonConfiguration(new FirstPersonConfiguration(true,true,true,false));
        ((ModifierLayer<IAnimation>)raw).setAnimation(k);return true;
    }
    public static boolean active(UUID id){return ACTIVE.containsKey(id);}
    public static int age(UUID id){var s=ACTIVE.get(id);return s==null?-1:s.age;}
    public static int createdEchoes(){return created;}
    public static int renderedEchoes(){return rendered;}
    public static int segments(){return segments;}
    public static int echoCount(){return ACTIVE.values().stream().mapToInt(s->s.echoes.size()).sum();}
    private static void remove(UUID id){
        ACTIVE.remove(id);var c=class_310.method_1551();var p=c.field_1687==null?null:c.field_1687.method_18470(id);
        if(p instanceof class_742 player){var raw=PlayerAnimationAccess.getPlayerAssociatedData(player).get(LAYER);if(raw instanceof ModifierLayer<?> l)l.setAnimation(null);}
    }
    public static void clear(){for(var id:new ArrayList<>(ACTIVE.keySet()))remove(id);wide=slim=null;created=rendered=segments=0;}
    private static class_591<class_742> model(boolean narrow){
        var m=narrow?slim:wide;if(m==null){m=new class_591<>(class_310.method_1551().method_31974().method_32072(narrow?class_5602.field_27581:class_5602.field_27577),narrow);m.field_3448=false;if(narrow)slim=m;else wide=m;}return m;
    }
    private static void joint(class_630 part,String bone,Echo e,float delta){
        part.method_41923();var pos=e.animation.get3DTransform(bone,TransformType.POSITION,delta,new Vec3f(part.field_3657,part.field_3656,part.field_3655));
        var rot=e.animation.get3DTransform(bone,TransformType.ROTATION,delta,Vec3f.ZERO);
        part.method_2851(pos.getX(),pos.getY(),pos.getZ());part.method_33425(rot.getX(),rot.getY(),rot.getZ());part.field_37938=part.field_37939=part.field_37940=1;
    }
    private static void render(WorldRenderContext context){
        segments=0;var c=class_310.method_1551();if(c.field_1687==null||context.matrixStack()==null||context.consumers()==null)return;
        float partial=context.tickCounter().method_60637(false);var camera=context.camera().method_19326();int count=0;
        for(var s:ACTIVE.values()){
            var raw=c.field_1687.method_18470(s.id);if(!(raw instanceof class_742 p)||p.method_5767()||p.method_5707(camera)>4096||++count>8)continue;
            for(var e:s.echoes)renderEcho(context,p,s,e,partial);
            var stack=context.matrixStack();stack.method_22903();stack.method_22904(s.origin.field_1352-camera.field_1352,s.origin.field_1351-camera.field_1351,s.origin.field_1350-camera.field_1350);
            // Orient the whole forward area to the cast's original aim, including vertical aim.
            stack.method_22907(new Quaternionf().rotationTo(0,0,1,(float)s.direction.field_1352,(float)s.direction.field_1351,(float)s.direction.field_1350));
            var end=s.origin.method_1019(s.direction.method_1021(NeungsaEchoRules.REACH));
            var wall=c.field_1687.method_17742(new class_3959(s.origin,end,class_3959.class_3960.field_17558,class_3959.class_242.field_1348,p));
            float reach=(float)(wall.method_17783()==class_239.class_240.field_1332?s.origin.method_1022(wall.method_17784()):NeungsaEchoRules.REACH);
            var vertices=context.consumers().getBuffer(WeaponTrailRenderType.LAYER);
            for(int i=-1;i<=NeungsaEchoRules.ECHO_COUNT;i++){
                int beat=i<0?NeungsaEchoRules.OPEN_HIT:i==NeungsaEchoRules.ECHO_COUNT?NeungsaEchoRules.FINAL_HIT:NeungsaEchoRules.echoHit(i);
                float t=s.age+partial-beat+1;if(t<0||t>=4||reach<.5)continue;
                boolean big=i<0||i==NeungsaEchoRules.ECHO_COUNT;
                double angle=big?.08:(i%2==0?1:-1)*(.18+(i%5)*.14);
                // Each echo's cut occupies a new depth/height, rather than a fixed stack of identical flashes.
                float depth=Math.min(reach-.15f,.9f+((i*7+21)%20)/20f*Math.max(0,reach-1.1f));
                var stroke=new BishopBarrageMotion.Stroke(0,big?0:((i%5)-2)*.19f,depth,(float)Math.cos(angle),(float)Math.sin(angle),big?2f:1.7f,.035f,0,0);
                segments+=BishopBarrageVfx.renderStroke(stack,new Tint(vertices,.85f,true),stroke,t*1.5f);
            }
            stack.method_22909();
        }
    }
    private static void renderEcho(WorldRenderContext context,class_742 p,State s,Echo e,float partial){
        var c=class_310.method_1551();boolean first=p==c.field_1724&&c.field_1690.method_31044().method_31034();
        float age=e.age+partial,alpha=(first?.25f:.52f)*Math.min(1,(age+.5f)/.7f)*Math.clamp((5-age)/2,0,1);
        if(alpha<=0)return;e.animation.setupAnim(partial);
        var m=model(p.method_52814().comp_1629()==class_8685.class_7920.field_41122);
        joint(m.field_3391,"body",e,partial);joint(m.field_3398,"head",e,partial);joint(m.field_3401,"rightArm",e,partial);joint(m.field_27433,"leftArm",e,partial);joint(m.field_3392,"rightLeg",e,partial);joint(m.field_3397,"leftLeg",e,partial);
        m.field_3394.method_17138(m.field_3398);m.field_3483.method_17138(m.field_3391);m.field_3486.method_17138(m.field_3401);m.field_3484.method_17138(m.field_27433);m.field_3479.method_17138(m.field_3392);m.field_3482.method_17138(m.field_3397);
        var side=new class_243(s.direction.field_1350,0,-s.direction.field_1352).method_1029();
        var at=p.method_30950(partial).method_1019(side.method_1021((e.index%2==0?1:-1)*(.32+(e.index%3)*.18))).method_1019(s.direction.method_1021(.12+(e.index%4)*.12));
        var camera=context.camera().method_19326();var stack=context.matrixStack();stack.method_22903();stack.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);
        float scale=.9375f*p.method_55693();stack.method_22907(class_7833.field_40716.rotationDegrees(180-s.yaw));stack.method_22905(-scale,-scale,scale);stack.method_22904(0,-1.501,0);
        int color=((int)(alpha*255)<<24)|0xCFB5FF;var v=context.consumers().getBuffer(class_1921.method_42600(p.method_52814().comp_1626()));
        var parts=first?List.of(m.field_3401,m.field_27433,m.field_3486,m.field_3484):List.of(m.field_3391,m.field_3398,m.field_3394,m.field_3401,m.field_27433,m.field_3392,m.field_3397,m.field_3483,m.field_3486,m.field_3484,m.field_3479,m.field_3482);
        for(var part:parts)part.method_22699(stack,v,0xF000F0,class_4608.field_21444,color);
        var hand=p.method_6068();stack.method_22903();m.method_2803(hand,stack);stack.method_22904(hand==class_1306.field_6182?1.0/16:-1.0/16,10.0/16,0);
        var rot=e.animation.get3DTransform(hand==class_1306.field_6182?"leftItem":"rightItem",TransformType.ROTATION,partial,Vec3f.ZERO);
        stack.method_22907(new Quaternionf().rotationZYX(rot.getZ(),rot.getY(),rot.getX()));if(hand==class_1306.field_6182)stack.method_22907(class_7833.field_40716.rotationDegrees(180));stack.method_22905(.9f,.9f,.9f);
        var baked=((FabricBakedModelManager)c.method_1554()).getModel(KillerRankingMod.id("item/neungsa_katana"));
        var vertices=context.consumers().getBuffer(class_1921.method_23580(class_1059.field_5275));class_4597 tinted=type->new Tint(vertices,alpha,true);
        c.method_1480().method_23179(new class_1799(KillerRankingMod.NEUNGSA_KATANA),class_811.field_4315,false,stack,tinted,0xF000F0,class_4608.field_21444,baked);
        stack.method_22909();stack.method_22909();rendered++;
    }
    private record Tint(class_4588 target,float alpha,boolean purple) implements class_4588 {
        public class_4588 method_22912(float x,float y,float z){target.method_22912(x,y,z);return this;}
        public class_4588 method_1336(int r,int g,int b,int a){target.method_1336(purple?(int)(r*.84):r,purple?(int)(g*.62):g,b,(int)(a*alpha));return this;}
        public class_4588 method_22913(float u,float v){target.method_22913(u,v);return this;}
        public class_4588 method_60796(int u,int v){target.method_60796(u,v);return this;}
        public class_4588 method_22921(int u,int v){target.method_22921(u,v);return this;}
        public class_4588 method_22914(float x,float y,float z){target.method_22914(x,y,z);return this;}
    }
    private NeungsaEchoVfx(){ }
}
