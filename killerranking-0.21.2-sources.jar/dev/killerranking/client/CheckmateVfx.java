package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.CheckmateBoard;
import dev.killerranking.combat.CheckmateRules;
import dev.killerranking.network.CheckmateVisualPayload;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import java.util.*;

public final class CheckmateVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("checkmate_layer"),ANIMATION=KillerRankingMod.id("checkmate");
    private static final Map<UUID,State> ACTIVE=new HashMap<>();
    private static final class_1921 FLOOR=class_1921.method_42600(class_2960.method_60656("textures/block/white_concrete.png"));
    private static final class State {
        int remaining,age;boolean animated;final boolean aiming;
        final class_243 origin;final List<class_243> tiles;int selected;
        State(CheckmateVisualPayload p) { remaining=p.remaining();age=p.age();origin=p.origin();tiles=p.tiles();selected=p.selected();aiming=p.aiming(); }
    }
    public static void register() {
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)-> {
            var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new LeftHandedHelperModifier(p));
            stack.addAnimLayer(2600,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
        });
        WorldRenderEvents.AFTER_ENTITIES.register(CheckmateVfx::render);
    }
    public static void accept(CheckmateVisualPayload payload) {
        if(payload.remaining()<=0) { remove(payload.player());return; }
        ACTIVE.compute(payload.player(),(key,old)-> {
            if(old==null||old.aiming!=payload.aiming()||payload.age()<old.age-2) {
                if(old!=null&&old.animated) {
                    var client=class_310.method_1551();var p=client.field_1687==null?null:client.field_1687.method_18470(key);
                    if(p!=null) animate(p,-1);
                }
                return new State(payload);
            }
            old.remaining=payload.remaining();old.age=payload.age();old.selected=payload.selected();return old;
        });
    }
    public static boolean active(UUID id) { return ACTIVE.containsKey(id); }
    public static boolean aiming(UUID id) { var s=ACTIVE.get(id);return s!=null&&s.aiming; }
    public static int selectedTile() {
        var client=class_310.method_1551();if(client.field_1724==null||client.field_1687==null) return -1;
        var state=ACTIVE.get(client.field_1724.method_5667());
        return state==null||!state.aiming?-1:select(client.field_1724,state,1);
    }
    private static int select(net.minecraft.class_1657 p,State state,float delta) {
        var eye=p.method_5836(delta);var look=p.method_5828(delta);
        int selected=CheckmateBoard.select(eye,look,state.tiles);
        if(selected<0) return -1;
        var tile=state.tiles.get(selected);double distance=(tile.field_1351+.025-eye.field_1351)/look.field_1351;
        var point=eye.method_1019(look.method_1021(distance));
        var hit=p.method_37908().method_17742(new net.minecraft.class_3959(eye,point,
            net.minecraft.class_3959.class_3960.field_17558,net.minecraft.class_3959.class_242.field_1348,p));
        return hit.method_17783()==net.minecraft.class_239.class_240.field_1333||hit.method_17784().method_1025(point)<.01?selected:-1;
    }
    public static void tick(class_310 client) {
        if(client.method_1493()||client.field_1687==null) return;
        for(var id:new ArrayList<>(ACTIVE.keySet())) {
            var state=ACTIVE.get(id);var p=client.field_1687.method_18470(id);
            if(--state.remaining<=0||p==null||!p.method_5805()||p.method_7325()) { remove(id);continue; }
            if(!state.aiming&&!state.animated) state.animated=animate(p,state.age);
            state.age++;
        }
    }
    private static void remove(UUID id) {
        ACTIVE.remove(id);var client=class_310.method_1551();
        if(client.field_1687!=null) { var p=client.field_1687.method_18470(id);if(p!=null) animate(p,-1); }
    }
    public static void clear() { for(var id:new ArrayList<>(ACTIVE.keySet())) remove(id); }
    public static int platformCount() { return ACTIVE.values().stream().mapToInt(s->s.tiles.size()).sum(); }
    private static void render(WorldRenderContext context) {
        if(context.matrixStack()==null||context.consumers()==null) return;
        var camera=context.camera().method_19326();var stack=context.matrixStack();
        class_4588 vertices=null;
        float delta=context.tickCounter().method_60637(false);
        for(var entry:ACTIVE.entrySet()) {
            var p=context.world().method_18470(entry.getKey());var state=entry.getValue();
            if(p==null||p.method_5767()||p.method_7325()||state.origin.method_1025(camera)>1024) continue;
            if(vertices==null) vertices=context.consumers().getBuffer(FLOOR);
            float fade=state.aiming?1:(float)Math.clamp((CheckmateRules.HIT+8-state.age-delta)/8,0,1);
            if(fade<=0) continue;
            int selected=state.aiming&&p==class_310.method_1551().field_1724?select(p,state,delta):state.selected;
            for(int i=0;i<state.tiles.size();i++) tile(stack,vertices,state.tiles.get(i).method_1020(camera),i==selected,fade);
            if(selected>=0&&selected<state.tiles.size()) {
                var end=state.tiles.get(selected);var corner=CheckmateBoard.corner(state.origin,end);
                guide(stack,vertices,state.origin.method_1020(camera),corner.method_1020(camera),fade);
                guide(stack,vertices,corner.method_1020(camera),end.method_1020(camera),fade);
            }
            tile(stack,vertices,state.origin.method_1020(camera),false,fade*.65f);
        }
    }
    private static void tile(class_4587 stack,class_4588 v,class_243 c,boolean selected,float fade) {
        double h=CheckmateBoard.HALF,y=c.field_1351+.025;
        for(int x=0;x<2;x++) for(int z=0;z<2;z++) {
            float shade=(x+z)%2==0?1f:.06f;
            rect(stack,v,c.field_1352-h+x*h,y,c.field_1350-h+z*h,c.field_1352-h+(x+1)*h,c.field_1350-h+(z+1)*h,shade,fade*(selected?.8f:.48f));
        }
        double w=selected?.065:.03;float alpha=fade*(selected?1:.65f);
        rect(stack,v,c.field_1352-h,y+.002,c.field_1350-h,c.field_1352+h,c.field_1350-h+w,1,alpha);
        rect(stack,v,c.field_1352-h,y+.002,c.field_1350+h-w,c.field_1352+h,c.field_1350+h,1,alpha);
        rect(stack,v,c.field_1352-h,y+.002,c.field_1350-h,c.field_1352-h+w,c.field_1350+h,1,alpha);
        rect(stack,v,c.field_1352+h-w,y+.002,c.field_1350-h,c.field_1352+h,c.field_1350+h,1,alpha);
    }
    private static void guide(class_4587 stack,class_4588 v,class_243 a,class_243 b,float fade) {
        double y=Math.min(a.field_1351,b.field_1351)+.035,w=.055;
        rect(stack,v,Math.min(a.field_1352,b.field_1352)-w,y,Math.min(a.field_1350,b.field_1350)-w,Math.max(a.field_1352,b.field_1352)+w,Math.max(a.field_1350,b.field_1350)+w,1,fade*.8f);
    }
    private static void rect(class_4587 stack,class_4588 v,double x1,double y,double z1,double x2,double z2,float shade,float alpha) {
        var pose=stack.method_23760();
        for(int i=0;i<4;i++) v.method_22918(pose.method_23761(),(float)(i<2?x1:x2),(float)y,(float)(i==0||i==3?z1:z2))
            .method_22915(shade,shade,shade,alpha).method_22913(i<2?0:1,i==0||i==3?0:1)
            .method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(pose,0,1,0);
    }
    @SuppressWarnings("unchecked")
    private static boolean animate(net.minecraft.class_1657 entity,int age) {
        if(!(entity instanceof class_742 player)) return false;
        var layer=PlayerAnimationAccess.getPlayerAssociatedData(player).get(LAYER);
        if(!(layer instanceof ModifierLayer<?>)) return false;
        IAnimation animation=null;
        if(age>=0) {
            var data=PlayerAnimationRegistry.getAnimation(ANIMATION);if(data==null) return false;
            animation=(IAnimation)data.playAnimation();
            if(animation instanceof KeyframeAnimationPlayer frames) {
                for(int t=0;t<age;t++) frames.tick();
                frames.setFirstPersonMode(dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode.THIRD_PERSON_MODEL);
                frames.setFirstPersonConfiguration(new dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration(true,true,true,true));
            }
        }
        ((ModifierLayer<IAnimation>)layer).setAnimation(animation);return true;
    }
    private CheckmateVfx() { }
}
