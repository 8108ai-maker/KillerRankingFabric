package dev.killerranking.client;

import dev.killerranking.combat.SpiritBranch;
import net.minecraft.class_1657;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;

/** Branch-colored smoke and small light motes rise around the large character. */
final class SpiritAuraParticle extends class_4003 {
    private final class_1657 owner;
    private final class_4002 sprites;
    private final boolean spark;
    private final SpiritBranch branch;
    private final float side, height, phase, size, rear;
    SpiritAuraParticle(class_638 world, class_1657 owner, class_4002 sprites, boolean spark, SpiritBranch branch) {
        super(world, owner.method_23317(), owner.method_23318(), owner.method_23321());
        this.owner = owner; this.sprites = sprites; this.spark = spark; this.branch = branch;
        field_3862 = false;
        field_3847 = spark ? 18 + field_3840.method_43048(9) : 27 + field_3840.method_43048(10);
        side = (field_3840.method_43057() - .5f) * 3.45f;
        height = field_3840.method_43057() * 3.0f - .05f;
        phase = field_3840.method_43057() * 6.283f;
        rear = .98f + field_3840.method_43057() * .25f;
        size = spark ? .06f + field_3840.method_43057() * .045f : .40f + field_3840.method_43057() * .24f;
        if (branch == SpiritBranch.KING_AND_KILL) {
            float shade = spark ? 1 : field_3840.method_43057() < .20f ? .32f + field_3840.method_43057() * .12f : .76f + field_3840.method_43057() * .24f;
            method_3084(shade, shade, shade);
        }
        else if (spark) method_3084(.68f, 1, .42f);
        else if (field_3840.method_43057() < .20f) method_3084(.035f, .22f, .055f);
        else method_3084(.10f + field_3840.method_43057() * .15f, .70f + field_3840.method_43057() * .25f, .16f);
        field_3841 = 0;
        place(); field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871;
        method_18142(sprites);
    }
    private void place() {
        float progress = field_3866 / (float) field_3847;
        double yaw = Math.toRadians(owner.field_6283);
        double sweep = side * (1 + progress * .12) + Math.sin(phase + progress * 4) * .10;
        double back = rear + Math.cos(phase + progress * 3) * .08;
        method_3063(owner.method_23317() + Math.cos(yaw) * sweep + Math.sin(yaw) * back,
            owner.method_23318() + height + progress * (spark ? 1.75 : 1.55),
            owner.method_23321() + Math.sin(yaw) * sweep - Math.cos(yaw) * back);
    }
    @Override public void method_3070() {
        field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871; field_3857 = field_3839;
        if (owner.method_31481() || !owner.method_5805() || owner.method_5767() || owner.method_7325()) { method_3085(); return; }
        var currentBranch = SpiritVfx.branch(owner.method_5667());
        if (currentBranch != SpiritBranch.NONE && currentBranch != branch) { method_3085(); return; }
        if (currentBranch == SpiritBranch.NONE) field_3866 = Math.max(field_3866, field_3847 - 4);
        if (++field_3866 >= field_3847) { method_3085(); return; }
        float progress = field_3866 / (float) field_3847;
        field_3841 = Math.min(1, field_3866 / 4f) * Math.min(1, (field_3847 - field_3866) / 8f) * (spark ? .85f : .43f);
        field_17867 = size * (1.05f - progress * .45f);
        field_3839 = (float) Math.sin(phase + progress * 3) * .16f;
        place(); method_18142(sprites);
        if ((field_3874-field_3858)*(field_3874-field_3858) + (field_3871-field_3856)*(field_3871-field_3856) > 16) { field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871; }
    }
    @Override public void method_3074(class_4588 vertices, class_4184 camera, float delta) {
        var currentBranch = SpiritVfx.branch(owner.method_5667());
        if (!KillingIntentVfx.hiddenForCamera(owner) && (currentBranch == branch || currentBranch == SpiritBranch.NONE))
            super.method_3074(vertices, camera, delta);
    }
    @Override protected int method_3068(float delta) { return 0xF000F0; }
    @Override public class_3999 method_18122() { return class_3999.field_17829; }
}
