package dev.killerranking.client;

import net.minecraft.class_1657;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;

/** The same blocky smoke sprites as Killing Aura, clustered into red/orange flame-shaped eyes. */
final class PoisonFlameParticle extends class_4003 {
    private static final float[][] OUTER = {
        {0,0}, {.23f,.03f}, {.56f,.04f}, {.88f,.04f}, {.95f,.10f}, {.90f,.17f},
        {1,.27f}, {.98f,.39f}, {.90f,.48f}, {.98f,.56f}, {1.02f,.70f}, {.95f,.77f},
        {.94f,1}, {.73f,.91f}, {.62f,.78f}, {.52f,.58f}, {.39f,.39f}, {.24f,.25f}, {.12f,.16f}
    };
    private static final float[][] INNER = {
        {.025f,.065f}, {.24f,.12f}, {.46f,.13f}, {.65f,.18f}, {.76f,.25f}, {.77f,.44f},
        {.73f,.49f}, {.65f,.48f}, {.56f,.45f}, {.46f,.38f}, {.34f,.29f}, {.20f,.23f}
    };
    private final class_1657 owner;
    private final class_4002 sprites;
    private final int side;
    private final boolean orange;
    private final float px, py, size, phase;
    PoisonFlameParticle(class_638 world, class_1657 owner, class_4002 sprites, int side, boolean orange) {
        super(world, owner.method_23317(), owner.method_23318(), owner.method_23321());
        this.owner = owner; this.sprites = sprites; this.side = side; this.orange = orange;
        field_3862 = false;
        field_3847 = 20 + field_3840.method_43048(7);
        phase = field_3840.method_43057() * 6.283f;
        size = (orange ? .110f + field_3840.method_43057() * .035f : .130f + field_3840.method_43057() * .040f)
            * (PoisonVfx.salmosa(owner.method_5667()) ? SalmosaSnakeModel.HEAD_SCALE : 1);
        float sx, sy;
        do {
            sx = field_3840.method_43057() * 1.02f;
            sy = field_3840.method_43057();
        } while (!inside(orange ? INNER : OUTER, sx, sy) || (!orange && inside(INNER, sx, sy)));
        px = sx; py = sy;
        if (orange) method_3084(1, .32f + field_3840.method_43057() * .12f, .015f);
        else method_3084(.93f + field_3840.method_43057() * .07f, .012f, .025f);
        field_3841 = 0; field_17867 = size;
        place(); field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871;
        method_18142(sprites);
    }
    private static boolean inside(float[][] polygon, float x, float y) {
        boolean hit = false;
        for (int i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            var a = polygon[i]; var b = polygon[j];
            if ((a[1] > y) != (b[1] > y) && x < (b[0]-a[0]) * (y-a[1]) / (b[1]-a[1]) + a[0]) hit = !hit;
        }
        return hit;
    }
    private void place() {
        float progress = field_3866 / (float) field_3847;
        float flickerX = (float) Math.sin(phase + progress * 4) * .018f;
        float flickerY = (float) Math.sin(phase + progress * 3) * .022f;
        boolean salmosa = PoisonVfx.salmosa(owner.method_5667());
        float localX = side * ((salmosa ? .26f : .12f) + (px + flickerX) * (salmosa ? .23f : .32f));
        float localY = (salmosa ? .10f : .12f) + (py + flickerY) * (salmosa ? .12f : .23f);
        float localZ = (salmosa ? .65f : .57f) - px * (salmosa ? .39f : .23f) + (orange ? .013f : 0);
        var origin = PoisonSnakeModel.headPoint(owner, 0, localX, localY, localZ);
        // New particles start in the eye silhouette; older ones rise and disperse like the aura.
        double yaw = Math.toRadians(owner.field_6283);
        double drift = Math.sin(phase + progress * 4) * .04 * progress;
        method_3063(owner.method_23317() + origin.x + Math.cos(yaw) * drift,
            owner.method_23318() + origin.y + progress * (salmosa ? .28 * SalmosaSnakeModel.HEAD_SCALE : .65),
            owner.method_23321() + origin.z + Math.sin(yaw) * drift);
    }
    @Override public void method_3070() {
        field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871; field_3857 = field_3839;
        if (owner.method_31481() || !owner.method_5805() || owner.method_5767() || owner.method_7325()) { method_3085(); return; }
        if (!PoisonVfx.active(owner.method_5667())) field_3866 = Math.max(field_3866, field_3847 - 4);
        if (++field_3866 >= field_3847) { method_3085(); return; }
        float progress = field_3866 / (float) field_3847;
        field_3841 = Math.min(1, field_3866 / 3f) * Math.min(1, (field_3847 - field_3866) / 7f) * .82f;
        field_17867 = size * (1.05f - progress * .45f);
        field_3839 = (float) Math.sin(phase + progress * 3) * .12f;
        place(); method_18142(sprites);
        if ((field_3874-field_3858)*(field_3874-field_3858) + (field_3871-field_3856)*(field_3871-field_3856) > 16) { field_3858 = field_3874; field_3838 = field_3854; field_3856 = field_3871; }
    }
    @Override public void method_3074(class_4588 vertices, class_4184 camera, float delta) {
        if (!KillingIntentVfx.hiddenForCamera(owner)) super.method_3074(vertices, camera, delta);
    }
    @Override protected int method_3068(float delta) { return 0xF000F0; }
    @Override public class_3999 method_18122() { return class_3999.field_17829; }
}
