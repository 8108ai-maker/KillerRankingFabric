package dev.killerranking.client;

import dev.killerranking.network.KatanaHolstersPayload;
import dev.killerranking.visual.KatanaHolsters;
import dev.killerranking.visual.KatanaHolsterSelection;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_7923;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ClientKatanaHolsters {
    private static final Map<UUID,KatanaHolstersPayload> SLOTS = new HashMap<>();
    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(KatanaHolstersPayload.TYPE,(v,c) -> c.client().execute(() -> SLOTS.put(v.player(),v)));
        ClientPlayConnectionEvents.JOIN.register((h,s,c) -> SLOTS.clear());
        ClientPlayConnectionEvents.DISCONNECT.register((h,c) -> SLOTS.clear());
    }
    public static KatanaHolsterSelection.Slots<class_1799> slots(class_742 player) {
        if (player == class_310.method_1551().field_1724) return KatanaHolsters.inventory(player);
        var value = SLOTS.get(player.method_5667());
        if (value == null) return KatanaHolsterSelection.select(java.util.List.of(player.method_6047(),player.method_6079()),
            KatanaHolsters::katana,s -> class_7923.field_41178.method_10221(s.method_7909()).toString());
        return new KatanaHolsterSelection.Slots<>(new class_1799(class_7923.field_41178.method_10223(value.waist())),new class_1799(class_7923.field_41178.method_10223(value.back())));
    }
    private ClientKatanaHolsters() { }
}
