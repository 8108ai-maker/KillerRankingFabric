package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.MadnessLeapRules;
import dev.killerranking.network.MadnessLeapVisualPayload;
import dev.kosmx.playerAnim.api.firstPerson.*;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.minecraftApi.*;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import java.util.*;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;

/** Three upright aerial turns followed by an axe strike. Targeting never locks the model or camera. */
public final class MadnessLeapVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("madness_leap_layer"),ANIMATION=KillerRankingMod.id("madness_leap");
    private static final Map<UUID,State> ACTIVE=new HashMap<>();
    private static final class State {
        int phase,age,ttl=25;float yaw;boolean animated;
        State(MadnessLeapVisualPayload p){update(p);}
        void update(MadnessLeapVisualPayload p){phase=p.phase();age=p.age();yaw=p.yaw();ttl=25;}
    }
    public static void register(){
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{
            var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new LeftHandedHelperModifier(p));
            stack.addAnimLayer(2850,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
        });
    }
    public static void accept(MadnessLeapVisualPayload p){
        if(p.phase()==0){remove(p.player());return;}
        ACTIVE.compute(p.player(),(id,old)->{
            if(old==null||old.phase!=p.phase()||p.age()<old.age-3)return new State(p);
            old.update(p);return old;
        });
    }
    public static boolean active(UUID id){return ACTIVE.containsKey(id);}
    public static boolean casting(UUID id){var s=ACTIVE.get(id);return s!=null&&s.phase==MadnessLeapRules.CAST;}
    public static float yaw(UUID id,float original){var s=ACTIVE.get(id);return s!=null&&s.phase==MadnessLeapRules.CAST?s.yaw:original;}
    public static void clear(){for(var id:new ArrayList<>(ACTIVE.keySet()))remove(id);}
    private static void remove(UUID id){
        ACTIVE.remove(id);var c=class_310.method_1551();if(c.field_1687==null)return;var p=c.field_1687.method_18470(id);
        if(p instanceof class_742 player){var layer=PlayerAnimationAccess.getPlayerAssociatedData(player).get(LAYER);if(layer instanceof ModifierLayer<?> l)l.setAnimation(null);}
    }
    @SuppressWarnings("unchecked")
    private static boolean animate(class_742 p,State s){
        var layer=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);var data=PlayerAnimationRegistry.getAnimation(ANIMATION);
        if(!(layer instanceof ModifierLayer<?> l)||data==null)return false;
        var animation=(IAnimation)data.playAnimation();
        if(animation instanceof KeyframeAnimationPlayer k){
            for(int i=0;i<Math.min(s.age,MadnessLeapRules.DURATION);i++)k.tick();
            k.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);k.setFirstPersonConfiguration(new FirstPersonConfiguration(true,true,true,true));
        }
        ((ModifierLayer<IAnimation>)l).setAnimation(animation);return true;
    }
    public static void tick(class_310 c){
        if(c.field_1687==null||c.method_1493())return;
        for(var id:new ArrayList<>(ACTIVE.keySet())){
            var s=ACTIVE.get(id);var p=c.field_1687.method_18470(id);
            if(--s.ttl<=0||p==null||!p.method_5805()||p.method_7325()
                ||s.phase==MadnessLeapRules.CAST&&s.age>=MadnessLeapRules.DURATION){remove(id);continue;}
            if(s.phase==MadnessLeapRules.CAST&&!s.animated&&p instanceof class_742 player)s.animated=animate(player,s);
            s.age++;
        }
    }
    private MadnessLeapVfx() { }
}
