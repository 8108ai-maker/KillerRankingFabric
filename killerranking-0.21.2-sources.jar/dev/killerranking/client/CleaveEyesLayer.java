package dev.killerranking.client;
import net.minecraft.class_1007;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.client.renderer.*;
public final class CleaveEyesLayer extends class_3887<class_742,class_591<class_742>> {
    private static final class_1921 EYES=class_1921.method_23026(class_2960.method_60656("textures/block/white_concrete.png"));
    public CleaveEyesLayer(class_1007 renderer){super(renderer);}
    @Override public void render(class_4587 stack,class_4597 buffers,int light,class_742 p,float walk,float speed,float delta,float time,float yaw,float pitch){
        if(!CleaveVfx.full(p.method_5667())||p.method_5767()||p.method_7325())return;
        if(net.minecraft.class_310.method_1551().field_1690.method_31044().method_31034()&&p==net.minecraft.class_310.method_1551().field_1724)return;
        stack.method_22903();method_17165().field_3398.method_22703(stack);
        var v=CleaveSilhouetteBuffers.unwrap(buffers).getBuffer(EYES);
        for(float sign:new float[]{-1,1}){
            quad(stack,v,sign,.19f,.055f,.20f,.16f);
            quad(stack,v,sign,.16f,.065f,.13f,1);
        }
        stack.method_22909();
    }
    private static void quad(class_4587 s,class_4588 v,float sign,float outer,float inner,float h,float alpha){
        float[] xs={sign*outer,sign*inner,sign*inner,sign*outer};float[] ys={-.285f,-.245f,-.225f,-.255f};
        if(alpha<1){for(int i=0;i<4;i++)ys[i]-=.012f;}
        for(int i=0;i<4;i++)v.method_22918(s.method_23760().method_23761(),xs[i],ys[i],-.287f-(alpha<1?.0001f:0)).method_22915(1f,1f,1f,alpha)
            .method_22913(i==0||i==3?0:1,i<2?0:1).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(s.method_23760(),0,0,-1);
    }
}
