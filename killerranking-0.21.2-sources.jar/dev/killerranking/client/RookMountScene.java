package dev.killerranking.client;

import dev.killerranking.combat.RookMountPose;
import dev.killerranking.visual.RookMountLayout;
import java.util.UUID;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1007;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_742;

/** Hide the standing caster and draw its animated skin in a separate grounded scene. */
public final class RookMountScene {
    private static UUID rendering;
    private static long hidden,frames;

    public static boolean hideOriginal(class_742 player) {
        boolean hide=!player.method_5667().equals(rendering)&&RookVfx.mountVictim(player.method_5667())!=null;
        if(hide)hidden++;
        return hide;
    }
    public static class_243 position(class_742 player,class_1309 victim,float delta) {
        var center=victim.method_30950(delta);
        var away=new class_243(player.method_23317()-victim.method_23317(),0,player.method_23321()-victim.method_23321());
        if(away.method_1027()<.0001){var look=player.method_5720();away=new class_243(-look.field_1352,0,-look.field_1350);}
        double root=RookMountLayout.rootOffset(victim.method_17682(),victim.method_17681(),RookMountPose.inverted(victim),player.method_55693());
        return center.method_1019(away.method_1029().method_1021(.15)).method_1031(0,root,0);
    }
    public static void render(WorldRenderContext context) {
        var c=class_310.method_1551();
        if(c.field_1687==null||context.matrixStack()==null||context.consumers()==null)return;
        float delta=context.tickCounter().method_60637(false);
        var camera=context.camera().method_19326();var stack=context.matrixStack();
        for(var player:c.field_1687.method_18456()) {
            var victim=RookVfx.mountVictim(player.method_5667());
            if(victim==null||player.method_19538().method_1025(camera)>4096)continue;
            var at=position(player,victim,delta);
            var renderer=(class_1007)c.method_1561().method_3953(player);
            stack.method_22903();stack.method_22904(at.field_1352-camera.field_1352,at.field_1351-camera.field_1351,at.field_1350-camera.field_1350);
            rendering=player.method_5667();
            try {
                renderer.method_4215(player,player.method_36454(),delta,stack,context.consumers(),c.method_1561().method_23839(player,delta));
                frames++;
            } finally {rendering=null;stack.method_22909();}
        }
    }
    public static long renderedFrames(){return frames;}
    public static long hiddenFrames(){return hidden;}
    private RookMountScene() { }
}
