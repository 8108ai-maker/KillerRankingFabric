package dev.killerranking.client;
import dev.killerranking.entity.BishopFollower;
import dev.killerranking.KillerRankingMod;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
import dev.kosmx.playerAnim.core.util.Vec3f;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;

/** Authored weapon-style clips drive the whole skeleton; the cloak is one connected sheet. */
public final class BishopModel extends class_572<BishopFollower> {
    public static final class_5601 LAYER=new class_5601(class_2960.method_60655("killerranking","bishop_follower"),"main");
    private KeyframeAnimationPlayer motion;
    private float partial;
    public float clothFlow,clothAge;
    public BishopModel(class_630 root){super(root,net.minecraft.class_1921::method_23576);}
    public static class_5607 layer(){
        var mesh=class_572.method_32011(class_5605.field_27715,0);var root=mesh.method_32111();
        root.method_32117("hat",class_5606.method_32108(),class_5603.field_27701);
        return class_5607.method_32110(mesh,128,128);
    }
    @Override public void setupAnim(BishopFollower e,float walk,float speed,float age,float yaw,float pitch){
        for(var part:new class_630[]{field_3398,field_3394,field_3391,field_3401,field_27433,field_3392,field_3397})part.method_41923();
        super.method_17087(e,walk,speed,age,yaw,pitch);
        partial=class_3532.method_15363(age-e.field_6012,0,1);motion=null;
        String clip=null;float time=0;
        if(e.striking()){clip=switch(e.attackStyle()){case 3->"bishop_combo";case 4->"bishop_stab_combo";case 2->"bishop_cut";default->"bishop_stab";};time=e.attackPoseTick()+partial;}
        else if(e.leapPoseTick()>0){clip="bishop_leap";time=e.leapPoseTick()+partial;}
        else if(e.fighting()&&speed>.02f){clip="bishop_sprint";time=walk*1.65f;}
        if(e.barrageEcho())time=Math.min(27,time*1.4f);
        if(clip!=null&&PlayerAnimationRegistry.getAnimation(KillerRankingMod.id(clip)) instanceof KeyframeAnimation frames){
            if(clip.equals("bishop_sprint"))time%=12;
            motion=new KeyframeAnimationPlayer(frames,(int)time);partial=time-(int)time;motion.setupAnim(partial);
            apply("torso",field_3391);apply("head",field_3398);apply("rightArm",field_3401);apply("leftArm",field_27433);apply("rightLeg",field_3392);apply("leftLeg",field_3397);
        }
        field_3401.field_3665=field_27433.field_3665=e.striking();
        // Head/look direction and the mask retain their own bone, independent of the torso clip.
        field_3394.method_17138(field_3398);
        clothAge=age;clothFlow=e.leaping()?1:class_3532.method_15363(speed*(e.fighting()?1.2f:.4f),0,1);
    }
    private Vec3f sample(String name,TransformType type,Vec3f base){return motion==null?base:motion.get3DTransform(name,type,partial,base);}
    private void apply(String name,class_630 part){
        var p=sample(name,TransformType.POSITION,new Vec3f(part.field_3657,part.field_3656,part.field_3655));var r=sample(name,TransformType.ROTATION,new Vec3f(part.field_3654,part.field_3675,part.field_3674));
        part.method_2851(p.getX(),p.getY(),p.getZ());part.method_33425(r.getX(),r.getY(),r.getZ());part.field_37938=part.field_37939=part.field_37940=1;
    }
    public void globalPose(class_4587 stack){pose(stack,"body",Vec3f.ZERO);}
    public Vec3f trail(){return sample("nightBatTrail",TransformType.POSITION,Vec3f.ZERO);}
    public void daggerPose(class_4587 stack){
        // Rotate about the handle inside the palm, not the item's center.
        stack.method_46416(0,-2/16f,0);pose(stack,"rightItem",Vec3f.ZERO);stack.method_46416(0,2/16f,0);
    }
    private void pose(class_4587 stack,String name,Vec3f base){
        var p=sample(name,TransformType.POSITION,base);var r=sample(name,TransformType.ROTATION,base);
        stack.method_46416(p.getX()/16,p.getY()/16,p.getZ()/16);stack.method_22907(class_7833.field_40718.rotation(r.getZ()));stack.method_22907(class_7833.field_40716.rotation(r.getY()));stack.method_22907(class_7833.field_40714.rotation(r.getX()));
    }
    @Override public void method_2828(class_4587 stack,net.minecraft.class_4588 v,int light,int overlay,int color){stack.method_22903();globalPose(stack);super.method_2828(stack,v,light,overlay,color);stack.method_22909();}
}
