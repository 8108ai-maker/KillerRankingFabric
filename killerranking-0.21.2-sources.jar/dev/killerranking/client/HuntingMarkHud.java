package dev.killerranking.client;

import dev.killerranking.network.HuntingMarkPayload;
import java.util.Locale;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_7833;

public final class HuntingMarkHud {
    private static HuntingMarkPayload mark = HuntingMarkPayload.CLEAR;
    private static int remaining;
    public static void accept(HuntingMarkPayload value) { mark = value; remaining = Math.clamp(value.ticks(), 0, 180); }
    public static void clear() { accept(HuntingMarkPayload.CLEAR); }
    public static boolean active() { return mark.active() && remaining > 0; }
    public static HuntingMarkPayload get() { return mark; }
    public static void tick(class_310 client) { if (!client.method_1493() && remaining > 0) remaining--; }
    public static void render(class_332 g) {
        var client = class_310.method_1551();
        if (!active() || client.field_1724 == null || !client.field_1724.method_5805() || client.field_1724.method_7325() || client.field_1690.field_1842 || client.field_1755 != null) return;
        FixedUi.begin(g);
        int width = Math.min(250, FixedUi.width() - 12), x = (FixedUi.width() - width) / 2, y = 8;
        double dx = mark.x() - client.field_1724.method_23317(), dy = mark.y() - client.field_1724.method_23318(), dz = mark.z() - client.field_1724.method_23321();
        double distance = Math.sqrt(dx*dx + dy*dy + dz*dz);
        g.method_25294(x, y, x + width, y + 33, 0xCE151021);
        g.method_25294(x, y, x + 2, y + 33, 0xFFBF84F2);
        var font = client.field_1772;
        String target = "사냥표식 · " + mark.name() + " · " + Math.round(distance) + "m";
        g.method_51433(font, font.method_27523(target, width - 31), x + 26, y + 5, 0xFFE4C0FF, false);
        String detail = String.format(Locale.ROOT, "X %.0f Y %.0f Z %.0f · %.1fs", mark.x(), mark.y(), mark.z(), remaining / 20f);
        g.method_51433(font, font.method_27523(detail, width - 31), x + 26, y + 19, 0xFFFFFFFF, false);
        float angle = class_3532.method_15393((float) Math.toDegrees(Math.atan2(-dx, dz)) - client.field_1724.method_36454());
        g.method_51448().method_22903(); g.method_51448().method_46416(x + 14, y + 16, 0); g.method_51448().method_22907(class_7833.field_40718.rotationDegrees(angle));
        g.method_25294(-1, -7, 2, 6, 0xFFDCAAFF);
        for (int i = 0; i < 5; i++) g.method_25294(-i, -7 + i, i + 1, -6 + i, 0xFFDCAAFF);
        g.method_51448().method_22909();
        FixedUi.end(g);
    }
    private HuntingMarkHud() { }
}
