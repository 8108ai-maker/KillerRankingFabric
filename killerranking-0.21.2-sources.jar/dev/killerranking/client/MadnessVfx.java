package dev.killerranking.client;

import dev.killerranking.Trait;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_4066;
import java.util.*;

/** Mixed Madness uses the same server-owned introduction timer as the trait toggle. */
public final class MadnessVfx {
    public static boolean active(UUID id) { return TraitVisuals.trait(id) == Trait.MIXED_MADNESS && TraitVisuals.intro(id) > 0; }
    private static List<class_1657> visible(class_310 client) {
        var camera=client.method_1560();
        if (client.field_1687==null || camera==null) return List.of();
        return client.field_1687.method_18456().stream().filter(p -> active(p.method_5667()) && !KillingIntentVfx.hiddenForCamera(p) && p.method_5858(camera)<=1024)
            .sorted(Comparator.comparingDouble(p -> p.method_5858(camera))).limit(4).map(p -> (class_1657)p).toList();
    }
    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (context.matrixStack()==null || context.consumers()==null) return;
            float delta=context.tickCounter().method_60637(false);
            for(var player:visible(class_310.method_1551())) {
                float left=TraitVisuals.intro(player.method_5667())-delta;
                float alpha=Math.min(1,(100-left)/8f)*Math.min(1,left/8f);
                MadnessGlyph.render(context,player,delta,Math.max(0,alpha),100-left);
            }
        });
    }
    public static void tick(class_310 client) {
        var sprites=KillingIntentVfx.sprites();
        if (client.field_1687==null || client.method_1493() || sprites==null) return;
        var setting=client.field_1690.method_42475().method_41753();
        int count=setting==class_4066.field_18199?1:setting==class_4066.field_18198?4:8;
        for(var player:visible(client)) {
            for(int i=0;i<count;i++) client.field_1713.method_3058(new MadnessAuraParticle(client.field_1687,player,sprites,false));
            if(setting!=class_4066.field_18199) client.field_1713.method_3058(new MadnessAuraParticle(client.field_1687,player,sprites,true));
        }
    }
    private MadnessVfx() { }
}
