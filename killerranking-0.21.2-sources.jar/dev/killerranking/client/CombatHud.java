package dev.killerranking.client;

import dev.killerranking.Trait;
import dev.killerranking.combat.TraitLevels;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class CombatHud {
	private CombatHud() { }
	public static int traitColor() {
        return 0xFF000000 | TraitVisuals.color(ClientCombatStatus.trait(), ClientDashboard.branch());
	}
	public static String seconds(int ticks) { return String.format(Locale.ROOT, "%.1fs", ticks / 20.0F); }
	public static class_2561 traitName() {
		if (ClientCombatStatus.trait() == Trait.FIGHTING_SPIRIT && ClientDashboard.branch() != dev.killerranking.combat.SpiritBranch.NONE)
            return class_2561.method_43470("Lv." + ClientCombatStatus.level() + " " + ClientDashboard.branch().label());
        return class_2561.method_43470("Lv." + ClientCombatStatus.level() + " ").method_10852(class_2561.method_43471("trait.killerranking." + ClientCombatStatus.trait().id()));
	}
	public static class_2561 traitDescription() {
		if (ClientCombatStatus.trait() == Trait.FIGHTING_SPIRIT) {
            var branch = ClientDashboard.branch(); var d = ClientDashboard.get(); int level = ClientCombatStatus.level();
            if (branch != dev.killerranking.combat.SpiritBranch.NONE) {
                int move = branch.movement(level, d != null && d.checkmate());
                return class_2561.method_43470("공격 +" + branch.attack(level) + "% · 방어 +" + branch.defense(level) + "% / 공속 +" + branch.attackSpeed(level) + "% · 이속 " + (move > 0 ? "+" : "") + move + "%. 켜진 동안 적용. 상세 정보: 스탯창");
            }
            return class_2561.method_43470("떡발 / 킹앤킬 중 한 분기를 아래 버튼에서 선택하세요. 선택 전에는 기존 투기 효과가 유지됩니다.");
        }
        String key = "trait.killerranking." + ClientCombatStatus.trait().id() + ".description";
		return switch (ClientCombatStatus.trait()) {
			case KILLING_INTENT -> class_2561.method_43469(key, ClientCombatStatus.power(), seconds(ClientCombatStatus.effectTotalTicks()));
			case FIGHTING_SPIRIT -> class_2561.method_43469(key, ClientCombatStatus.highHealthPercent(), ClientCombatStatus.halfHealthPercent(), ClientCombatStatus.lowHealthPercent(), String.format(Locale.ROOT, "%.2fs", TraitLevels.parryWindow(ClientCombatStatus.level()) / 20.0F));
			case MIXED_MADNESS -> class_2561.method_43469(key, ClientCombatStatus.power(), ClientDashboard.get() == null ? TraitLevels.bonusPercent(5, ClientCombatStatus.level()) : ClientDashboard.get().madnessSpeedPercent());
			case POISON_AURA -> class_2561.method_43469(key, seconds(ClientCombatStatus.effectTotalTicks()), dev.killerranking.combat.PoisonEffects.resistance(ClientCombatStatus.level()), dev.killerranking.combat.PoisonEffects.speed(ClientCombatStatus.level()));
			default -> class_2561.method_43471(key);
		};
	}
	public static class_2561 traitStatus() {
        if (!TraitVisuals.enabled()) return class_2561.method_43470("꺼짐 [" + KillerRankingClient.traitKeyLabel().getString() + "]");
		return switch (ClientCombatStatus.trait()) {
			case KILLING_INTENT -> ClientCombatStatus.active() ? class_2561.method_43470("+" + ClientCombatStatus.power() + "% " + seconds(ClientCombatStatus.effectTicks())) : class_2561.method_43471("hud.killerranking.on_hit");
			case FIGHTING_SPIRIT -> class_2561.method_43469("hud.killerranking.defense", ClientCombatStatus.power());
			case MIXED_MADNESS -> class_2561.method_43470(String.format(Locale.ROOT,"피해 +%.1f%%",ClientCombatStatus.madnessBonus()));
			case POISON_AURA -> class_2561.method_43469("hud.killerranking.poison_duration", seconds(ClientCombatStatus.effectTotalTicks()));
			default -> class_2561.method_43471("hud.killerranking.waiting");
		};
	}
	public static class_2561 parryStatus() {
		return ClientCombatStatus.parryActive() ? class_2561.method_43471("hud.killerranking.parrying") : ClientCombatStatus.parryTicks() > 0
			? class_2561.method_43470(seconds(ClientCombatStatus.parryTicks())) : class_2561.method_43471("hud.killerranking.ready");
	}
    public static class_2561 survivalStatus() {
        if (ClientCombatStatus.survivalTicks() > 0) return class_2561.method_43470("생존 " + seconds(ClientCombatStatus.survivalTicks()));
        if (ClientCombatStatus.survivalCooldown() > 0) return class_2561.method_43470("재사용 " + seconds(ClientCombatStatus.survivalCooldown()));
        return class_2561.method_43470(TraitVisuals.enabled() ? "준비" : "꺼짐");
    }
    public static float survivalProgress() {
        return ClientCombatStatus.survivalTicks() > 0 ? (float) ClientCombatStatus.survivalTicks() / dev.killerranking.combat.MadnessSurvival.DURATION
            : dev.killerranking.combat.CombatRules.cooldownProgress(ClientCombatStatus.survivalCooldown(), dev.killerranking.combat.MadnessSurvival.COOLDOWN);
    }
	public static void render(class_332 graphics) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1690.field_1842 || client.field_1724.method_7325() || !client.field_1724.method_5805()) return;
        FixedUi.begin(graphics);
        SkillHud.render(graphics);
        if (!ClientCombatStatus.available() || ClientCombatStatus.trait() == Trait.UNASSIGNED) { FixedUi.end(graphics); return; }
		int x = FixedUi.width() / 2 + 10;
        // Fixed-size bars remain above vanilla food/air bars when their scale changes.
        double vanillaUnits = client.method_22683().method_4495() / FixedUi.SCALE;
		int bottom = FixedUi.height() - (int) Math.ceil(39 * vanillaUnits + 13);
		if (client.field_1724.method_5869() || client.field_1724.method_5669() < client.field_1724.method_5748()) bottom -= (int) Math.ceil(10 * vanillaUnits);
		if (client.field_1724.method_5854() != null) bottom -= (int) Math.ceil(20 * vanillaUnits);
        if (ClientCombatStatus.trait() == Trait.MIXED_MADNESS) {
            label(graphics, class_2561.method_43470("미친 고씨"), survivalStatus(), x, bottom - 45, 0xFFFFB181);
            bar(graphics, x, bottom - 37, 81, 5, survivalProgress(), 0xFFFFB181);
        }
		label(graphics, traitName(), traitStatus(), x, bottom - 27, traitColor());
		bar(graphics, x, bottom - 19, 81, 5, ClientCombatStatus.gauge(), traitColor());
		label(graphics, class_2561.method_43471("key.killerranking.parry"), parryStatus(), x, bottom - 9,
			ClientCombatStatus.parryActive() ? 0xFFFFFFFF : 0xFF81D6C5);
		bar(graphics, x, bottom - 1, 81, 5, ClientCombatStatus.parryProgress(), 0xFF81D6C5);
        FixedUi.end(graphics);
	}
	private static void label(class_332 graphics, class_2561 name, class_2561 status, int x, int y, int color) {
		var font = class_310.method_1551().field_1772;
		graphics.method_51448().method_22903();
		graphics.method_51448().method_46416(x, y, 0);
		graphics.method_51448().method_22905(0.65F, 0.65F, 1);
		String text = status.getString();
		int available = 124 - font.method_1727(text) - 5;
		graphics.method_25303(font, font.method_27523(name.getString(), available), 0, 0, color);
		graphics.method_25303(font, text, 124 - font.method_1727(text), 0, 0xFFF0F2F7);
		graphics.method_51448().method_22909();
	}
	public static void bar(class_332 graphics, int x, int y, int width, int height, float progress, int color) {
		graphics.method_25294(x - 1, y - 1, x + width + 1, y + height + 1, 0xDD090D16);
		graphics.method_25294(x, y, x + width, y + height, 0xFF303B4C);
		int fill = Math.round((width - 2) * Math.clamp(progress, 0, 1));
		if (fill > 0) {
			graphics.method_25294(x + 1, y + 1, x + 1 + fill, y + height - 1, color);
			graphics.method_25294(x + 1, y + 1, x + 1 + fill, y + 2, 0x66FFFFFF);
		}
	}
}
