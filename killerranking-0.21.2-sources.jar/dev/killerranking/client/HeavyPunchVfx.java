package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.HeavyPunchRules;
import dev.killerranking.network.HeavyPunchVisualPayload;
import dev.kosmx.playerAnim.api.layered.*;
import dev.kosmx.playerAnim.minecraftApi.*;
import java.util.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import com.mojang.blaze3d.vertex.*;

/** A single falling drop and a forward pixel trail for the self-braced rotational punch. */
public final class HeavyPunchVfx {
    private static final class_2960 LAYER=KillerRankingMod.id("heavy_punch_layer"),ANIMATION=KillerRankingMod.id("tteokbal_heavy_punch");
    private static final Map<UUID,State> ACTIVE=new HashMap<>();
    private static final class State {int remaining,age,target;float yaw,height=1.55f,reach=1.57f;boolean animated;
        State(HeavyPunchVisualPayload p){remaining=p.remaining();age=p.age();target=p.target();yaw=p.yaw();}}
    private static long drops,impacts;
    public static void register(){
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{
            var layer=new ModifierLayer<IAnimation>();
            layer.addModifierLast(new dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier(p));
            stack.addAnimLayer(2600,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
        });
        WorldRenderEvents.AFTER_ENTITIES.register(HeavyPunchVfx::render);
    }
    public static void accept(HeavyPunchVisualPayload p){
        if(p.remaining()<=0){remove(p.player());return;}
        ACTIVE.compute(p.player(),(id,s)->{if(s==null)return new State(p);s.remaining=p.remaining();s.age=p.age();s.target=p.target();s.yaw=p.yaw();return s;});
    }
    public static boolean active(UUID id){return ACTIVE.containsKey(id);}
    public static boolean captured(class_1309 entity){return false;}
    public static net.minecraft.class_1657 captor(class_1309 target){return null;}
    public static class_1309 target(UUID id){var s=ACTIVE.get(id);var c=class_310.method_1551();
        return s!=null&&s.target>=0&&c.field_1687!=null&&c.field_1687.method_8469(s.target) instanceof class_1309 e?e:null;}
    public static float age(UUID id,float delta){var s=ACTIVE.get(id);return s==null?-1:s.age+delta;}
    public static float facing(class_1309 entity,float fallback){return yaw(entity.method_5667(),fallback);}
    public static boolean locked(class_1309 e){return e.method_37908().field_9236&&active(e.method_5667());}
    public static float yaw(UUID id,float fallback){var s=ACTIVE.get(id);return s==null?fallback:s.yaw;}
    public static net.minecraft.class_243 contactPoint(UUID id,net.minecraft.class_243 origin,net.minecraft.class_243 forward){
        var s=ACTIVE.get(id);return s==null?origin.method_1019(forward.method_1021(1.57)).method_1031(0,1.55,0):origin.method_1019(forward.method_1021(s.reach)).method_1031(0,s.height,0);
    }
    /** Offset the native punching block for the target's actual head height. */
    public static float headOffset(UUID id){var s=ACTIVE.get(id);if(s==null)return 0;
        float weight=Math.clamp((s.age-38)/3f,0,1)*Math.clamp((49-s.age)/5f,0,1);
        return -(s.height-1.65f)*16*weight;}
    public static long renderedDrops(){return drops;}
    public static long renderedImpacts(){return impacts;}
    public static void tick(class_310 client){
        if(client.method_1493()||client.field_1687==null)return;
        for(var id:new ArrayList<>(ACTIVE.keySet())){
            var s=ACTIVE.get(id);var e=client.field_1687.method_18470(id);
            if(--s.remaining<=0||e==null||!e.method_5805()||e.method_7325()){remove(id);continue;}
            if(!s.animated)s.animated=animate(e,s.age);
            if(s.age<HeavyPunchRules.IMPACT&&s.target>=0&&client.field_1687.method_8469(s.target) instanceof class_1309 target){
                s.height=(float)Math.clamp(target.method_23320()-.08-e.method_23318(),.55,2.65);
                var forward=net.minecraft.class_243.method_1030(0,s.yaw);
                s.reach=(float)Math.clamp(target.method_19538().method_1020(e.method_19538()).method_1026(forward)-.18,.65,2.22);
            }
            // Lock the body to the opponent, while allowing mouse look to remain free.
            e.field_6283=e.field_6220=s.yaw;s.age++;
        }
    }
    @SuppressWarnings("unchecked")
    private static boolean animate(net.minecraft.class_1657 e,int age){
        if(!(e instanceof class_742 p))return false;
        var layer=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(!(layer instanceof ModifierLayer<?>))return false;
        IAnimation animation=null;
        if(age>=0){var data=PlayerAnimationRegistry.getAnimation(ANIMATION);if(data==null)return false;
            animation=(IAnimation)data.playAnimation();if(animation instanceof KeyframeAnimationPlayer key){
                for(int i=0;i<age;i++)key.tick();
                key.setFirstPersonMode(dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode.THIRD_PERSON_MODEL);
                key.setFirstPersonConfiguration(new dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration(true,true,false,false));
            }
        }
        ((ModifierLayer<IAnimation>)layer).setAnimation(animation);return true;
    }
    private static void remove(UUID id){ACTIVE.remove(id);var c=class_310.method_1551();if(c.field_1687!=null){var p=c.field_1687.method_18470(id);if(p!=null)animate(p,-1);}}
    public static void clear(){for(var id:new ArrayList<>(ACTIVE.keySet()))remove(id);}
    private static void render(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext context){
        var c=class_310.method_1551();var stack=context.matrixStack();var buffers=context.consumers();
        if(c.field_1687==null||stack==null||buffers==null)return;
        float delta=context.tickCounter().method_60637(false);var camera=context.camera().method_19326();
        for(var entry:ACTIVE.entrySet()){
            var p=c.field_1687.method_18470(entry.getKey());if(p==null||p.method_5767()||p.method_5707(camera)>4096)continue;
            var s=entry.getValue();float time=s.age+delta;
            var dir=net.minecraft.class_243.method_1030(0,s.yaw);
            var origin=p.method_30950(delta).method_1019(dir.method_1021(.55));
            if(time>=HeavyPunchRules.DROP&&time<HeavyPunchRules.SPLASH){
                float progress=(time-HeavyPunchRules.DROP)/(HeavyPunchRules.SPLASH-HeavyPunchRules.DROP);
                stack.method_22903();stack.method_22904(origin.field_1352-camera.field_1352,origin.field_1351+.15+1.4*(1-progress*progress)-camera.field_1351,origin.field_1350-camera.field_1350);
                stack.method_22907(context.camera().method_23767());
                quad(stack,buffers.getBuffer(class_1921.method_23580(KillerRankingMod.id("textures/effect/heavy_drop.png"))),-.055f,-.10f,.055f,.10f,0,0,1,1,1);
                stack.method_22909();drops++;
            }
            if(time>=HeavyPunchRules.SPLASH&&time<HeavyPunchRules.SPLASH+3){
                float r=.08f+(time-HeavyPunchRules.SPLASH)*.10f;
                stack.method_22903();stack.method_22904(origin.field_1352-camera.field_1352,origin.field_1351+.03-camera.field_1351,origin.field_1350-camera.field_1350);
                stack.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(90));
                quad(stack,buffers.getBuffer(class_1921.method_23580(KillerRankingMod.id("textures/effect/heavy_ripple.png"))),-r,-r,r,r,0,0,1,1,1);
                stack.method_22909();
            }
            if(time>=HeavyPunchRules.IMPACT-2&&time<HeavyPunchRules.IMPACT+6){
                float elapsed=time-(HeavyPunchRules.IMPACT-2);int frame=Math.min(3,(int)elapsed/2);
                stack.method_22903();stack.method_22904(p.method_23317()-camera.field_1352,p.method_23318()+s.height-camera.field_1351,p.method_23321()-camera.field_1350);
                stack.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-s.yaw));
                var v=buffers.getBuffer(class_1921.method_23580(KillerRankingMod.id("textures/effect/heavy_impact.png")));
                float alpha=Math.min(1,(8-elapsed)/3);float lo=frame/4f,hi=(frame+1)/4f;
                // The trail follows the forward head-height strike, without an upward flare.
                stack.method_22904(0,0,.45);stack.method_22903();stack.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(90));
                stack.method_22907(net.minecraft.class_7833.field_40718.rotationDegrees(-5));
                quad(stack,v,-1.40f,-.19f,-.06f,.19f,0,lo,1,hi,alpha);stack.method_22909();
                stack.method_22904(0,0,s.reach-.45);quad(stack,v,-.38f,-.38f,.38f,.38f,0,lo,1,hi,alpha);
                stack.method_22909();impacts++;
            }
        }
    }
    private static void quad(class_4587 s,class_4588 v,float x0,float y0,float x1,float y1,float u0,float v0,float u1,float v1,float a){
        vertex(s,v,x0,y0,u0,v1,a);vertex(s,v,x1,y0,u1,v1,a);vertex(s,v,x1,y1,u1,v0,a);vertex(s,v,x0,y1,u0,v0,a);
    }
    private static void vertex(class_4587 s,class_4588 v,float x,float y,float u,float tex,float alpha){v.method_22918(s.method_23760().method_23761(),x,y,0).method_22915(1,1,1,alpha).method_22913(u,tex).method_22922(class_4608.field_21444).method_60803(0xF000F0).method_60831(s.method_23760(),0,0,1);}
    private HeavyPunchVfx(){}
}
