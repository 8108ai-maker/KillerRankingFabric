package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.network.KillingIntentVfxPayload;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_4002;
import net.minecraft.class_4066;
import java.util.*;

public final class KillingIntentVfx {
    private static final Map<UUID, Integer> ACTIVE = new HashMap<>();
    private static class_4002 sprites;
    public static void register() {
        ParticleFactoryRegistry.getInstance().register(KillerRankingMod.KILLING_AURA, set -> {
            sprites = set;
            return (parameters, world, x, y, z, dx, dy, dz) -> null;
        });
    }
    static class_4002 sprites() { return sprites; }
    public static void accept(KillingIntentVfxPayload payload) {
        if (payload.ticks() == 0) ACTIVE.remove(payload.player());
        else ACTIVE.put(payload.player(), payload.ticks());
    }
    public static void clear() { ACTIVE.clear(); }
    public static boolean active(UUID id) { return ACTIVE.getOrDefault(id, 0) > 0; }
    public static boolean hiddenForCamera(class_1657 player) {
        var client = class_310.method_1551();
        return player.method_5767() || player.method_7325() || !player.method_5805()
            || (player == client.method_1560() && client.field_1690.method_31044().method_31034());
    }
    public static void tick(class_310 client) {
        if (client.method_1493() || client.field_1687 == null) return;
        ACTIVE.replaceAll((id, ticks) -> ticks - 1);
        ACTIVE.entrySet().removeIf(e -> e.getValue() <= 0);
        if (sprites == null || client.method_1560() == null) return;
        var camera = client.method_1560();
        var players = ACTIVE.keySet().stream().map(id -> client.field_1687.method_18470(id)).filter(Objects::nonNull)
            .filter(p -> !hiddenForCamera(p) && p.method_5858(camera) <= 1024)
            .sorted(Comparator.comparingDouble(p -> p.method_5858(camera))).limit(6).toList();
        var setting = client.field_1690.method_42475().method_41753();
        int budget = setting == class_4066.field_18199 ? 4 : setting == class_4066.field_18198 ? 12 : 24;
        for (var player : players) {
            int count = setting == class_4066.field_18199 ? 1 : setting == class_4066.field_18198 || player.method_5858(camera) > 256 ? 2 : 4;
            for (int i = 0; i < count && budget > 0; i++, budget--) {
                boolean dark = player.method_59922().method_43057() < .28f;
                client.field_1713.method_3058(new KillingAuraParticle(client.field_1687, player, sprites, dark));
            }
        }
    }
    private KillingIntentVfx() { }
}
