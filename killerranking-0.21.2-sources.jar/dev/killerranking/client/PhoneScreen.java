package dev.killerranking.client;
import dev.killerranking.data.KillerPoints;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import dev.killerranking.KillerRankingMod;

/** A resizable phone with keyboard-accessible navigation and live server data. */
public final class PhoneScreen extends class_437 {
	private static final int W = 224, H = 270;
	private static final int WHITE = 0xFFF1F4FA, MUTED = 0xFF9FACBF, RED = 0xFFF06470;
	private int page;
	private int left, top;
	private float scale;
    private PhoneButton branchButton;
	public PhoneScreen() { super(class_2561.method_43471("item.killerranking.phone")); UiSounds.open(); }
	@Override public void method_25419() { UiSounds.close(); super.method_25419(); }

	@Override protected void method_25426() {
		scale = FixedUi.factor();
		left = Math.round((field_22789 - W * scale) / 2);
		top = Math.round((field_22790 - H * scale) / 2);
		for (int index = 0; index < 3; index++) {
			final int selected = index;
			method_37063(new PhoneButton(14 + index * 66, 230, 64, 18,
				class_2561.method_43471("phone.killerranking.tab." + index), () -> { if (selected == 2) field_22787.method_1507(new MissionsScreen(this)); else page = selected; }, index));
		}
		method_37063(new PhoneButton(136, 17, 48, 16, class_2561.method_43470("스탯"), () -> field_22787.method_1507(new StatsScreen(this)), -1));
        method_37063(new PhoneButton(82, 17, 48, 16, class_2561.method_43470("상점"), () -> field_22787.method_1507(new PointsShopScreen(this)), -1));
        method_37063(new PhoneButton(191, 12, 18, 18, class_2561.method_43470("×"), this::method_25419, -1));
        branchButton = method_37063(new PhoneButton(25, 135, 173, 17, class_2561.method_43470("투기 분기 선택"),
            () -> field_22787.method_1507(new BranchChoiceScreen(this)), -1));
        updateBranchButton();
	}
    private void updateBranchButton() {
        branchButton.field_22764 = page == 1 && ClientDashboard.needsChoice();
        branchButton.field_22763 = branchButton.field_22764;
    }

	@Override public void method_25420(class_332 g, int mouseX, int mouseY, float delta) {
        updateBranchButton();
		super.method_25420(g, mouseX, mouseY, delta);
		g.method_51448().method_22903();
		g.method_51448().method_46416(left, top, 0);
		g.method_51448().method_22905(scale, scale, 1);
		g.method_25294(2, 2, W - 2, H - 2, 0xFF080B11);
		g.method_25294(0, 10, W, H - 10, 0xFF080B11);
		g.method_25294(4, 6, W - 4, H - 6, 0xFF374355);
		g.method_25294(7, 9, W - 7, H - 9, 0xFF101723);
		g.method_25294(93, 10, 131, 13, 0xFF06080D);
		g.method_25294(136, 10, 139, 13, RED);
		text(g, "K / R", 17, 19, RED);
		text(g, "KILLER RANKING  ·  " + KillerRankingClient.traitKeyLabel().getString() + " " + (TraitVisuals.enabled() ? "ON" : "OFF"), 17, 36, WHITE);
		g.method_25294(17, 49, W - 17, 50, 0xFF344053);
		if (!ClientCombatStatus.available()) {
			g.method_27534(field_22793, tr("hud.killerranking.waiting"), W / 2, 112, MUTED);
		} else if (page == 0) renderHome(g);
		else if (page == 1) renderCombat(g);
		else renderMission(g);
		g.method_27534(field_22793, tr("phone.killerranking.close"), W / 2, 251, MUTED);
		g.method_51448().method_22909();
	}

	private void renderHome(class_332 g) {
		var profile = ClientProfile.get();
		card(g, 58, 43, RED);
		text(g, tr("phone.killerranking.points"), 25, 65, MUTED);
		g.method_51448().method_22903();
		g.method_51448().method_46416(25, 80, 0);
        String balance = KillerPoints.format(profile.pointUnits()) + " P";
        float balanceScale = Math.min(1.25F, 148F / Math.max(1, field_22793.method_1727(balance)));
		g.method_51448().method_22905(balanceScale, balanceScale, 1);
		text(g, balance, 0, 0, WHITE);
		g.method_51448().method_22909();
		g.method_51427(KillerRankingMod.PHONE.method_7854(), 179, 70);
		card(g, 108, 57, CombatHud.traitColor());
		text(g, CombatHud.traitName(), 25, 116, CombatHud.traitColor());
		text(g, CombatHud.traitStatus(), 25, 134, WHITE);
		CombatHud.bar(g, 25, 151, 173, 5, ClientCombatStatus.gauge(), CombatHud.traitColor());
		card(g, 172, 49, 0xFF81D6C5);
		var data = ClientDashboard.get();
        long complete = data == null ? 0 : data.missions().stream().filter(m -> m.complete()).count();
        text(g, "랜덤 미션 · " + complete + " / 10 완료", 25, 179, MUTED);
        text(g, ClientDashboard.remaining(), 25, 194, WHITE);
        CombatHud.bar(g, 25, 208, 173, 4, complete / 10f, 0xFF81D6C5);
	}

	private void renderCombat(class_332 g) {
		card(g, 58, 119, CombatHud.traitColor());
		text(g, CombatHud.traitName(), 25, 66, CombatHud.traitColor());
		g.method_51440(field_22793, CombatHud.traitDescription(), 25, 84, 173, MUTED);
        if (!ClientDashboard.needsChoice()) text(g, ClientCombatStatus.trait() == dev.killerranking.Trait.MIXED_MADNESS
            ? class_2561.method_43470("미친 고씨 · ").method_10852(CombatHud.survivalStatus()) : CombatHud.traitStatus(), 25, 137, WHITE);
		CombatHud.bar(g, 25, 152, 173, 4, ClientCombatStatus.gauge(), CombatHud.traitColor());
        var progress = ClientDashboard.get();
        if (progress != null) text(g, progress.level() >= 3 ? "특성 경험치 · MAX" : "특성 경험치 " + progress.traitXp() + " / " + progress.traitXpRequired(), 25, 164, WHITE);
		card(g, 178, 43, 0xFF81D6C5);
		text(g, class_2561.method_43469("phone.killerranking.parry_key", KillerRankingClient.parryKeyLabel()), 25, 186, WHITE);
		class_2561 status = CombatHud.parryStatus();
		g.method_51439(field_22793, status, 199 - field_22793.method_27525(status), 186, 0xFF81D6C5, false);
		CombatHud.bar(g, 25, 205, 173, 5, ClientCombatStatus.parryProgress(), 0xFF81D6C5);
	}

	private void renderMission(class_332 g) {
        text(g, "미션 탭을 눌러 10개 목록 보기", 25, 80, WHITE);
    }

	private static class_2561 tr(String key) { return class_2561.method_43471(key); }
	private void text(class_332 g, String value, int x, int y, int color) { g.method_51433(field_22793, value, x, y, color, false); }
	private void text(class_332 g, class_2561 value, int x, int y, int color) { g.method_51439(field_22793, value, x, y, color, false); }
	private void card(class_332 g, int y, int height, int accent) {
		g.method_25294(17, y, 207, y + height, 0xFF1B2636);
		g.method_25294(17, y, 19, y + height, accent);
	}
	@Override public boolean method_25421() { return false; }

	private final class PhoneButton extends class_4264 {
		private final Runnable action;
		private final int tab;
		PhoneButton(int x, int y, int w, int h, class_2561 label, Runnable action, int tab) {
			super(left + Math.round(x * scale), top + Math.round(y * scale), Math.round(w * scale), Math.round(h * scale), label);
			this.action = action;
			this.tab = tab;
		}
		@Override public void method_25306() { action.run(); }
		@Override protected void method_48579(class_332 g, int mouseX, int mouseY, float delta) {
			boolean selected = tab >= 0 && page == tab;
			g.method_25294(method_46426(), method_46427(), method_46426() + method_25368(), method_46427() + method_25364(), selected ? 0xFF963E4A : method_25367() ? 0xFF35445A : 0xFF202C3D);
			if (method_25370()) g.method_49601(method_46426(), method_46427(), method_25368(), method_25364(), WHITE);
			g.method_51448().method_22903();
			g.method_51448().method_46416(method_46426() + method_25368() / 2.0F, method_46427() + (method_25364() - 8 * scale) / 2, 0);
			g.method_51448().method_22905(scale, scale, 1);
			g.method_27534(class_310.method_1551().field_1772, method_25369(), 0, 0, WHITE);
			g.method_51448().method_22909();
		}
		@Override protected void method_47399(class_6382 output) { method_37021(output); }
		@Override public void method_25354(net.minecraft.class_1144 manager) { UiSounds.click(manager); }
	}
}
