package dev.killerranking.client;
import dev.killerranking.KillerRankingMod;
import dev.killerranking.combat.RookRules;
import dev.killerranking.network.RookVisualPayload;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import java.util.*;
import net.minecraft.class_310;
import net.minecraft.class_742;

public final class RookVfx {
    private static final net.minecraft.class_2960 LAYER=KillerRankingMod.id("rook_layer");
    private static final Map<UUID,State> STATES=new HashMap<>();
    private static final class State {
        UUID victim;int phase,age,remaining,victimId=-1;float width=.6f;boolean animated,victimAnimated;
        State(RookVisualPayload p){victim=p.victim();phase=p.phase();age=p.age();remaining=p.remaining();}
    }
    public static void register(){PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((p,stack)->{
        var layer=new ModifierLayer<IAnimation>();layer.addModifierLast(new LeftHandedHelperModifier(p));stack.addAnimLayer(3300,layer);PlayerAnimationAccess.getPlayerAssociatedData(p).set(LAYER,layer);
    });net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.AFTER_ENTITIES.register(RookMountScene::render);}
    public static void accept(RookVisualPayload p){
        var old=STATES.get(p.owner());
        if(p.remaining()<=0||p.phase()==0){remove(p.owner());return;}
        if(old==null||old.phase!=p.phase()) {remove(p.owner());STATES.put(p.owner(),new State(p));}
        else {if(!Objects.equals(old.victim,p.victim())){animate(old.victim,null,0);old.victimAnimated=false;old.victimId=-1;}old.victim=p.victim();old.age=p.age();old.remaining=p.remaining();}
    }
    public static boolean active(UUID id){return STATES.containsKey(id);}
    public static boolean mounting(UUID owner){var s=STATES.get(owner);return s!=null&&s.phase==RookRules.MOUNT;}
    public static net.minecraft.class_1309 mountVictim(UUID owner) {
        var s=STATES.get(owner);var c=class_310.method_1551();
        if(s==null||s.phase!=RookRules.MOUNT||s.victim==null||c.field_1687==null)return null;
        var victim=c.field_1687.method_8469(s.victimId);
        if(victim==null||!s.victim.equals(victim.method_5667()))for(var e:c.field_1687.method_18112())if(s.victim.equals(e.method_5667())){s.victimId=e.method_5628();victim=e;break;}
        return victim instanceof net.minecraft.class_1309 living&&living.method_5805()&&!living.method_31481()?living:null;
    }
    public static float mountedWidth(UUID owner) {
        var s=STATES.get(owner);return s==null?.6f:s.width;
    }
    public static boolean captured(UUID id){return WasabariVfx.captured(id)||STATES.values().stream().anyMatch(s->id.equals(s.victim));}
    public static boolean immobilized(net.minecraft.class_1297 entity) {
        if(WasabariVfx.immobilized(entity))return true;
        if(entity instanceof net.minecraft.class_1309 living&&HeavyPunchVfx.locked(living))return true;
        return entity.method_37908().field_9236&&(active(entity.method_5667())||captured(entity.method_5667())
            ||entity==class_310.method_1551().field_1724&&ClientRook.locked());
    }
    public static class_742 mountingOwner(UUID victim) {
        var c=class_310.method_1551();if(c.field_1687==null)return null;
        for(var entry:STATES.entrySet())if(entry.getValue().phase==RookRules.MOUNT&&victim.equals(entry.getValue().victim))
            return c.field_1687.method_18470(entry.getKey()) instanceof class_742 owner?owner:null;
        return null;
    }
    public static float mountImpact(UUID victim,float partialTick) {
        for(var s:STATES.values())if(s.phase==RookRules.MOUNT&&victim.equals(s.victim)) {
            float age=s.age+partialTick-1;
            for(int i=0;i<RookRules.MOUNT_HITS;i++){
                int strike=RookRules.MOUNT_FIRST_HIT+i*RookRules.MOUNT_HIT_INTERVAL;
                if(age>=strike&&age<strike+3)return 1-(age-strike)/3;
            }
        }
        return 0;
    }
    public static void tick(class_310 c){
        if(c.method_1493()||c.field_1687==null)return;
        for(var id:new ArrayList<>(STATES.keySet())) {
            var s=STATES.get(id);var p=c.field_1687.method_18470(id);
            if(--s.remaining<=0||p==null||!p.method_5805()){remove(id);continue;}
            if(s.victim!=null) {
                if(s.victimId<0)for(var entity:c.field_1687.method_18112())if(s.victim.equals(entity.method_5667())){s.victimId=entity.method_5628();break;}
                var victim=c.field_1687.method_8469(s.victimId);if(victim!=null)s.width=victim.method_17681();
            }
            if(!s.animated)s.animated=animate(id,switch(s.phase){case RookRules.THROW->"rook_throw";case RookRules.PUNCH->"rook_punch";case RookRules.MOUNT->"rook_mount";default->"rook_hold";},s.age);
            if(!s.victimAnimated)s.victimAnimated=animate(s.victim,"rook_captive",s.age);
            s.age++;
        }
    }
    private static void remove(UUID id){var old=STATES.remove(id);animate(id,null,0);if(old!=null)animate(old.victim,null,0);}
    public static void clear(){for(var id:new ArrayList<>(STATES.keySet()))remove(id);}
    @SuppressWarnings("unchecked") private static boolean animate(UUID id,String name,int age){
        var c=class_310.method_1551();if(id==null||c.field_1687==null||!(c.field_1687.method_18470(id) instanceof class_742 p))return false;
        var layer=PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);if(!(layer instanceof ModifierLayer<?>))return false;
        IAnimation animation=null;
        if(name!=null){var data=PlayerAnimationRegistry.getAnimation(KillerRankingMod.id(name));if(data==null)return false;animation=(IAnimation)data.playAnimation();
            if(animation instanceof KeyframeAnimationPlayer frames){for(int i=0;i<age;i++)frames.tick();frames.setFirstPersonMode(dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode.THIRD_PERSON_MODEL);frames.setFirstPersonConfiguration(new dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration(true,true,false,false));}}
        ((ModifierLayer<IAnimation>)layer).setAnimation(animation);return true;
    }
    private RookVfx(){}
}
