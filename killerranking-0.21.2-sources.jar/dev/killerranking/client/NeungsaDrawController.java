package dev.killerranking.client;

import dev.killerranking.KillerRankingMod;
import dev.killerranking.visual.NeungsaDrawState;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.api.layered.modifier.SpeedModifier;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import dev.kosmx.playerAnim.minecraftApi.layers.LeftHandedHelperModifier;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_742;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Hold the hilt and saya during locomotion; Better Combat still owns every cut. */
public final class NeungsaDrawController {
    private static final net.minecraft.class_2960 LAYER = KillerRankingMod.id("neungsa_draw_layer");
    private static final Map<UUID, NeungsaDrawState> STATES = new HashMap<>();
    private static final Map<UUID,Long> DRAW_FINISH = new HashMap<>();
    private static final Map<UUID,String> CLIPS = new HashMap<>();

    public static void register() {
        PlayerAnimationAccess.REGISTER_ANIMATION_EVENT.register((player, stack) -> {
            var layer = new ModifierLayer<IAnimation>();
            layer.addModifierLast(new SpeedModifier(32));
            layer.addModifierLast(new LeftHandedHelperModifier(player));
            stack.addAnimLayer(1900, layer);
            PlayerAnimationAccess.getPlayerAssociatedData(player).set(LAYER, layer);
        });
        ClientPlayConnectionEvents.JOIN.register((h,s,c) -> { STATES.clear(); DRAW_FINISH.clear(); CLIPS.clear(); });
        ClientPlayConnectionEvents.DISCONNECT.register((h,c) -> { STATES.clear(); DRAW_FINISH.clear(); CLIPS.clear(); });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null || client.method_1493()) return;
            STATES.keySet().removeIf(id -> client.field_1687.method_18470(id) == null);
            DRAW_FINISH.keySet().removeIf(id -> !STATES.containsKey(id));
            CLIPS.keySet().removeIf(id -> !STATES.containsKey(id));
            for (var player : client.field_1687.method_18456()) {
                var state = STATES.get(player.method_5667());
                if (state == null && player.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA))
                    state = STATES.computeIfAbsent(player.method_5667(), id -> new NeungsaDrawState());
                if (state == null) continue;
                if (!player.method_5805() || !player.method_6047().method_31574(KillerRankingMod.NEUNGSA_KATANA)) {
                    state.reset(); DRAW_FINISH.remove(player.method_5667()); set(player, null); continue;
                }
                var readyAt = DRAW_FINISH.get(player.method_5667());
                if (readyAt != null && player.field_6012 >= readyAt) {
                    DRAW_FINISH.remove(player.method_5667()); set(player,"drawn_guard");
                }
                var before = state.phase();
                boolean continuing = player == client.field_1724 && client.field_1755 == null && client.field_1690.field_1886.method_1434();
                var after = state.tick(player.field_6012, continuing || NeungsaHeldBlade.hidden(player));
                if (before != after) set(player, after == NeungsaDrawState.Phase.SHEATHING ? "sheathe" : null);
                // Better Combat fades its idle pose while moving. Keep the
                // existing two-hand hilt/saya grip above locomotion, below
                // attacks/parry. This clip has no body, head or leg channels.
                if (after == NeungsaDrawState.Phase.SHEATHED)
                    set(player, player.method_52814().comp_1629() == net.minecraft.class_8685.class_7920.field_41122
                        ? "carry_slim" : "carry");
            }
        });
    }

    public static void iaido(class_742 player){
        STATES.computeIfAbsent(player.method_5667(),id->new NeungsaDrawState()).reset();
        DRAW_FINISH.remove(player.method_5667());set(player,player.method_52814().comp_1629()==net.minecraft.class_8685.class_7920.field_41122?"carry_slim":"carry");
    }
    public static void parry(class_742 player){
        interruptIaidoRecovery(player);
        STATES.computeIfAbsent(player.method_5667(),id->new NeungsaDrawState()).attack(player.field_6012,12);
        DRAW_FINISH.remove(player.method_5667());set(player,"drawn_guard");
    }
    public static String attack(class_742 player, String name, float length) {
        if (!name.startsWith("killerranking:neungsa_katana_") || name.endsWith("parry")) return name;
        interruptIaidoRecovery(player);
        var state = STATES.computeIfAbsent(player.method_5667(), id -> new NeungsaDrawState());
        boolean first = state.attack(player.field_6012, length);
        // Keep the sheathed idle under the first fade until extraction clears
        // the scabbard. Installing drawn idle immediately flashes the blade.
        if (first) {
            DRAW_FINISH.put(player.method_5667(),(long)player.field_6012 + Math.max(1,(int)Math.ceil(length * 7 / 26)));
            set(player,null);
        } else { DRAW_FINISH.remove(player.method_5667()); set(player,"drawn_guard"); }
        return first ? name.replace("neungsa_katana_", "neungsa_katana_draw_") : name;
    }
    public static void interruptIaidoRecovery(class_742 player){
        if(NeungsaIaidoVfx.interruptRecovery(player.method_5667())){
            STATES.computeIfAbsent(player.method_5667(),id->new NeungsaDrawState()).attack(player.field_6012,0);
            DRAW_FINISH.remove(player.method_5667());set(player,"drawn_guard");
        }
    }
    public static NeungsaDrawState.Phase phase(class_742 player) {
        var state = STATES.get(player.method_5667());
        return state == null ? NeungsaDrawState.Phase.SHEATHED : state.phase();
    }
    @SuppressWarnings("unchecked")
    private static void set(class_742 player, String clip) {
        var data = PlayerAnimationAccess.getPlayerAssociatedData(player).get(LAYER);
        if (!(data instanceof ModifierLayer<?> raw)) return;
        var layer = (ModifierLayer<IAnimation>)raw;
        if (java.util.Objects.equals(CLIPS.get(player.method_5667()), clip)) return;
        if (clip == null) { layer.setAnimation(null); CLIPS.remove(player.method_5667()); return; }
        var playable = PlayerAnimationRegistry.getAnimation(KillerRankingMod.id("neungsa_katana_" + clip));
        if (playable == null) return;
        var animation = (IAnimation)playable.playAnimation();
        if (animation instanceof KeyframeAnimationPlayer keys) {
            keys.setFirstPersonMode(FirstPersonMode.THIRD_PERSON_MODEL);
            keys.setFirstPersonConfiguration(new FirstPersonConfiguration(true,true,true,false));
        }
        layer.setAnimation(animation);
        CLIPS.put(player.method_5667(), clip);
    }
    private NeungsaDrawController() { }
}
